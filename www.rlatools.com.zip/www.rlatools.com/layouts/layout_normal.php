<?php include($processFile); ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
        <meta name="description" content="Record linkage algorithmic tools include two tools to integrate records accross multiple data sets. Single linkage clustering tool integrates records following a chaining process. But for real life data sources, complete linkage clustering performs better. Both tools are free to use." />
        <meta name="keywords" content="Record linkage, Data integration, clustering, hierarchical clustering, single linkage, complete linkage" />
        
        <title>Record Linkage</title>
        <link rel="icon" type="image/png" href="images/logo/icon.png" />
        <link rel="stylesheet" type="text/css" href="css/style_new.css" />
        <link href='http://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css' />
        <script src="javascripts/common.js" type="text/javascript"></script>
        <script src="javascripts/md5.js" type="text/javascript"></script>
        <script language="JavaScript">
        </script>
      
    </head>
    <body>
    
        <div id="frame">
			<?php include('common/header.php'); ?>
            <table width="100%" cellpadding="10">
                <tr align="left" valign="top">
                   	<?php include($leftMenu); ?>       
                </tr>
                <tr align="center" valign="top">
                	<?php include($rightPage); ?> 
                </tr>
            </table> 
            <?php include('common/footer.php'); ?>
        </div>
    </body>
</html>
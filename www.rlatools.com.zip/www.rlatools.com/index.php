<?php
	session_start();
	include_once('configs/config.php');
	include_once('configs/mysql_conf.php');
	include_once('libs/mysql_utilities.php');
	include_once('libs/common_utilities.php');
	require_once('libs/recaptchalib.php');
	
	
	$layout		 	= 'layouts/layout_normal.php';
	$logPage		= 'default';
	$leftMenu 		= 'common/leftMenuNew.php';
	$rightPage 		= 'pages/services.php';
	$processFile 	= 'pages/process_nothing.php';
	
	
	function rearrangePage($logPageVal, $leftMenuVal, $rightPageVal, $processFileVal)
	{
		global $logPage, $leftMenu, $rightPage, $processFile;
	
		$logPage		= $logPageVal;
		$leftMenu 		= $leftMenuVal;
		$rightPage 		= $rightPageVal;
		$processFile 	= $processFileVal;
	}
	
	
	
	if ( (isset($_GET['page']) && ($_GET['page'] == 'services')) || (isset($_POST['page']) && ($_POST['page'] == 'services')) ) 
	{
		rearrangePage('services', 'common/topMenu.php', 'pages/services.php', 'pages/process_nothing.php');
		include_once($layout);
	} 
	else if ((isset($_GET['page']) && ($_GET['page'] == 'singlelinkage')) || (isset($_POST['page']) && ($_POST['page'] == 'singlelinkage')))
	{
		rearrangepage('singlelinkage', 'common/topMenu.php', 'pages/singlelinkage.php', 'pages/process_singlelinkage.php');
		include_once($layout);
	}
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'completelinkage')) || (isset($_POST['page']) && ($_POST['page'] == 'completelinkage')) )
	{
		rearrangePage('motifproteinseq', 'common/topMenu.php', 'pages/completelinkage.php', 'pages/process_completelinkage.php');
		include_once($layout);  
	} 
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'motifseqcmp')) || (isset($_POST['page']) && ($_POST['page'] == 'motifseqcmp')) )
	{
		rearrangePage('motifseqcmp', 'common/topMenu.php', 'pages/motifseqcmp.php', 'pages/process_nothing.php');
		include_once($layout);	
	} 
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'motifstrct')) || (isset($_POST['page']) && ($_POST['page'] == 'motifstrct')) )
	{
		rearrangePage('motifstrct', 'common/topMenu.php', 'pages/motifstrct.php', 'pages/process_nothing.php');
		include_once($layout);
	} 
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'download')) || (isset($_POST['page']) && ($_POST['page'] == 'download')) )
	{
		rearrangePage('download', 'common/topMenu.php', 'pages/download.php', 'pages/process_nothing.php');
		include_once($layout);	
	} 
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'submissionhistory')) || (isset($_POST['page']) && ($_POST['page'] == 'submissionhistory')) )
	{
		rearrangePage('submissionhistory', 'common/topMenu.php', 'pages/submissionhistory.php', 'pages/process_submissionhistory.php');
		include_once($layout);	
	} 
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'feedback')) || (isset($_POST['page']) && ($_POST['page'] == 'feedback')) )
	{
		rearrangePage('feedback', 'common/topMenu.php', 'pages/feedback.php', 'pages/process_nothing.php');
		include_once($layout);
	} 
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'aboutus')) || (isset($_POST['page']) && ($_POST['page'] == 'aboutus')) )
	{
		rearrangePage('aboutus', 'common/topMenu.php', 'pages/aboutus.php', 'pages/process_nothing.php');
		include_once($layout);
	} 
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'help')) || (isset($_POST['page']) && ($_POST['page'] == 'help')) )
	{
		rearrangePage('help', 'common/topMenu.php', 'pages/services.php', 'pages/process_nothing.php');
		include_once($layout); 	
	}
	else if ( (isset($_GET['page']) && ($_GET['page'] == 'sponsors')) || (isset($_POST['page']) && ($_POST['page'] == 'sponsors')) )
	{
		rearrangePage('sponsors', 'common/topMenu.php', 'pages/sponsors.php', 'pages/process_nothing.php');
		include_once($layout);
	} 
	else 
	{
		rearrangePage('default', 'common/topMenu.php', 'pages/singlelinkage.php', 'pages/process_nothing.php');
		include_once($layout);  
	}
	
	// insert data in log_ip table when an user visits any page
	$link	= mysqli_connect($sql_host, $sql_username, $sql_password);
	if (!mysqli_select_db($link, $sql_database))
		die();
	$logID = insertAutoKeyRecord($link, '`log_ip`',
						array('`ipAddr`', '`websiteID`', '`page`', '`visitTime`'),					 
						array("'".$_SERVER["REMOTE_ADDR"]."'", "$websiteID", "'".$logPage."'", "NOW()"),
						'logID');				
	mysqli_close($link);

?>

 


<?php
	$sql_host		= '127.0.0.1';
	$sql_database 	= 'recordlinkage';
	$sql_username 	= 'yyyyyyy';
	$sql_password 	= 'zzzzzzz';
	$sql_port 		= 3306;
	
	// function to connect mysql
	function get_mysql_conn() 
	{
		$link = mysqli_connect($sql_host, $sql_username, $sql_password);
		if (!mysqli_select_db($link, $sql_database)) 
		{
			mysqli_close($link);
			return NULL;
		}
		return $link;
	}
?>
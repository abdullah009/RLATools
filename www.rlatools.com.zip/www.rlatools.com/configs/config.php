<?php
$CAPTCHA_PublicKey = "6LcY9sESAAAAAFj2adprqHfGTBMOzijcUpySpeE4";
$CAPTCHA_PrivateKey = "6LcY9sESAAAAAPXI8tttfJIUwIPNFIyc1gKNfu81";

$websiteID = 1; //rlatools.com
$websiteDomain = 'www.rlatools.com';

$ShowGoogleAd = false;

$AnonymousUserID = 1;
$IsIgnoredSecurityCheck = false;

$Path_UploadedFiles = "/Users/abdullah-al-mamun/office/Research/RecordLinkage/UploadedFiles/"; // 

function SecurityEncodeFunc($str) 
{
	$securityKey = "xxxxxx";
	return md5($securityKey.$str.$securityKey);
}
?>
<?php
header('Location: ../');
exit(1);
?>
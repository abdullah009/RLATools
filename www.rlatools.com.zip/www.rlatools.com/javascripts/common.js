function setCheckedElementsByName(elementName,checked) {
	var elements =document.getElementsByName(elementName);
	for (i = 0; i < elements.length; i++){	
		elements[i].checked = checked;		
	}
}

function change(element,newText) {
	document.getElementById(element).innerHTML = newText
}

function copySelectContent(b,a) {
	b.options.length = a.options.length;
	for (i = 0; i < a.options.length ; i++) {
		b.options[i] = new Option(a.options[i].text,a.options[i].value);
	}
}

function isEmailChar(a) {
	if ('a' <= a && a <= 'z') return true;
	if ('A' <= a && a <= 'Z') return true;
	if ('0' <= a && a <= '9') return true;
	if (a == '@') return true;
	if (a == '.') return true;
	if (a == '_') return true;
	return false;
}
function isValidEmail(email) {
	AC_pos = 0;
	AC_count = 0;
	dot_pos = 0;
	dot_count = 0;
	if (email.length < 5) {
		return false;
	}
	for (i = 0; i < email.length; i++) {
		if (email[i] == '@') {
			AC_pos = i;
			AC_count++;
		}
		if (AC_count > 1 || !isEmailChar(email[i])) {
			return false;
		}
		if (AC_count == 1) {
			if (email[i] == '.') {
				dot_pos = i;
				dot_count++;
			}		
		}
	}
	//alert(AC_pos + ' ' + AC_count + ' ' + dot_pos + ' ' + dot_count + ' ' + email.length);
	if (AC_count != 1 || dot_count < 1) { 
		return false;
	}
	if (!(0 < AC_pos && AC_pos < dot_pos && dot_pos < (email.length - 1))) {
		return false;
	}
	return true;
}
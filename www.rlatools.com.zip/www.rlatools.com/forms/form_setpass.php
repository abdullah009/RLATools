<table align="center">
    <td id="submission">
		<?php
           if ( isset($_POST['cmd_changepass']) && !$isValidPassword ) {
				echo '<b>New password and confirm password do not MATCH.</b><br>';
			}  
        ?>

    	<p>Please enter your new password to set it.</p>
    </td>
</table>

<table align="center">
	<td>
        <form method="post" action="index.php" id="formsubmission">
        <input type="hidden" name="page" value="submissionhistory" />
        <input type="hidden" name="cmd" value="set_password" />
        <input type="hidden" name="email" value="<?php echo $userEmail;?>" />
        <input type="hidden" name="cd" value="<?php echo SecurityEncodeFunc("$userEmail");?>" />
            <table border="1" >
            	<tr>
                	<td>
                        <font size="+1"> <b><center>Set new password form</center></b></font><br>
                        <table >
                            <tr>
                                <td>Email:
                                </td>
                                <td><?php echo $userEmail;?> 
                                </td>
                            </tr>
                            <tr>
                            	<td>New password:
                                </td>
                            	<td><input type="password" size="30" name="password_new" id="password_new" value=""/> 
                                </td>
                            </tr>
                            <tr>
                            	<td>New password(again):
                                </td>
                            	<td><input type="password" size="30" name="password_new_again" id="password_new_again" value="" /> 
                                </td>
                            </tr>
                            <tr>
                            	<td>
                                </td>
                            	<td><input type="submit" name="cmd_changepass" value="Submit" onClick="if (!checkSubmission()) return false;"/>
                                </td>
                            </tr>
                        </table>
                	</td>
                </tr>
            </table>
                
			<script language="JavaScript">
            function checkSubmission() {
                var password_new = document.getElementById('password_new');
                var password_new_again = document.getElementById('password_new_again');
                
                if (password_new.value != password_new_again.value) {
                    alert('New password and new confirmed password DO NOT match'); 
                    return false;	
                }
                if (!confirm('Are you sure that new passwords are correct?')) {
                    return false;
                }
                return true;
            }
            </script>
        </form>
    </td>
</table>
<form method="post" action="index.php" id="formSub">
<input type="hidden" name="page" value="motifproteinseq" />

<font color="#3399FF" size="+2"><b>Information about your data</b></font>
<?php
if ($_POST['cmd'] == 'Submit' && $captcha_passed && !$isValidData) {
	echo '<br><font color="#FF0000">Your protein sequences are not in the correct format. Please check it again.</font><br>';
} 
?>

<ul>

<li>
<b>Please enter your <font size="+1" color="#FF0000">protein sequences</font> in 
<a href="http://en.wikipedia.org/wiki/FASTA_format" target="_blank">FASTA format</a></b> 
<font color="#FF0000">*(required)</font>. <br>
The number of sequences must be <font color="#FF0000"><b>between 5 and 5000</b></font>. 
The length of each sequence must be <font color="#FF0000"><b>between 15 and 1000 protein letters</b></font>.
<a href="proteinseqssample.php" target="_blank">Click here for an example</a>. 
If your data is DNA sequences, please submit to the DNA motif form at 
<a href="index.php?page=motifseq"> <b>Finding de-novo DNA motif sequences</b></a>.
If your data is protein sequneses, you can easily copy and paste your data into the following text box.<br>
<textarea name="dna_seqs_fasta" id="dna_seqs_fasta" cols="80" rows="14">
<?php if ($_POST['cmd'] == 'Submit') echo $_POST['dna_seqs_fasta'];?>
</textarea>
<br><br>&nbsp;
</li>

<li>
<b>The percentage of protein sequences containing motifs</b> <font color="#FF0000">*(required)</font>: 
<select name="quorum_percent">
<option value="5" <?php if ($_POST['quorum_percent'] == 5) echo 'selected';?> > 5</option>
<option value="10" <?php if ($_POST['quorum_percent'] == 10) echo 'selected';?> > 10</option>
<option value="20" <?php if ($_POST['quorum_percent'] == 20) echo 'selected';?> > 20</option>
<option value="30" <?php if ($_POST['quorum_percent'] == 30) echo 'selected';?> > 30</option>
<option value="35" <?php if ($_POST['quorum_percent'] == 35) echo 'selected';?> > 35</option>
<option value="40" <?php if ($_POST['quorum_percent'] == 40) echo 'selected';?> > 40</option>
<option value="45" <?php if ($_POST['quorum_percent'] == 45) echo 'selected';?> > 45</option>
<option value="50" <?php if ($_POST['quorum_percent'] == 50) echo 'selected';?> > 50</option>
<option value="55" <?php if ($_POST['quorum_percent'] == 55) echo 'selected';?> > 55</option>
<option value="60" <?php if ($_POST['quorum_percent'] == 60) echo 'selected';?> > 60</option>
<option value="65" <?php if ($_POST['quorum_percent'] == 65) echo 'selected';?> > 65</option>
<option value="70" <?php if ($_POST['quorum_percent'] == 70) echo 'selected';?> > 70</option>
<option value="75" <?php if (!isset($_POST['quorum_percent']) || $_POST['quorum_percent'] == 75) echo 'selected';?> > 75</option>
<option value="80" <?php if ($_POST['quorum_percent'] == 80) echo 'selected';?> > 80</option>
<option value="85" <?php if ($_POST['quorum_percent'] == 85) echo 'selected';?> > 85</option>
<option value="90" <?php if ($_POST['quorum_percent'] == 90) echo 'selected';?> > 90</option>
<option value="95" <?php if ($_POST['quorum_percent'] == 95) echo 'selected';?> > 95</option>
<option value="100" <?php if ($_POST['quorum_percent'] == 100) echo 'selected';?> > 100</option>
</select>
<br><br>&nbsp;
</li>

<li>
<b>Please let us know about the form of motifs</b> <font color="#FF0000">*(required)</font>:<br>
<input type="radio" name="binding_site" value="1" <?php if (!isset($_POST['binding_site']) || $_POST['binding_site'] == 1) echo 'checked';?> /> 
<font  color="#FF0000"> Single-box </font><br>
<ul><li>
The length of the box (motif length): 
<select name="binding_len">
<option value="4" <?php if ($_POST['binding_len'] == 4) echo 'selected';?> > 4</option>
<option value="5" <?php if ($_POST['binding_len'] == 5) echo 'selected';?> > 5</option>
<option value="6" <?php if ($_POST['binding_len'] == 6) echo 'selected';?> > 6</option>
<option value="7" <?php if ($_POST['binding_len'] == 7) echo 'selected';?> > 7</option>
<option value="8" <?php if ($_POST['binding_len'] == 8) echo 'selected';?> > 8</option>
<option value="9" <?php if ($_POST['binding_len'] == 9) echo 'selected';?> > 9</option>
<option value="10" <?php if ($_POST['binding_len'] == 10) echo 'selected';?> >10</option>
<option value="11" <?php if ($_POST['binding_len'] == 11) echo 'selected';?> >11</option>
<option value="12" <?php if ($_POST['binding_len'] == 12) echo 'selected';?> >12</option>
<option value="13" <?php if ($_POST['binding_len'] == 13) echo 'selected';?> >13</option>
<option value="14" <?php if ($_POST['binding_len'] == 14) echo 'selected';?> >14</option>
<option value="15" <?php if ($_POST['binding_len'] == 15) echo 'selected';?> >15</option>
<option value="16" <?php if ($_POST['binding_len'] == 16) echo 'selected';?> >16</option>
<option value="17" <?php if ($_POST['binding_len'] == 17) echo 'selected';?> >17</option>
<option value="18" <?php if ($_POST['binding_len'] == 18) echo 'selected';?> >18</option>
<option value="19" <?php if ($_POST['binding_len'] == 19) echo 'selected';?> >19</option>
<option value="20" <?php if ($_POST['binding_len'] == 20) echo 'selected';?> >20</option>
<option value="21" <?php if ($_POST['binding_len'] == 21) echo 'selected';?> >21</option>
<option value="22" <?php if ($_POST['binding_len'] == 22) echo 'selected';?> >22</option>
<option value="23" <?php if ($_POST['binding_len'] == 23) echo 'selected';?> >23</option>
<option value="24" <?php if ($_POST['binding_len'] == 24) echo 'selected';?> >24</option>
<option value="25" <?php if ($_POST['binding_len'] == 25) echo 'selected';?> >25</option>
<option value="26" <?php if ($_POST['binding_len'] == 26) echo 'selected';?> >26</option>
<option value="27" <?php if ($_POST['binding_len'] == 27) echo 'selected';?> >27</option>
<option value="28" <?php if ($_POST['binding_len'] == 28) echo 'selected';?> >28</option>
<option value="29" <?php if ($_POST['binding_len'] == 29) echo 'selected';?> >29</option>
<option value="30" <?php if ($_POST['binding_len'] == 30) echo 'selected';?> >30</option>
<option value="31" <?php if ($_POST['binding_len'] == 31) echo 'selected';?> >31</option>
<option value="32" <?php if ($_POST['binding_len'] == 32) echo 'selected';?> >32</option>
<option value="33" <?php if ($_POST['binding_len'] == 33) echo 'selected';?> >33</option>
<option value="34" <?php if ($_POST['binding_len'] == 34) echo 'selected';?> >34</option>
<option value="35" <?php if ($_POST['binding_len'] == 35) echo 'selected';?> >35</option>
<option value="36" <?php if ($_POST['binding_len'] == 36) echo 'selected';?> >36</option>
<option value="37" <?php if ($_POST['binding_len'] == 37) echo 'selected';?> >37</option>
<option value="38" <?php if ($_POST['binding_len'] == 38) echo 'selected';?> >38</option>
<option value="39" <?php if ($_POST['binding_len'] == 39) echo 'selected';?> >39</option>
<option value="40" <?php if ($_POST['binding_len'] == 40) echo 'selected';?> >40</option>
<option value="-1" <?php if (!isset($_POST['binding_len']) || $_POST['binding_len'] < 0) echo 'selected';?> >Any</option>
</select>
</li></ul>
<br>
<!--<img src="images/binding_sites/single-binding-site.JPG" /> -->

<br>
<input type="radio" name="binding_site" value="2" <?php if ($_POST['binding_site'] == 2) echo 'checked';?> /> 
<font  color="#FF0000">Double-box</font><br>
<ul>
<li>
The length of the first box: 
<select name="binding_len_1">
<option value="2" <?php if ($_POST['binding_len_1'] == 2) echo 'selected';?> > 2</option>
<option value="3" <?php if ($_POST['binding_len_1'] == 3) echo 'selected';?> > 3</option>
<option value="4" <?php if ($_POST['binding_len_1'] == 4) echo 'selected';?> > 4</option>
<option value="5" <?php if ($_POST['binding_len_1'] == 5) echo 'selected';?> > 5</option>
<option value="6" <?php if ($_POST['binding_len_1'] == 6) echo 'selected';?> > 6</option>
<option value="7" <?php if ($_POST['binding_len_1'] == 7) echo 'selected';?> > 7</option>
<option value="8" <?php if ($_POST['binding_len_1'] == 8) echo 'selected';?> > 8</option>
<option value="9" <?php if ($_POST['binding_len_1'] == 9) echo 'selected';?> > 9</option>
<option value="10" <?php if ($_POST['binding_len_1'] == 10) echo 'selected';?> >10</option>
<option value="11" <?php if ($_POST['binding_len_1'] == 11) echo 'selected';?> >11</option>
<option value="12" <?php if ($_POST['binding_len_1'] == 12) echo 'selected';?> >12</option>
<option value="13" <?php if ($_POST['binding_len_1'] == 13) echo 'selected';?> >13</option>
<option value="14" <?php if ($_POST['binding_len_1'] == 14) echo 'selected';?> >14</option>
<option value="15" <?php if ($_POST['binding_len_1'] == 15) echo 'selected';?> >15</option>
<option value="16" <?php if ($_POST['binding_len_1'] == 16) echo 'selected';?> >16</option>
<option value="17" <?php if ($_POST['binding_len_1'] == 17) echo 'selected';?> >17</option>
<option value="18" <?php if ($_POST['binding_len_1'] == 18) echo 'selected';?> >18</option>
<option value="19" <?php if ($_POST['binding_len_1'] == 19) echo 'selected';?> >19</option>
<option value="20" <?php if ($_POST['binding_len_1'] == 20) echo 'selected';?> >20</option>
<option value="-1" <?php if (!isset($_POST['binding_len_1']) || $_POST['binding_len'] < 0) echo 'selected';?> >Any</option>
</select>
</li>
<li>
The length of the gap between the two boxes: 
<select name="binding_len_gap">
<option value="1" <?php if ($_POST['binding_len_gap'] == 1) echo 'selected';?> > 1</option>
<option value="2" <?php if ($_POST['binding_len_gap'] == 2) echo 'selected';?> > 2</option>
<option value="3" <?php if ($_POST['binding_len_gap'] == 3) echo 'selected';?> > 3</option>
<option value="4" <?php if ($_POST['binding_len_gap'] == 4) echo 'selected';?> > 4</option>
<option value="5" <?php if ($_POST['binding_len_gap'] == 5) echo 'selected';?> > 5</option>
<option value="6" <?php if ($_POST['binding_len_gap'] == 6) echo 'selected';?> > 6</option>
<option value="7" <?php if ($_POST['binding_len_gap'] == 7) echo 'selected';?> > 7</option>
<option value="8" <?php if ($_POST['binding_len_gap'] == 8) echo 'selected';?> > 8</option>
<option value="9" <?php if ($_POST['binding_len_gap'] == 9) echo 'selected';?> > 9</option>
<option value="10" <?php if ($_POST['binding_len_gap'] == 10) echo 'selected';?> >10</option>
<option value="11" <?php if ($_POST['binding_len_gap'] == 11) echo 'selected';?> >11</option>
<option value="12" <?php if ($_POST['binding_len_gap'] == 12) echo 'selected';?> >12</option>
<option value="13" <?php if ($_POST['binding_len_gap'] == 13) echo 'selected';?> >13</option>
<option value="14" <?php if ($_POST['binding_len_gap'] == 14) echo 'selected';?> >14</option>
<option value="15" <?php if ($_POST['binding_len_gap'] == 15) echo 'selected';?> >15</option>
<option value="-1" <?php if (!isset($_POST['binding_len_gap']) || $_POST['binding_len_gap'] < 0) echo 'selected';?> >Any</option>
</select>
</li>
<li>
The length of the second box: 
<select name="binding_len_2">
<option value="1" <?php if ($_POST['binding_len_2'] == 1) echo 'selected';?> > 1</option>
<option value="2" <?php if ($_POST['binding_len_2'] == 2) echo 'selected';?> > 2</option>
<option value="3" <?php if ($_POST['binding_len_2'] == 3) echo 'selected';?> > 3</option>
<option value="4" <?php if ($_POST['binding_len_2'] == 4) echo 'selected';?> > 4</option>
<option value="5" <?php if ($_POST['binding_len_2'] == 5) echo 'selected';?> > 5</option>
<option value="6" <?php if ($_POST['binding_len_2'] == 6) echo 'selected';?> > 6</option>
<option value="7" <?php if ($_POST['binding_len_2'] == 7) echo 'selected';?> > 7</option>
<option value="8" <?php if ($_POST['binding_len_2'] == 8) echo 'selected';?> > 8</option>
<option value="9" <?php if ($_POST['binding_len_2'] == 9) echo 'selected';?> > 9</option>
<option value="10" <?php if ($_POST['binding_len_2'] == 10) echo 'selected';?> >10</option>
<option value="11" <?php if ($_POST['binding_len_2'] == 11) echo 'selected';?> >11</option>
<option value="12" <?php if ($_POST['binding_len_2'] == 12) echo 'selected';?> >12</option>
<option value="13" <?php if ($_POST['binding_len_2'] == 13) echo 'selected';?> >13</option>
<option value="14" <?php if ($_POST['binding_len_2'] == 14) echo 'selected';?> >14</option>
<option value="15" <?php if ($_POST['binding_len_2'] == 15) echo 'selected';?> >15</option>
<option value="16" <?php if ($_POST['binding_len_2'] == 16) echo 'selected';?> >16</option>
<option value="17" <?php if ($_POST['binding_len_2'] == 17) echo 'selected';?> >17</option>
<option value="18" <?php if ($_POST['binding_len_2'] == 18) echo 'selected';?> >18</option>
<option value="19" <?php if ($_POST['binding_len_2'] == 19) echo 'selected';?> >19</option>
<option value="20" <?php if ($_POST['binding_len_2'] == 20) echo 'selected';?> >20</option>
<option value="-1" <?php if (!isset($_POST['binding_len_2']) || $_POST['binding_len_2'] < 0) echo 'selected';?> >Any</option>
</select>
</li>
</ul>

<br><br>&nbsp;

</li>


<li>
<b>Description of your protein sequences</b> (optional): <br>
<textarea name="description" cols="60" rows="3"><?php if ($_POST['cmd'] == 'Submit') echo $_POST['description'];?></textarea>
</li>

</ul>


<font color="#3399FF" size="+2"><b>Computational preferences</b></font>
<ul>
<li><b>Would you like <i>Quick Search</i> or <i>Full Search</i>?</b><br>
<input  type="radio" name="time_limit" value="10" <?php if ($_POST['time_limit'] == 10) echo 'checked';?> /> Quick Search. 
<i>With this option, it will take about 10 minutes but you may miss some motifs.</i><br>
<input  type="radio" name="time_limit" value="480" <?php if (!isset($_POST['time_limit']) || $_POST['time_limit'] == 480) echo 'checked';?> /> Full Search. 
<i>With this option, it can take up to about 4 hours but you will find most of motifs.</i><br>
</li>
<!--
<li><b>Search model</b>:<br>
<input  type="radio" name="model" value="1" <?php if ($_POST['model'] == 1) echo 'checked';?> /> Pattern-based model <br>
<input  type="radio" name="model" value="2" <?php if ($_POST['model'] == 2) echo 'checked';?> /> Statistics-based model <br>
<input  type="radio" name="model" value="3" <?php if (!isset($_POST['model']) || $_POST['model'] == 3) echo 'checked';?> /> Mixing pattern-based and statistics-based model <i>(recommended)</i><br>
</li>
<li><b>Computational time limit</b>: <br>
<table width="100%">
<tr>
<td width="50%">
<input  type="radio" name="time_limit" value="1" <?php if ($_POST['time_limit'] == 1) echo 'checked';?> /> Instantly <br>
<input  type="radio" name="time_limit" value="10" <?php if ($_POST['time_limit'] == 10) echo 'checked';?> /> Within 10 minutes <br>
<input  type="radio" name="time_limit" value="30" <?php if ($_POST['time_limit'] == 30) echo 'checked';?> /> Within 30 minutes <br>
<input  type="radio" name="time_limit" value="60" <?php if ($_POST['time_limit'] == 60) echo 'checked';?> /> Within 1 hour <br>
<input  type="radio" name="time_limit" value="120" <?php if (!isset($_POST['time_limit']) || $_POST['time_limit'] == 120) echo 'checked';?>/> Within 2 hours <i>(recommended)</i><br>
<input  type="radio" name="time_limit" value="240" <?php if ($_POST['time_limit'] == 240) echo 'checked';?> /> Within 4 hours <br>
</td>
<td width="50%">
<input  type="radio" name="time_limit" value="480" <?php if ($_POST['time_limit'] == 480) echo 'checked';?> /> Within 8 hours <br>
<input  type="radio" name="time_limit" value="1440" <?php if ($_POST['time_limit'] == 1440) echo 'checked';?> /> Within 1 day <br>
<input  type="radio" name="time_limit" value="2880" <?php if ($_POST['time_limit'] == 2880) echo 'checked';?> /> Within 2 days <br>
<input  type="radio" name="time_limit" value="5760" <?php if ($_POST['time_limit'] == 5760) echo 'checked';?> /> Within 4 days <br>
<input  type="radio" name="time_limit" value="0" <?php if (isset($_POST['time_limit']) && $_POST['time_limit'] == 0) echo 'checked';?>/> No limit <br>
</td>
</tr></table>
</li>
-->
</ul>

<!--
<hr>
<font color="#3399FF" size="+2"><b>Your contact information</b></font>
<?php
if ($_POST['cmd'] == 'Submit' && $captcha_passed && $isValidData && !$emailDeliverySucc && $timeLimit != 1) {
	echo '<br><font color="#FF0000">We can not send to the email you provided. Please check your email.</font><br>';
} 
?>
<ul>
<li><b>Email</b>: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="email" id="email" size="30" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['email'];?>"/> 
<font color="#FF0000">*(required)</font>
</li>
<li>
<b>First name</b>: 
<input type="text" name="firstName" id="firstName" size="20" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['firstName'];?>"/> 
<font color="#FF0000">*(required)</font>
</li>
<li><b>Last name</b>: 
<input type="text" name="lastName" id="lastName" size="20" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['lastName'];?>"/> 
<font color="#FF0000">*(required)</font>
</li>
<li><b>Phone</b>: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="phone" size="20" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['phone'];?>"/> (optional)
</li>
<li><b>Organization</b>: 
<input type="text" name="organization" size="35" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['organization'];?>"/> (optional)
</li>
</ul>
-->

<!--
<hr>
<font color="#3399FF" size="+2"><b>Human Verification</b></font>
<br>Enter the text from the image below, <font color="#FF0000">seperate by space</font>. This function will prevent robot programs
from automatically submitting malicious data that can harm our website.<br>
<?php
if ($_POST['cmd'] == 'Submit' && !$captcha_passed ) {
	echo '<br><font color="#FF0000">You did not answer the verification question correctly. Please answer it again.</font><br>';} 
?>
<center>
<?php //echo recaptcha_get_html($CAPTCHA_PublicKey); ?>
</center>
<hr>
-->

<br>
<center>
<script language="JavaScript">
function checkSubmission() {
	var email = document.getElementById('email');
	var firstName = document.getElementById('firstName');
	var lastName = document.getElementById('lastName');
	var dna_seqs_fasta = document.getElementById('dna_seqs_fasta');
	if (!isValidEmail(email.value)) { 
		alert('Invalid email ' + email.value); 
		return false;
	}		
	if (firstName.value.length < 1 || firstName.value.length > 30) { 
		alert('Invalid first name'); 
		return false;
	}
	if (lastName.value.length < 1 || lastName.value.length > 30) { 
		alert('Invalid last name'); 
		return false;
	}	 
	if (dna_seqs_fasta.value.length < 50) { 
		alert('Invalid input DNA sequences'); 
		return false;
	}
	if (!confirm('Are you sure you want to submit your request?')) {
		return false;
	}	
	return true;
}
</script>
<input type="submit" name="cmd" value="Submit" onClick="if (!checkSubmission()) return false;"/>
<br>
<!--<i>(Important: click the links below first, then click submit button. Thank you!)</i>-->
</center>
<br>
</form>

<?php if (false && $ShowGoogleAd) { ?>
<br>
<center>
&nbsp;
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* MyfifthAd */
google_ad_slot = "0132043955";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>
<?php } ?>
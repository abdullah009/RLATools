
<table align="center">
    <td id="submission">
		<?php
            if ( isset($_POST['cmd_changepass']) && !$isValidPassword ) {
                echo '<b><font color="#ff0000">Email address or current password is incorrect.</font></b><br>';
            } 
        ?>

    	<p>Please enter your email address and current password to set your new password.</p>
    </td>
</table>
	
<table align="center">
	<td>
        <form method="post" action="index.php" id="formsubmission">
        <input type="hidden" name="page" value="submissionhistory" />
        <input type="hidden" name="cmd" value="change_password" />
            <table border="1" >
            	<tr>
                	<td>
                        <font size="+1"> <b><center>Change password form</center></b></font><br>
                        <table>
                        	<tr>
                        		<td>Email:
                                </td>
                        		<td><input type="text" size="40" name="email"id="email" value="<?php if (isset($_POST['email'])) echo $_POST['email']; else if (isset($_SESSION['userEmail'])) echo $_SESSION['userEmail'];?>" /> 
                            	</td>
                        	</tr>
                        	<tr>
                        		<td>Current password:
                                </td>
                        		<td><input type="password" size="30" name="password" id="password" value=""/> 
                                </td>
                        	</tr>
                        	<tr>
                            	<td>New password:
                                </td>
           		                <td><input type="password" size="30" name="password_new" id="password_new" value=""/>
                                </td>
                        	</tr>
                        	<tr>
                            	<td>New password(again):
                                </td>
                        		<td><input type="password" size="30" name="password_new_again" id="password_new_again" value=""/>
                            	</td>
                        	</tr>
                        	<tr>
                        		<td>
                                </td>
                        		<td><input type="submit" name="cmd_changepass" value="Submit" onClick="if (!checkSubmission()) return false;" />
                        			<input type="submit" name="cmd_changepass" value="Cancel"/>
                                </td>
                        	</tr>
                        </table>
                    </td>
                </tr>           
            </table>
            
            <script language="JavaScript">
				function checkSubmission() 
				{
					var email = document.getElementById('email');
					var password_new = document.getElementById('password_new');
					var password_new_again = document.getElementById('password_new_again');
					
					if (password_new.value != password_new_again.value) 
					{
						alert('New password and new confirmed password DO NOT match'); 
						return false;	
					}	
					if (!isValidEmail(email.value)) 
					{ 
						alert('Invalid email ' + email.value + '. Make sure that there are NO SPACE CHARACTERS at the end and/or beginning of the email');  
						return false;
					}
					if (!confirm('Are you sure that your email and current password are correct?')) 
					{
						return false;
					}
					
					return true;
				}
            </script>
        </form>
    </td>
</table>
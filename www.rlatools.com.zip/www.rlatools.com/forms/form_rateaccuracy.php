<?php
	$link = mysql_connect($sql_host, $sql_username, $sql_password);
	if (!mysql_select_db($sql_database, $link)) die ();
	$sqlQuery = 'SELECT `rateAccuracy`, `commment` FROM `motifseq_query` WHERE `queryID` = '.$queryID;
	$result = mysql_query($sqlQuery, $link);
	$row = mysql_fetch_array($result);	
	$rateAccuracy  = $row['rateAccuracy'];
	$commment  = $row['commment'];
	mysql_close($link);
?>

<form method="post" action="index.php" id="formSub">
<input type="hidden" name="page" value="<?php echo $htmlPageName; ?>" />
<input type="hidden" name="cmd" value="rate_accuracy" />
<input type="hidden" name="queryID" value="<?php echo $queryID; ?>" />
<input type="hidden" name="cd" value="<?php echo SecurityEncodeFunc("$queryID"); ?>" />


<font color="#3399FF" size="+2"><b>Result evaluation</b></font>
<br><i>In order to improve our tools, please let us know what you think about the results. Thank you.</i>
<ul>

<li>
<b>Accuracy</b> <font color="#FF0000">*(required)</font>:  
<table>
<tr valign="middle" align="center">
<td>Not<br>accurate</td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
<td> </td>
<td>Very<br>accurate</td>
</tr>
<tr valign="middle" align="center">
<td>1</td>
<td>2</td>
<td>3</td>
<td>4</td>
<td>5</td>
<td>6</td>
<td>7</td>
<td>8</td>
<td>9</td>
<td>10</td>
</tr>
<tr valign="middle" align="center">
<td><input name="rate_accuracy" type="radio" value="1" <?php if ($rateAccuracy ==1) echo 'checked';?> /> </td>
<td><input name="rate_accuracy" type="radio" value="2" <?php if ($rateAccuracy ==2) echo 'checked';?> /></td>
<td><input name="rate_accuracy" type="radio" value="3" <?php if ($rateAccuracy ==3) echo 'checked';?> /></td>
<td><input name="rate_accuracy" type="radio" value="4" <?php if ($rateAccuracy ==4) echo 'checked';?> /></td>
<td><input name="rate_accuracy" type="radio" value="5" <?php if ($rateAccuracy ==5) echo 'checked';?> /></td>
<td><input name="rate_accuracy" type="radio" value="6" <?php if ($rateAccuracy ==6) echo 'checked';?> /> </td>
<td><input name="rate_accuracy" type="radio" value="7" <?php if ($rateAccuracy ==7) echo 'checked';?> /></td>
<td><input name="rate_accuracy" type="radio" value="8" <?php if ($rateAccuracy ==8) echo 'checked';?> /></td>
<td><input name="rate_accuracy" type="radio" value="9" <?php if ($rateAccuracy ==9) echo 'checked';?> /></td>
<td><input name="rate_accuracy" type="radio" value="10" <?php if ($rateAccuracy ==10) echo 'checked';?> /></td>
</tr>
</table>
<br>&nbsp;
</li>

<li>
<b>Other comments, suggestions, etc</b> (optional): <br>
<textarea name="commment" cols="80" rows="6"><?php echo $commment; ?></textarea>
</li>

</ul>

<br>
<center>
<input type="submit" name="cmd_submit" value="Submit evaluation"/> &nbsp; 
<input type="submit" name="cmd_cancel" value="Cancel"/>
</center>
<br>

</form>
<?php
	$link = mysql_connect($sql_host, $sql_username, $sql_password);
	if (!mysql_select_db($sql_database, $link)) die ();

	$sqlQuery = 'SELECT `timeLimit`, `quorumPercent`,
				`bindingLen1Min`, `bindingLen1Max`, 
				`bindingGapMin`, `bindingGapMax`, 
				`bindingLen2Min`, `bindingLen2Max`, 				
				`seqsDescription`
				FROM `motifseq_query`
				WHERE `queryID` = '.$queryID;
	
	$result = mysql_query($sqlQuery, $link);
	$row = mysql_fetch_array($result);	
	$timeLimit  = $row['timeLimit'];
	$quorumPercent  = $row['quorumPercent'];
	$bindingLen1Min  = $row['bindingLen1Min'];
	$bindingLen1Max  = $row['bindingLen1Max'];
	$bindingGapMin  = $row['bindingGapMin'];
	$bindingGapMax  = $row['bindingGapMax'];
	$bindingLen2Min  = $row['bindingLen2Min'];
	$bindingLen2Max  = $row['bindingLen2Max'];
	$seqsDescription = $row['seqsDescription'];
	
	$isSingleBox = false;
	if ($bindingLen2Min == 0 && $bindingLen2Max == 0 && isset($bindingLen2Min)) $isSingleBox = true;
	
	$isSingleBoxLenAny = true;
	if ($isSingleBox && $bindingLen1Min == $bindingLen1Max && 5 <= $bindingLen1Min && $bindingLen1Min <= 40) {
		$isSingleBoxLenAny = false;
	}
		
	$isDoubleBoxLen1Any = true;
	if (!$isSingleBox && $bindingLen1Min == $bindingLen1Max 
		&& 5 <= $bindingLen1Min && $bindingLen1Min <= 40) $isDoubleBoxLen1Any =false;

	$isDoubleBoxGapAny = true;
	if (!$isSingleBox && $bindingGapMin == $bindingGapMax 
		&& 1 <= $bindingGapMin && $bindingGapMin <= 40) $isDoubleBoxGapAny = false;

	$isDoubleBoxLen2Any = true;
	if (!$isSingleBox && $bindingLen2Min == $bindingLen2Max 
		&& 5 <= $bindingLen2Min && $bindingLen2Min <= 40) $isDoubleBoxLen2Any = false;

		
	mysql_close($link);
?>

<form method="post" action="index.php" id="formSub">
<input type="hidden" name="page" value="<?php echo $htmlPageName; ?>" />
<input type="hidden" name="cmd" value="change_params" />
<input type="hidden" name="queryID" value="<?php echo $queryID; ?>" />
<input type="hidden" name="cd" value="<?php echo SecurityEncodeFunc("$queryID"); ?>" />


<font color="#3399FF" size="+2"><b>Search with different parameters</b></font>

<ul>

<li>
<b>The percentage of protein sequences containing motifs</b> <font color="#FF0000">*(required)</font>:  
<select name="quorum_percent">
<option value="5" <?php if ($quorumPercent == 5) echo 'selected';?> > 5</option>
<option value="10" <?php if ($quorumPercent == 10) echo 'selected';?> > 10</option>
<option value="20" <?php if ($quorumPercent == 20) echo 'selected';?> > 20</option>
<option value="30" <?php if ($quorumPercent == 30) echo 'selected';?> > 30</option>
<option value="35" <?php if ($quorumPercent == 35) echo 'selected';?> > 35</option>
<option value="40" <?php if ($quorumPercent == 40) echo 'selected';?> > 40</option>
<option value="45" <?php if ($quorumPercent == 45) echo 'selected';?> > 45</option>
<option value="50" <?php if ($quorumPercent == 50) echo 'selected';?> > 50</option>
<option value="55" <?php if ($quorumPercent == 55) echo 'selected';?> > 55</option>
<option value="60" <?php if ($quorumPercent == 60) echo 'selected';?> > 60</option>
<option value="65" <?php if ($quorumPercent == 65) echo 'selected';?> > 65</option>
<option value="70" <?php if ($quorumPercent == 70) echo 'selected';?> > 70</option>
<option value="75" <?php if (!isset($quorumPercent) || $quorumPercent== 75) echo 'selected';?> > 75</option>
<option value="80" <?php if ($quorumPercent == 80) echo 'selected';?> > 80</option>
<option value="85" <?php if ($quorumPercent == 85) echo 'selected';?> > 85</option>
<option value="90" <?php if ($quorumPercent == 90) echo 'selected';?> > 90</option>
<option value="95" <?php if ($quorumPercent == 95) echo 'selected';?> > 95</option>
<option value="100" <?php if ($quorumPercent == 100) echo 'selected';?> > 100</option>
</select>
<br><br>&nbsp;
</li>

<li>
<b>Please let us know about the form of motifs</b> <font color="#FF0000">*(required)</font>:<br>
<table><tr valign="top" align="left"><td width="50%" valign="middle">
<input type="radio" name="binding_site" value="1" <?php if ($isSingleBox) echo 'checked';?> /> 
<font color="#FF0000">Single-box</font><br>
<ul><li>
The length of the box (motif length): 
<select name="binding_len">
<option value="4"  <?php if ($bindingLen1Min == 4 && !$isSingleBoxLenAny) echo 'selected';?> > 4</option>
<option value="5"  <?php if ($bindingLen1Min == 5 && !$isSingleBoxLenAny) echo 'selected';?> > 5</option>
<option value="6"  <?php if ($bindingLen1Min == 6 && !$isSingleBoxLenAny) echo 'selected';?> > 6</option>
<option value="7"  <?php if ($bindingLen1Min == 7 && !$isSingleBoxLenAny) echo 'selected';?> > 7</option>
<option value="8"  <?php if ($bindingLen1Min == 8 && !$isSingleBoxLenAny) echo 'selected';?> > 8</option>
<option value="9"  <?php if ($bindingLen1Min == 9 && !$isSingleBoxLenAny) echo 'selected';?> > 9</option>
<option value="10" <?php if ($bindingLen1Min == 10 && !$isSingleBoxLenAny) echo 'selected';?> >10</option>
<option value="11" <?php if ($bindingLen1Min == 11 && !$isSingleBoxLenAny) echo 'selected';?> >11</option>
<option value="12" <?php if ($bindingLen1Min == 12 && !$isSingleBoxLenAny) echo 'selected';?> >12</option>
<option value="13" <?php if ($bindingLen1Min == 13 && !$isSingleBoxLenAny) echo 'selected';?> >13</option>
<option value="14" <?php if ($bindingLen1Min == 14 && !$isSingleBoxLenAny) echo 'selected';?> >14</option>
<option value="15" <?php if ($bindingLen1Min == 15 && !$isSingleBoxLenAny) echo 'selected';?> >15</option>
<option value="16" <?php if ($bindingLen1Min == 16 && !$isSingleBoxLenAny) echo 'selected';?> >16</option>
<option value="17" <?php if ($bindingLen1Min == 17 && !$isSingleBoxLenAny) echo 'selected';?> >17</option>
<option value="18" <?php if ($bindingLen1Min == 18 && !$isSingleBoxLenAny) echo 'selected';?> >18</option>
<option value="19" <?php if ($bindingLen1Min == 19 && !$isSingleBoxLenAny) echo 'selected';?> >19</option>
<option value="20" <?php if ($bindingLen1Min == 20 && !$isSingleBoxLenAny) echo 'selected';?> >20</option>
<option value="21" <?php if ($bindingLen1Min == 21 && !$isSingleBoxLenAny) echo 'selected';?> >21</option>
<option value="22" <?php if ($bindingLen1Min == 22 && !$isSingleBoxLenAny) echo 'selected';?> >22</option>
<option value="23" <?php if ($bindingLen1Min == 23 && !$isSingleBoxLenAny) echo 'selected';?> >23</option>
<option value="24" <?php if ($bindingLen1Min == 24 && !$isSingleBoxLenAny) echo 'selected';?> >24</option>
<option value="25" <?php if ($bindingLen1Min == 25 && !$isSingleBoxLenAny) echo 'selected';?> >25</option>
<option value="26" <?php if ($bindingLen1Min == 26 && !$isSingleBoxLenAny) echo 'selected';?> >26</option>
<option value="27" <?php if ($bindingLen1Min == 27 && !$isSingleBoxLenAny) echo 'selected';?> >27</option>
<option value="28" <?php if ($bindingLen1Min == 28 && !$isSingleBoxLenAny) echo 'selected';?> >28</option>
<option value="29" <?php if ($bindingLen1Min == 29 && !$isSingleBoxLenAny) echo 'selected';?> >29</option>
<option value="30" <?php if ($bindingLen1Min == 30 && !$isSingleBoxLenAny) echo 'selected';?> >30</option>
<option value="31" <?php if ($bindingLen1Min == 31 && !$isSingleBoxLenAny) echo 'selected';?> >31</option>
<option value="32" <?php if ($bindingLen1Min == 32 && !$isSingleBoxLenAny) echo 'selected';?> >32</option>
<option value="33" <?php if ($bindingLen1Min == 33 && !$isSingleBoxLenAny) echo 'selected';?> >33</option>
<option value="34" <?php if ($bindingLen1Min == 34 && !$isSingleBoxLenAny) echo 'selected';?> >34</option>
<option value="35" <?php if ($bindingLen1Min == 35 && !$isSingleBoxLenAny) echo 'selected';?> >35</option>
<option value="36" <?php if ($bindingLen1Min == 36 && !$isSingleBoxLenAny) echo 'selected';?> >36</option>
<option value="37" <?php if ($bindingLen1Min == 37 && !$isSingleBoxLenAny) echo 'selected';?> >37</option>
<option value="38" <?php if ($bindingLen1Min == 38 && !$isSingleBoxLenAny) echo 'selected';?> >38</option>
<option value="39" <?php if ($bindingLen1Min == 39 && !$isSingleBoxLenAny) echo 'selected';?> >39</option>
<option value="40" <?php if ($bindingLen1Min == 40 && !$isSingleBoxLenAny) echo 'selected';?> >40</option>
<option value="-1" <?php if ($isSingleBoxLenAny) echo 'selected';?> >Any</option>
</select>
</li></ul>
</td>
<td valign="top">
<!-- <img src="images/binding_sites/single-binding-site.JPG" width="300px" /> -->
</td>
</tr>

<tr valign="top" align="left"><td width="50%" valign="middle">
<input type="radio" name="binding_site" value="2" <?php if (!$isSingleBox) echo 'checked';?> /> 
<font color="#FF0000">Double-box</font><br>
<ul>
<li>
The length of the first box: 
<select name="binding_len_1">
<option value="2" <?php if ($bindingLen1Min == 2 && !$isDoubleBoxLen1Any) echo 'selected';?> > 2</option>
<option value="3" <?php if ($bindingLen1Min == 3 && !$isDoubleBoxLen1Any) echo 'selected';?> > 3</option>
<option value="4" <?php if ($bindingLen1Min == 4 && !$isDoubleBoxLen1Any) echo 'selected';?> > 4</option>
<option value="5" <?php if ($bindingLen1Min == 5 && !$isDoubleBoxLen1Any) echo 'selected';?> > 5</option>
<option value="6" <?php if ($bindingLen1Min == 6 && !$isDoubleBoxLen1Any) echo 'selected';?> > 6</option>
<option value="7" <?php if ($bindingLen1Min == 7 && !$isDoubleBoxLen1Any ) echo 'selected';?> > 7</option>
<option value="8" <?php if ($bindingLen1Min == 8 && !$isDoubleBoxLen1Any) echo 'selected';?> > 8</option>
<option value="9" <?php if ($bindingLen1Min == 9 && !$isDoubleBoxLen1Any) echo 'selected';?> > 9</option>
<option value="10" <?php if ($bindingLen1Min == 10 && !$isDoubleBoxLen1Any) echo 'selected';?> >10</option>
<option value="11" <?php if ($bindingLen1Min == 11 && !$isDoubleBoxLen1Any) echo 'selected';?> >11</option>
<option value="12" <?php if ($bindingLen1Min == 12 && !$isDoubleBoxLen1Any) echo 'selected';?> >12</option>
<option value="13" <?php if ($bindingLen1Min == 13 && !$isDoubleBoxLen1Any) echo 'selected';?> >13</option>
<option value="14" <?php if ($bindingLen1Min == 14 && !$isDoubleBoxLen1Any) echo 'selected';?> >14</option>
<option value="15" <?php if ($bindingLen1Min == 15 && !$isDoubleBoxLen1Any) echo 'selected';?> >15</option>
<option value="16" <?php if ($bindingLen1Min == 16 && !$isDoubleBoxLen1Any) echo 'selected';?> >16</option>
<option value="17" <?php if ($bindingLen1Min == 17 && !$isDoubleBoxLen1Any) echo 'selected';?> >17</option>
<option value="18" <?php if ($bindingLen1Min == 18 && !$isDoubleBoxLen1Any) echo 'selected';?> >18</option>
<option value="19" <?php if ($bindingLen1Min == 19 && !$isDoubleBoxLen1Any) echo 'selected';?> >19</option>
<option value="20" <?php if ($bindingLen1Min == 20 && !$isDoubleBoxLen1Any) echo 'selected';?> >20</option>
<option value="-1" <?php if ($isDoubleBoxLen1Any) echo 'selected';?> >Any</option>
</select>
</li>
<li>
The length of the gap between the two boxes: 
<select name="binding_len_gap">
<option value="1" <?php if ($bindingGapMin == 1 && !$isDoubleBoxGapAny) echo 'selected';?> > 1</option>
<option value="2" <?php if ($bindingGapMin == 2 && !$isDoubleBoxGapAny) echo 'selected';?> > 2</option>
<option value="3" <?php if ($bindingGapMin == 3 && !$isDoubleBoxGapAny) echo 'selected';?> > 3</option>
<option value="4" <?php if ($bindingGapMin == 4 && !$isDoubleBoxGapAny) echo 'selected';?> > 4</option>
<option value="5" <?php if ($bindingGapMin == 5 && !$isDoubleBoxGapAny) echo 'selected';?> > 5</option>
<option value="6" <?php if ($bindingGapMin == 6 && !$isDoubleBoxGapAny) echo 'selected';?> > 6</option>
<option value="7" <?php if ($bindingGapMin == 7 && !$isDoubleBoxGapAny) echo 'selected';?> > 7</option>
<option value="8" <?php if ($bindingGapMin == 8 && !$isDoubleBoxGapAny) echo 'selected';?> > 8</option>
<option value="9" <?php if ($bindingGapMin == 9 && !$isDoubleBoxGapAny) echo 'selected';?> > 9</option>
<option value="10" <?php if ($bindingGapMin == 10 && !$isDoubleBoxGapAny) echo 'selected';?> >10</option>
<option value="11" <?php if ($bindingGapMin == 11 && !$isDoubleBoxGapAny) echo 'selected';?> >11</option>
<option value="12" <?php if ($bindingGapMin == 12 && !$isDoubleBoxGapAny) echo 'selected';?> >12</option>
<option value="13" <?php if ($bindingGapMin == 13 && !$isDoubleBoxGapAny) echo 'selected';?> >13</option>
<option value="14" <?php if ($bindingGapMin == 14 && !$isDoubleBoxGapAny) echo 'selected';?> >14</option>
<option value="15" <?php if ($bindingGapMin == 15 && !$isDoubleBoxGapAny) echo 'selected';?> >15</option>
<option value="-1" <?php if ($isDoubleBoxGapAny) echo 'selected';?> >Any</option>
</select>
</li>
<li>
The length of the second box: 
<select name="binding_len_2">
<option value="1" <?php if ($bindingLen2Min == 1 && !$isDoubleBoxLen2Any) echo 'selected';?> > 1</option>
<option value="2" <?php if ($bindingLen2Min == 2 && !$isDoubleBoxLen2Any) echo 'selected';?> > 2</option>
<option value="3" <?php if ($bindingLen2Min == 3 && !$isDoubleBoxLen2Any) echo 'selected';?> > 3</option>
<option value="4" <?php if ($bindingLen2Min == 4 && !$isDoubleBoxLen2Any) echo 'selected';?> > 4</option>
<option value="5" <?php if ($bindingLen2Min == 5 && !$isDoubleBoxLen2Any) echo 'selected';?> > 5</option>
<option value="6" <?php if ($bindingLen2Min == 6 && !$isDoubleBoxLen2Any) echo 'selected';?> > 6</option>
<option value="7" <?php if ($bindingLen2Min == 7 && !$isDoubleBoxLen2Any) echo 'selected';?> > 7</option>
<option value="8" <?php if ($bindingLen2Min == 8 && !$isDoubleBoxLen2Any) echo 'selected';?> > 8</option>
<option value="9" <?php if ($bindingLen2Min == 9 && !$isDoubleBoxLen2Any) echo 'selected';?> > 9</option>
<option value="10" <?php if ($bindingLen2Min == 10 && !$isDoubleBoxLen2Any) echo 'selected';?> >10</option>
<option value="11" <?php if ($bindingLen2Min == 11 && !$isDoubleBoxLen2Any) echo 'selected';?> >11</option>
<option value="12" <?php if ($bindingLen2Min == 12 && !$isDoubleBoxLen2Any) echo 'selected';?> >12</option>
<option value="13" <?php if ($bindingLen2Min == 13 && !$isDoubleBoxLen2Any) echo 'selected';?> >13</option>
<option value="14" <?php if ($bindingLen2Min == 14 && !$isDoubleBoxLen2Any) echo 'selected';?> >14</option>
<option value="15" <?php if ($bindingLen2Min == 15 && !$isDoubleBoxLen2Any) echo 'selected';?> >15</option>
<option value="16" <?php if ($bindingLen2Min == 16 && !$isDoubleBoxLen2Any) echo 'selected';?> >16</option>
<option value="17" <?php if ($bindingLen2Min == 17 && !$isDoubleBoxLen2Any) echo 'selected';?> >17</option>
<option value="18" <?php if ($bindingLen2Min == 18 && !$isDoubleBoxLen2Any) echo 'selected';?> >18</option>
<option value="19" <?php if ($bindingLen2Min == 19 && !$isDoubleBoxLen2Any) echo 'selected';?> >19</option>
<option value="20" <?php if ($bindingLen2Min == 20 && !$isDoubleBoxLen2Any) echo 'selected';?> >20</option>
<option value="-1" <?php if ($isDoubleBoxLen2Any) echo 'selected';?> >Any</option>
</select>
</li>
</ul>
</td>
<td valign="top">
<!--<img src="images/binding_sites/double-binding-site.JPG"  width="300px"/> -->
</td></tr></table>
<br><br>&nbsp;


<li>
<b>Description of your protein sequences</b> (optional): <br>
<textarea name="description" cols="60" rows="3"><?php echo $seqsDescription;?></textarea>
</li>

</ul>


<font color="#3399FF" size="+1"><b>Computational preferences</b></font>
<ul>
<li><b>Would you like <i>Quick Search</i> or <i>Full Search</i>?</b><br>
<input  type="radio" name="time_limit" value="10" <?php if ($timeLimit <= 10) echo 'checked';?> /> Quick Search. 
<i>With this option, it will take about 10 minutes but you may miss some motifs.</i><br>
<input  type="radio" name="time_limit" value="480" <?php if ($timeLimit > 10) echo 'checked';?> /> Full Search. 
<i>With this option, it can take up to about 4 hours but you will find most of motifs.</i><br>
</li>
</ul>

<br>
<center>
<input type="submit" name="cmd_submit" value="Submit new parameters"/> &nbsp;
<input type="submit" name="cmd_cancel" value="Cancel"/>
</center>
<br>

</form>
<form method="post" action="index.php" id="formSub">
<input type="hidden" name="page" value="<?php echo $htmlPageName; ?>" />
<input type="hidden" name="cmd" value="add_contact" />
<input type="hidden" name="queryID" value="<?php echo $queryID; ?>" />
<input type="hidden" name="cd" value="<?php echo SecurityEncodeFunc("$queryID"); ?>" />

<font color="#3399FF" size="+2"><b>Your contact information</b></font>
<?php
//if ($_POST['cmd'] == 'Submit' && !$emailDeliverySucc ) {
	//echo '<br><font color="#FF0000">We can not send to the email you provided. Please check your email.</font><br>';
//} 
?>
<table><tr>
<td>
<ul>
<li><b>Email</b>: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="email" id="email" size="30" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['email'];?>"/> 
<font color="#FF0000">*(required)</font>
</li>
<li>
<b>First name</b>: 
<input type="text" name="firstName" id="firstName" size="20" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['firstName'];?>"/> 
<font color="#FF0000">*(required)</font>
</li>
<li><b>Last name</b>: 
<input type="text" name="lastName" id="lastName" size="20" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['lastName'];?>"/> 
<font color="#FF0000">*(required)</font>
</li>
<li><b>Phone</b>: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="phone" size="20" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['phone'];?>"/> (optional)
</li>
<li><b>Organization</b>: 
<input type="text" name="organization" size="35" value="<?php if ($_POST['cmd'] == 'Submit') echo $_POST['organization'];?>"/> (optional)
</li>
</ul>
</td>
<td valign="top">
<input type="submit" name="cmd_submit" value="Submit" onClick="if (!checkSubmission()) return false;"/> &nbsp;
<input type="submit" name="cmd_cancel" value="Cancel"/>
</td>
</tr></table>
<br>

<script language="JavaScript">
function checkSubmission() {
	var email = document.getElementById('email');
	var firstName = document.getElementById('firstName');
	var lastName = document.getElementById('lastName');
	if (!isValidEmail(email.value)) { 
		alert('Invalid email ' + email.value + '. Make sure that there are NO SPACE CHARACTERS at the end and/or beginning of the email');  
		return false;
	}		
	if (firstName.value.length < 1 || firstName.value.length > 30) { 
		alert('Invalid first name'); 
		return false;
	}
	if (lastName.value.length < 1 || lastName.value.length > 30) { 
		alert('Invalid last name'); 
		return false;
	}	 
	if (!confirm('Are you sure that your email is correct?')) {
		return false;
	}	
	return true;
}
</script>
</form>
<table align="center">
    <td id="submission">
        You can view your submission history by entering your email and password. 
        If you forget your password or did not set your password yet, 
        <a href="index.php?page=submissionhistory&cmd=sendpass" class="headertext"><b>click here to 
        reset your password</b></a> . You can also 
        <a href="index.php?page=submissionhistory&cmd=changepass" class="headertext"><b>change your current password</b></a>.
        <?php
			if ( isset($_POST['cmd_view']) && !$isValidPassword ) {
				echo '<br><center><b><font color="#ff0000">Email or password is incorrect.</font></b></center><br>';
			} 
        ?>	
    </td>
</table>


<table align="center">
	<td	>
        <form method="post" action="index.php" id="formsubmission">
        <input type="hidden" name="page" value="submissionhistory" />
        <input type="hidden" name="cmd" value="view_submission_history"/>
            <table>
            	<tr valign="top">
                	<td id="submission">
            			<table border="1" >
                        	<tr>
					            <td>Email:
                                </td>
                            	<td><input type="text" size="40" name="email" id="email" value="<?php if (isset($_POST['email'])) echo $_POST['email']; else if (isset($_SESSION['userEmail'])) echo $_SESSION['userEmail']; else echo "";?>"/>
                                </td>
                            </tr>
                            <tr>
                            	<td>Password:
                                </td>
                            	<td><input type="password" size="30" name="password" id="password" value=""/> 
                            	</td>
                            </tr>
                        </table>
                        <center>
                        <input type="submit" name="cmd_view" value="View submission history" onClick="if (!checkSubmission()) return false;"/>
                        </center>
                        <script language="JavaScript">
							function checkSubmission() {
								var email = document.getElementById('email');
								if (!isValidEmail(email.value)) { 
									alert('Invalid email ' + email.value + '. Make sure that there are NO SPACE CHARACTERS at the end and/or beginning of the email');  
									return false;
								}		
								if (!confirm('Are you sure that your email is correct?')) {
									return false;
								}	
								return true;
							}
						</script>
		            </td>
                </tr>
            </table>
    	</form>
    </td>
</table>
<table align="center">
    <td id="submission">
    	<?php
			if (isset($_POST['cmd_noaction']) && $captcha_passed) {
				if ($isSendEmailSucc) {
					echo '<br><b>An email has been successfully sent to your email <i>'.$userEmail.'</i></b><br><br>';
				} else {
					echo '<br><b>We can not send to your provided email <i>'.$userEmail.'</i></b><br><br>';
				} 
			}
		?>
    	<p>Please enter your email address. An email will be sent to you providing a link to reset password.</p>
        
    </td>
</table>



<table align="center">
	<td>
        <form method="post" action="index.php" id="formsubmission">
        <input type="hidden" name="page" value="submissionhistory" />
        <input type="hidden" name="cmd" value="send_new_password" />
            <table border="1"  width="70%" id="formsubmission">
                <tr>
                    <td>
                        <br \>
                        <table>
                            <tr>
                                <td><b>Email:</b>
                                </td>
                                <td><input type="text" size="40" name="email" id="email" value="<?php if (isset($_POST['email'])) echo $_POST['email']; else if (isset($_SESSION['userEmail'])) echo $_SESSION['userEmail'];?>" />
                                </td>
                            </tr>
                        </table>
                    
                        <br \>
                        <center>
                        <input type="submit" name="cmd_noaction" value="Send me new password" onClick="if (!checkSubmission()) return false;"/>
                        </center>
                    </td>
                </tr>
            </table>
            <script language="JavaScript">
            function checkSubmission() {
                var email = document.getElementById('email');
                if (!isValidEmail(email.value)) { 
                    alert('Invalid email ' + email.value + '. Make sure that there are NO SPACE CHARACTERS at the end and/or beginning of the email');  
                    return false;
                }		
                if (!confirm('Are you sure that your email is correct?')) {
                    return false;
                }	
                return true;
            }
            </script>
        </form>
    </td>
</table>
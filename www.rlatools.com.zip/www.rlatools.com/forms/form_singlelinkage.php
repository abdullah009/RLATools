<form method="post" action="index.php" enctype="multipart/form-data" id="formsinglelinkage">
	<input type="hidden" name="page" value="singlelinkage" />

    <font color="#666600" size="+2"><b>Information about your data</b></font><br/>
 	<font color="#FF0000" size="+0"><label id="comment_data"></label></font><br/>
    <ul>
        <li id="id_01">
            <b>Please choose number of input data sets:
            <select name="dataset_total" id="id_dataset_total">
            	<option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
            </select>
        </li>
        
        <li id="id_02">
        	<b>Select input data files from your computer:
            <input type='file' style="width:100%" name='dataset0' id='dataset0'/>
            <input type='file' style="width:100%" name='dataset1'id='dataset1'/>
        </li>
        
        <li id="id_03">
        	<b>Choose number of attribute types:
            <select name="attribute_total" id="id_attribute_total">
            	<option value="0">--select--</option>
            	<option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
                <option value="16">16</option>
                <option value="17">17</option>
                <option value="18">18</option>
                <option value="19">19</option>
                <option value="20">20</option>
            </select>
        </li>

        <br>

         <li id="id_04">
         	<b>Short distinct name of attribute fields.
         </li>

		<br>
         
         <li id="id_05">
         	<b>Indices of attribute fields. If not present in this dataset, select --.
         </li>
        
         <br>
         
         <li id="id_06">
         	<b>Number of Comparison Methods
         </li>
         
         <br>
         
         <li id="id_09">
         	<b>Comparison methods
         </li>
         
         <br>
         
         <li id="id_07">
         	<b>Block Field
         </li>
         
         <br>
         
         <li id="id_08">
         	<b>Block Field Avg Length: <input type="text" name="block_length" size="2">
            <br>You may change the approximate average value of the block field for better performance. 
         </li>
         
         <br>
         
          <li id="id_08">
         	<b>Threshold Value: <input type="text" name="threshold" id="id_threshold" size="2">
         </li>
         
	</ul>
    
    
    <i>Please enter your email address: <input type="text" name="email" id="email" size="50"> 
    <font color="#FF0000"><label id="comment_email" hidden>Invalid email address</label></font> <br/>
    First Name: <input type="text" name="firstName" size="20" placeholder="optional">  Last Name: <input type="text" name="lastName" size="20" placeholder="optional"><br>
	Organization: <input type="text" name="organization" size="35" placeholder="optional"> <br>
    Phone: <input type="text" name="phone" size="15" placeholder="optional">  
    </i>    

	<center>
    	<input type="submit" name="cmd" value="Submit" onclick="if (!checkBeforeSubmit()) return false;">
    </center>


	<script language="javascript">
		
		function checkBeforeSubmit()
		{
			//return true;
			// check dataset
			var id_dataset_total	= document.getElementById("id_dataset_total");
			var comment_data		= document.getElementById("comment_data");
			comment_data.style.display	= "none";
			//alert(id_dataset_total.value + "");
			for (var i = 0; i < id_dataset_total.value; ++i)
			{
				var id_dataset	= document.getElementById("dataset" + i);
				var val_dataset	= id_dataset.value;
				var type_dataset	= val_dataset.substring(val_dataset.length - 4);
				//alert(id_dataset.value);
				if ((type_dataset != ".csv") && (type_dataset != ".txt"))
				{
					comment_data.style.display	= "inline";
					comment_data.innerHTML	= 'inavlid data set selection!!!';
					return false;
				}
			}
			
			// check attributes
			var id_attribute_total	= document.getElementById("id_attribute_total");
			var attribute_total		= parseInt(id_attribute_total.value);
			if (attribute_total < 2)
			{
				comment_data.style.display	= "inline";
				comment_data.innerHTML	= 'choose how many unique attributes your datasets contain!!!';
				return false;
			}
			
			/*
			for (var i = 0; i < attribute_total; ++i)
			{
				var id_attribute	= document.getElementById("attribute" + i);
				if (id_attribute.value.length < 1)
				{
					comment_data.style.display	= "inline";
					comment_data.innerHTML	= 'fill up unique names for all attributes!!!';
					return false;
				}
			}
			*/
			
			// check comparison
			var id_comparison_total	= document.getElementById("id_comparison_total");
			var comparison_total	= parseInt(id_comparison_total.value);
			if (comparison_total < 1)
			{
				comment_data.style.display	= "inline";
				comment_data.innerHTML	= 'choose a number of comparisons!!!';
				return false;
			}
			
			for (var i = 0; i < comparison_total; ++i)
			{
				var comparison_method		= parseInt(document.getElementById("id_comparison_method" + i).value);
				var comparison_index		= parseInt(document.getElementById("id_comparison_index" + i).value);
				var comparison_truncation	= parseInt(document.getElementById("id_comparison_truncation" + i).value);
				
				if (comparison_method < 0 || comparison_index < 0 || (comparison_method == 3 && comparison_truncation < 0))
				{
					comment_data.style.display	= "inline";
					comment_data.innerHTML	= 'invalid comparison method selection!!!';
					return false;
				}
			
			}
			
			// check block
			var id_block	= document.getElementById("id_block");
			if (parseInt(id_block.value) < 0)
			{
				comment_data.style.display	= "inline";
				comment_data.innerHTML	= 'choose an index for the blocking!!!';
				return false;
			}
			
			var block_length	= document.getElementById("block_length");
			if (block_length != '' && (isNaN(block_length.value) || parseInt(block_length.value) < 0))
			{
				comment_data.style.display	= "inline";
				comment_data.innerHTML	= 'choose a positive integer for block length!!!';
				return false;
			}
			
			// check threshold
			var id_threshold	= document.getElementById("id_threshold");
			if (id_threshold != '' && (isNaN(id_threshold.value) || parseInt(id_threshold.value) < 0))
			{
				comment_data.style.display	= "inline";
				comment_data.innerHTML	= 'choose a positive integer for threshold value!!!';
				return false;
			}
			
			
			// check email address
			var email	= document.getElementById('email');
			if (!isValidEmail(email.value)) 
			{ 
				document.getElementById('comment_email').style.display	= "inline";  
				return false;
			}
			
			/*
			var password	= document.getElementById('password');
			if (password.length < 6) 
			{ 
				comment_data.style.display	= "inline";
				comment_data.innerHTML	= 'put at least 6 characters for password!!!'; 
				return false;
			}
			*/
				
				
			return true;
		}
	
		document.getElementById("id_dataset_total").onchange	= function()
		{
			var li_02	= document.getElementById("id_02");
			li_02.innerHTML	= '<b>Select input data files from your computer:';
			for (var i = 0; i < this.value; ++i)
			{
				li_02.innerHTML	+= '<input type="file" style="width:100%" name="dataset' + i + '" id="dataset' + i + '"/>';
			}
			
		}
		
		document.getElementById("id_attribute_total").onchange	= function()
		{
			var itemTotal		= this.value;
			
			// name of all attribute fields
			var li_04			= document.getElementById("id_04");
			li_04.innerHTML		= '<b>Input short distinct name of attribute fields:<br>';
			var widthPerField	= 100 / itemTotal;
			for (var i = 0; i < itemTotal; ++i)
			{
				li_04.innerHTML	+= '<input type="text" size=' + widthPerField + ' name="attribute' + i + '" id="attribute' + i + '"/>';
			}
			
			var datasetTotal	= document.getElementById("id_dataset_total");
			
			// indices of attribute fields of all data sets
			var li_05			= document.getElementById("id_05");
			li_05.innerHTML		= '<b>Select indices of attribute fields. If not present in this dataset, select -1. 0 is the 1st index.';
			var dropMenu;
			for (var i = 0; i < datasetTotal.value; ++i)
			{
				li_05.innerHTML		+= '<br>dataset' + i + ':<br>';
				for (var j = 0; j < itemTotal; ++j)
				{
					dropMenu	= '<select name="attribute_index' + i + '_' + j + '" id="id_attribute_index">';
					for (var k = -1; k < itemTotal; ++k)
						if (j == k)
							dropMenu	+= '<option value=' + k + ' selected>' + k + '</option>';	
						else
							dropMenu	+= '<option value=' + k + '>' + k + '</option>';	
					dropMenu	+= '</select>';
            		li_05.innerHTML	+= dropMenu;
				}
			}
			
			
			// comparison methods and indices
			dropMenu	= '<b>Number of comparisons:\
			 <select name="comparison_total" id="id_comparison_total" onchange="addComparison(this)")>\
			 <option value="-1">--select--</option>';
			 
			for (var i = 1; i <= itemTotal; ++i)
            	dropMenu	+= '<option value=' + i + '>' + i + '</option>';
			dropMenu	+= '</select>';
			
			var li_06			= document.getElementById("id_06");
			li_06.innerHTML		= dropMenu;
			
			
			// block field index
			dropMenu	= '<b> Block Field Index:\
			 <select name="block_index" id="id_block">\
			 <option value="-1">--select--</option>';
			for (var i = 0; i < itemTotal; ++i)
            	dropMenu	+= '<option value=' + i + '>' + i + '</option>';
			dropMenu	+= '</select>'; 
			 
			var li_07			= document.getElementById("id_07");
			li_07.innerHTML		= dropMenu;
		}
		
		
		
		
		function addComparison(id)
		{
			//alert("asdsa " + id.value);
			var value			= id.value;
			var li_06			= document.getElementById("id_09");
			var attributeTotal	= document.getElementById("id_attribute_total").value;
			var menuRow	= '';
			
			for (var t = 0; t < id.value; ++t)
			{
				menuRow	+= 'Comparision ' + (t + 1) + ':\
				<select name="comparison' + t + '"id="id_comparison_method' + t + '" onChange="setTruncationField(this.value,' + t + ')">\
					<option value="-1">--method--</option>\
					<option value="1">Edit Distance</option>\
					<option value="2">Reversal Distance</option>\
					<option value="3">Truncation Distance</option>\
				</select> \
				 <select name="comparison_index' + t + '"id="id_comparison_index' + t + '">\
					<option value="-1">--index--</option>';
				for (var i = 0; i < attributeTotal; ++i)
					menuRow	+= '<option value=' + i + '>' + i +'</option>';
				menuRow	+= '</select>\
				<select name="comparison2_index' + t + '"id="id_comparison2_index' + t + '">\
					<option value="-1">--index--</option>';
				for (var i = 0; i < attributeTotal; ++i)
					menuRow	+= '<option value=' + i + '>' + i +'</option>';
				menuRow	+= '</select>\
				<select name="truncation_count' + t + '"id="id_comparison_truncation' + t + '">\
					<option value="-1">--truncation--</option>';
				for (var i = 1; i < 10; ++i)
					menuRow	+= '<option value=' + i + '>' + i +'</option>';
				menuRow	+= '</select><br>';
			}
			li_06.innerHTML	= menuRow;
		}
		
		
		function setTruncationField(compValue, compInd)
		{
			if (compValue == 1)
			{
				document.getElementById('id_comparison2_index' + compInd).style.display	= "none";
				document.getElementById('id_comparison_truncation' + compInd).style.display	= "none";
			}
			else if (compValue == 2)
			{
				document.getElementById('id_comparison2_index' + compInd).style.display	= "inline";
				document.getElementById('id_comparison_truncation' + compInd).style.display	= "none";
			}
			else if (compValue == 3)
			{
				document.getElementById('id_comparison2_index' + compInd).style.display	= "none";
				document.getElementById('id_comparison_truncation' + compInd).style.display	= "inline";
			}
				 
		}
		
	</script>
</form>
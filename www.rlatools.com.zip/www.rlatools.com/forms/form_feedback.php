
<form method="post" action="index.php" id="formfeedback">
<input type="hidden" name="page" value="feedback" />

    <center>
    <table width="70%" bordercolor="#CCCCCC" border="1"><tr><td id="formfeedback">
    <font color="#666600" size="+2"><b>Feedback form</b></font>
    <ul>
    <li>
    <b>Feedback type:</b>
    <select name="feedback_type">
    <option value="1"  <?php if (!isset($_POST['feedback_type']) || $_POST['feedback_type'] == 1) echo 'selected';?> > General</option>
    <option value="2"  <?php if (isset($_POST['feedback_type']) && $_POST['feedback_type'] == 2) echo 'selected';?> > Technical</option>
    <option value="3"  <?php if (isset($_POST['feedback_type']) && $_POST['feedback_type'] == 3) echo 'selected';?> > Visual</option>
    <option value="100"  <?php if (isset($_POST['feedback_type']) && $_POST['feedback_type'] == 100) echo 'selected';?> > Other</option>
    </select>
    </li>
    <li>
    <b>Feedback:</b><br>
    <textarea name="content" cols="77" rows="10"><?php if (isset($_POST['content'])) echo $_POST['content'];?></textarea> 
    </li>
    </ul>
    <center>
    <input type="submit" name="cmd" value="Submit" />
    </center>
    </td></tr></table>
    </center>
</form>
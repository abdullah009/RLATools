<?php
$isValidData = false;
$invalidDataErrorMessage = "";
$emailDeliverySucc = false;	
$captcha_passed = true;

$isConfirmSucc = false;
$processingStatus = 1;
$queryInforInHTML = "";
$inputSeqsInHTML = "";
$motifFoundInHTML = "";

function GetQueryInforInHTML($dBaseLink, $qID, $proStatus, $AnonymousUserID) {
	$sqlQuery = 'SELECT `motifseq_query`.`userID` as userID, `email`, `firstName`, `lastName`, 
				`model`, `timeLimit`, `quorumPercent`,
				`bindingLen1Min`, `bindingLen1Max`, 
				`bindingGapMin`, `bindingGapMax`, 
				`bindingLen2Min`, `bindingLen2Max`, 				
				`isRvrsComSeqsAdded`,
				`seqsDescription`, `isConfirmed`, `submissionTime`
				FROM `motifseq_query`, `user` 
				WHERE `motifseq_query`.`userID` = `user`.`userID` AND `motifseq_query`.`queryID` = '.$qID;
	
	$result = mysql_query($sqlQuery, $dBaseLink);
	$row = mysql_fetch_array($result);
	//echo $sqlQuery.'<br/>'.$row['email'];						
	$html = '<font color="#3399FF" size="+2"><b>Query Information</b></font><br>';
	$html .= '<table width="100%"><tr><td width="50%" valign="top">';
	$html .= '<ul>';
	$html .= "<li><b>Query No:</b> $qID</li>";
	//$html .= '<li><b>Submitted by:</b> '.$row['firstName'].' '.$row['lastName'].', email '.$row['email'].'</li>';
	//if ($row['email'] == 'anonymous@motifsearch.com') {
	$htmlLink = "'index.php?page=motifseq&cmd=viewResult&queryID=".$qID.'&cd='.SecurityEncodeFunc("$qID").'&email=update'."'";
	$updateEmailLink = '<br><input type="button" value="Update" onclick="window.location.href='.$htmlLink.'"/>';
	if ($row['userID'] == $AnonymousUserID) {
		$html .= '<li><b>Contact email:</b> unknown '.$updateEmailLink.'</li>';
	} else {
		$html .= '<li><b>Contact email:</b> '.$row['email'].' '.$updateEmailLink.'</li>';
	}
	//$html .= '<br>$'.$row['userID']. '$  $'. $AnonymousUserID. '$';	
	if ($row['bindingLen2Min'] == 0 && $row['bindingLen2Max'] == 0) {
		if ($row['bindingLen1Min'] == $row['bindingLen1Max']) {
			$html .= '<li><b>Single binding site:</b><br><ul><li>Binding site length: '.$row['bindingLen1Min'].'</li></ul></li>';
		} else {
			$html .= '<li><b>Single binding site:</b><br><ul><li>Binding site length: Any</li></ul></li>';
		}		
	} else {
		$html .= '<li><b>Double binding site:</b><br>';
		if ($row['bindingLen1Min'] == $row['bindingLen1Max']) {
			$html .= '<ul><li>First binding site length: '.$row['bindingLen1Min'].'</li>';
		} else {
			$html .= '<ul><li>First binding site length: Any </li>';
		}
		if ($row['bindingGapMin'] == $row['bindingGapMax']) {
			$html .= '<li>Gap between the two binding sites: '.$row['bindingGapMin'].'</li>';
		} else {
			$html .= '<li>Gap between the two binding sites: Any </li>';
		}		
		if ($row['bindingLen2Min'] == $row['bindingLen2Max']) {
			$html .= '<li>Second binding site length: '.$row['bindingLen2Min'].'</li></ul></li>';
		} else {
			$html .= '<li>Second binding site length: Any </li></ul></li>';
		}				
	}
	$html .= '<li><b>Quorum Percent: </b>'.$row['quorumPercent'].'</li>';
	$html .= '</ul>';
	$html .= '</td><td width="50%" valign="top">';	
	$html .= '<ul>';
	if ($proStatus == 1) {
		$html .= '<li><b>Processing status: </b> <font color="red">in processing queue</font></li>';
	} else if ($proStatus == 2) {
		$html .= '<li><b>Processing status: </b> <font color="red">being processed</font></li>';
	} else if ($proStatus == 3) {
		$html .= '<li><b>Processing status: </b> <font color="red">processed</font></li>';
	} else {
		$html .= '<li><b>Processing status: </b> <font color="red">unprocessed</font></li>';
	}
	if ($row['model'] == 1) {
		//$html .= '<li><b>Search model:</b> Pattern-based </li>';
	} else if ($row['model'] == 2) {
		//$html .= '<li><b>Search model:</b> Statistics-based </li>';	
	} else {
		//$html .= '<li><b>Search model:</b> Mixing pattern-based and statistics-based </li>';
	}	
	if ($row['timeLimit'] <= 10) {
		$html .= '<li><b>Search mode:</b> Quick Search</li>';	
	} else {
		$html .= '<li><b>Search mode:</b> Full Search</li>';	
	}
	$html .= '<li><b>Submitted time:</b> '.$row['submissionTime'].'</li>';	
	if ($row['isConfirmed'] == 1) {
		//$html .= '<li><b>Confirmed:</b> <font color="red">Yes</font></li>';
	} else {
		//$html .= '<li><b>Confirmed:</b> <font color="red">No</font></li>';
	}
	if ($row['isRvrsComSeqsAdded'] == 1) {
		$html .= "<li><b>Add reverse complement sequences:</b> Yes</li>";
	} else {
		$html .= "<li><b>Add reverse complement sequences:</b> No</li>";
	}
	$htmlLink = "'index.php?page=motifseq&cmd=viewResult&queryID=".$qID.'&cd='.SecurityEncodeFunc("$qID").'&params=update'."'";
	$updateParamLink = '<br><input type="button" value="Search with different parameters" onclick="window.location.href='.$htmlLink.'"/>';
	if ($proStatus == 3) {
		$htmlLink = "'index.php?page=motifseq&cmd=viewResult&queryID=".$qID.'&cd='.SecurityEncodeFunc("$qID").'&rateaccuracy=update'."'";
		$updateRateAccuracyLink = '<br><input type="button" value="Evaluate results" onclick="window.location.href='.$htmlLink.'"/>';
	}
	$html .= '<li><b>Description:</b> <i>'.$row['seqsDescription'].$updateParamLink.$updateRateAccuracyLink.'</i></li>';
	$html .= '</ul>';
	$html .= '</td></tr></table>';
	//$html .= '<hr>';
	mysql_free_result($result);
	return $html;
}

function GetRvrsComplement($seq) {
	$len = strlen($seq);
	$rvrsComp = $seq;	
	for ($i = 0; $i < $len; $i++) {
		if ($seq[$i] == 'A' || $seq[$i] == 'a') {
			$rvrsComp[$len - $i - 1] = 'T';
		} else if ($seq[$i] == 'C' || $seq[$i] == 'c') {
			$rvrsComp[$len - $i - 1] = 'G';
		} else if ($seq[$i] == 'G' || $seq[$i] == 'g') {
			$rvrsComp[$len - $i - 1] = 'C';
		} else if ($seq[$i] == 'T' || $seq[$i] == 't'){
			$rvrsComp[$len - $i - 1] = 'A';
		} else {
			$rvrsComp[$len - $i - 1] = $seq[$i];
		}
	}
	return $rvrsComp;
}

function GetMotifGapLen($motif) {
	$gapLen = 0;
	$motifLen = strlen($motif);
	for ($i =0 ; $i < $motifLen; $i++) {
		if ($motif[$i] == '#') $gapLen++;
	}
	return $gapLen;
}
function GetMotifsListFromResultTxt($motifSeqsResultTxt, &$scoreList, &$maxMutationList) {
	$motifList = array();
	$scoreList = array();
	$maxMutationList = array();
	$len = strlen($motifSeqsResultTxt);
	$line = "";
	for($i = 0; $i < $len; $i++) {
		$curChar = ord($motifSeqsResultTxt[$i]);
		if ($curChar == 10 || $curChar == 13) {
			$lineParts = explode(" ", $line);
			if (count($lineParts) >= 3) {
				$motifList[] = $lineParts[0];
				$scoreList[] = $lineParts[1];
				$maxMutationList[] = $lineParts[2];
			}
			$line = "";
		} else {
			$line .= $motifSeqsResultTxt[$i];
		}
	}
	if (strlen($line) > 0) {
		$lineParts = explode(" ", $line);
		if (count($lineParts) >= 3) {
			$motifList[] = $lineParts[0];
			$scoreList[] = $lineParts[1];
			$maxMutationList[] = $lineParts[2];
		}
	}		
	return $motifList;
}
function GetSeqsListFromFastaSeq($dnaSeqsInFasta) {
	$seqList = array();
	$len = strlen($dnaSeqsInFasta);
	$seq = "";
	$isCommentLine = false;
	for($i = 0; $i < $len; $i++) {
		$curChar = ord($dnaSeqsInFasta[$i]);
		if ($curChar == ord(' ') || $curChar == ord('\t')) continue;
		
		if ($isCommentLine) {			
			if ($curChar == 10 || $curChar == 13) {
				$isCommentLine = false;
				$seq = "";
			}
		} else {
			if ($curChar == ord('>')) {
				if (strlen($seq) > 0) {
					$seqList[] = $seq;
				}
				$isCommentLine = true;
			} else if ($curChar != 10 && $curChar != 13){
				$seq .= $dnaSeqsInFasta[$i];
			}		
		}
	}
	if (strlen($seq) > 0) {		
		$seqList[] = $seq;
	}		
	return $seqList;
}

function GetSeqsListWithCommentFromFastaSeq($dnaSeqsInFasta, &$seqComments) {
	$seqList = array();
	$seqComments = array();
	$len = strlen($dnaSeqsInFasta);
	$seq = "";
	$comment = "";
	$isCommentLine = false;
	for($i = 0; $i < $len; $i++) {
		$curChar = ord($dnaSeqsInFasta[$i]);
		if ($isCommentLine == false) {
			if ($curChar == ord(' ') || $curChar == ord('\t')) continue;
		}
		
		if ($isCommentLine) {			
			if ($curChar == 10 || $curChar == 13) {
				$isCommentLine = false;
				$seq = "";
			} else {
				$comment .= $dnaSeqsInFasta[$i];
			}
		} else {
			if ($curChar == ord('>')) {
				if (strlen($seq) > 0) {
					$seqList[] = $seq;
					$seqComments[] = $comment;
					$comment = "";
				}
				$isCommentLine = true;
			} else if ($curChar != 10 && $curChar != 13){
				$seq .= $dnaSeqsInFasta[$i];
			}		
		}
	}
	if (strlen($seq) > 0) {		
		$seqList[] = $seq;
		$seqComments[] = $comment;
	}		
	return $seqList;
}

function SplitSeqIntoLinesInHTML($seq, $nChar) {
	$len = strlen($seq) - $nChar;
	$html = "";
	for ($i = 0; $i < $len; $i += $nChar) {
		$html .= substr($seq, $i, $nChar).'<br>';
	}
	$html .= substr($seq, $i, $len + $nChar - $i);
	return $html;
}
function SplitSeqIntoLinesWithMotifInHTML($seq, $nChar, $beginMatchLocation, $motif) {
	$len = strlen($seq);
	$motifLen = strlen($motif);
	$html = "";
	$endMatchLocation = $beginMatchLocation + $motifLen - 1;

	if ($beginMatchLocation < 0 || $endMatchLocation >= $len) {
		return SplitSeqIntoLinesInHTML($seq, $nChar);
	}
	for ($i = 0; $i < $len; $i++) {
		if ($i == $beginMatchLocation) {
			$html .= '<span style="background-color:#ff9900">';
		}
		if ($beginMatchLocation <= $i && $i <= $endMatchLocation) {
			if (strtoupper($seq[$i]) == strtoupper($motif[$i - $beginMatchLocation])) {
				$html .= '<b><font color="blue">'.strtoupper($seq[$i]).'</font></b>';
			} else {
				$html .= strtolower($seq[$i]);
			}		
		} else {
			$html .= $seq[$i];
		}
		if ($i == $endMatchLocation) {
			$html .= '</span>';
		}
		if ((($i + 1) % $nChar == 0) && (($i + 1) < $len)) {
			$html .= '<br>';
		}
	}
	return $html;
}

function GetBestMatchLocation($seq, $motif, &$nBestMatch) {
	$nBestMatch = 0;
	$bestLocation = 0;
	$len = strlen($seq);
	$motifLen = strlen($motif);
	if ($motifLen > $len) {
		return $bestLocation;
	}
	for ($i = 0; $i <= $len - $motifLen; $i++) {
		$nMatch = 0;
		for ($j = $i; $j < $i + $motifLen; $j++ ) {
			if (strtoupper($seq[$j]) == strtoupper($motif[$j - $i])) {
				$nMatch++;
			}
		}
		if ($nBestMatch < $nMatch) {
			$nBestMatch = $nMatch;
			$bestLocation = $i;
		}
	}
	return $bestLocation;
}

function GetMotifLocations($seq, $motif, $nMatchThreshold, &$locationsArray, &$nMatchesArray, &$nBestMatch) {
	$nBestMatch = 0;
	$bestLocation = 0;
	$locationsArray = array();
	$nMatchesArray = array();
	$len = strlen($seq);
	$motifLen = strlen($motif);
	if ($motifLen > $len) {
		return $bestLocation;
	}
	for ($i = 0; $i <= $len - $motifLen; $i++) {
		$nMatch = 0;
		for ($j = $i; $j < $i + $motifLen; $j++ ) {
			if (strtoupper($seq[$j]) == strtoupper($motif[$j - $i])) {
				$nMatch++;
			}
		}
		if ($nMatchThreshold <= $nMatch) {
			$nMatchesArray[] = $nMatch;
			$locationsArray[] = $i;
		}
		if ($nBestMatch < $nMatch) {
			$nBestMatch = $nMatch;
			$bestLocation = $i;
		}
	}
	return $bestLocation;
}

function GetInputSeqsInHTML($dnaSeqs, $seqComments, $isRvrsComSeqsAdded) {
	$nCharPerLine = 50;
	$html = '<table cellspacing="10">';
	$nSeq = count($dnaSeqs);
	$nComments = count($seqComments);
	for ($i = 0; $i < $nSeq; $i++) {
		if ($i < $nComments) {
			$seqComment = $seqComments[$i];
		} else {
			$seqComment = "";
		}
		if ($isRvrsComSeqsAdded) {
			$html .= '<tr bgcolor="#FFFFFF"><td><b>Seq '.($i + 1).'</b><br>';
			$html .= '<b>Comment: </b><i>'.$seqComment.'</i><br><br>';
			$html .= SplitSeqIntoLinesInHTML($dnaSeqs[$i], $nCharPerLine);				
			$html .= '<br><br><b>Reverse complement of Seq '.($i + 1).'</b><br><br>'.SplitSeqIntoLinesInHTML(GetRvrsComplement($dnaSeqs[$i]), $nCharPerLine);
			$html .= "<br><br></td></tr>\n";
		} else {
			$html .= '<tr bgcolor="#FFFFFF"><td><b>Seq '.($i + 1).'</b><br>';
			$html .= '<b>Comment: </b><i>'.$seqComment.'</i><br><br>';
			$html .= SplitSeqIntoLinesInHTML($dnaSeqs[$i], $nCharPerLine);				
			$html .= '<br><br></td></tr>';
		}		
	}
	$html .= '</table>';
	return $html;
}

function GetMotifLocationsInTxt($dnaSeqs, $seqComments, $isRvrsComSeqsAdded, $motif, $motifIndex, $maxMutation, &$numSeqsOccur, &$numMismatches) {
	$motifLen = strlen($motif);
	$motifGapLen = GetMotifGapLen($motif);
	$nCharPerLine = 50;
	$txt = ">Motif: ".$motif." Length=".$motifLen;
	if ($motifGapLen > 0) {
		$txt .= " GapLength=".$motifGapLen;
	}
	$txt .="\r\n".$motif;
	$nSeq = count($dnaSeqs);
	$nComments = count($seqComments);
	$numSeqsOccur = 0;
	$numMisMatches = 0;
	$nMatchThreshold = $motifLen - $maxMutation - $motifGapLen;
	for ($i = 0; $i < $nSeq; $i++) {		
		$nBestMatch = 0;
		$locationsArray = array();
		$nMatchesArray = array();	
		//$bestLoc = GetBestMatchLocation($dnaSeqs[$i], $motif, &$nBestMatch);
		$bestLoc = GetMotifLocations($dnaSeqs[$i], $motif, $nMatchThreshold, &$locationsArray, &$nMatchesArray, &$nBestMatch);
		if ($i < $nComments) {
			$seqComment = $seqComments[$i];
		} else {
			$seqComment = "";
		}
		$isOccur = false;
		$numMisMatchesPerSeq = 0;
		if ($isRvrsComSeqsAdded) {
			$rvrsComplSeq = GetRvrsComplement($dnaSeqs[$i]);
			$nBestMatchCompl = 0;
			$locationsArrayCompl = array();
			$nMatchesArrayCompl = array();				
			//$bestLocCompl = GetBestMatchLocation($rvrsComplSeq, $motif, $&nBestMatchCompl);	
			$bestLocCompl = GetMotifLocations($rvrsComplSeq, $motif, $nMatchThreshold, &$locationsArrayCompl, &$nMatchesArrayCompl, &$nBestMatchCompl);
			if ($nMatchThreshold <= $nBestMatch) {
				$txt .= "\r\n>Seq_".($i+1)."_Forward_Complement: ".$seqComment."\r\n";
				$nLoc = count($locationsArray);
				for ($loc = 0; $loc < $nLoc; $loc++) {
					$txt .= "(location:".($locationsArray[$loc] + 1).", occurence:".substr($dnaSeqs[$i], $locationsArray[$loc], $motifLen).", #matches:".$nMatchesArray[$loc].") ";
				}
				$isOccur = true;				
			} else {
				$txt .= "\r\n>Seq_".($i+1)."_Forward_Complement: ".$seqComment."\r\n"."No occurrences";	
			}
			if ($nMatchThreshold <= $nBestMatchCompl) {
				$txt .= "\r\n>Seq_".($i+1)."_Reverse_Complement: ".$seqComment."\r\n";
				$nLoc = count($locationsArrayCompl);
				for ($loc = 0; $loc < $nLoc; $loc++) {
					//$txt .= "(location:".($locationsArrayCompl[$loc] + 1).", #matches:".$nMatchesArrayCompl[$loc].") ";
					$txt .= "(location:".($locationsArrayCompl[$loc] + 1).", occurence:".substr($rvrsComplSeq, $locationsArrayCompl[$loc], $motifLen).", #matches:".$nMatchesArrayCompl[$loc].") ";
				}
				$isOccur = true;
			} else {
				$txt .= "\r\n>Seq_".($i+1)."_Reverse_Complement: ".$seqComment."\r\n"."No occurrences";		
			}
			if ($nBestMatch >= $nBestMatchCompl) {
				$numMisMatchesPerSeq = $motifLen - $nBestMatch - $motifGapLen;
			} else {
				$numMisMatchesPerSeq = $motifLen - $nBestMatchCompl - $motifGapLen;
			}
		} else {
			if ($nMatchThreshold <= $nBestMatch ) {
				$txt .= "\r\n>Seq_".($i+1).": ".$seqComment."\r\n";
				$nLoc = count($locationsArray);
				for ($loc = 0; $loc < $nLoc; $loc++) {
					$txt .= "(location:".($locationsArray[$loc] + 1).", occurence:".substr($dnaSeqs[$i], $locationsArray[$loc], $motifLen).", #matches:".$nMatchesArray[$loc].") ";
				}
				$isOccur = true;
			} else {
				$txt .= "\r\n>Seq_".($i+1).": ".$seqComment."\r\n"."No occurrences";
			}
			$numMisMatchesPerSeq = $motifLen - $nBestMatch - $motifGapLen;
		}
		if ($isOccur) {
			$numSeqsOccur++;
			$numMisMatches += $numMisMatchesPerSeq;
		}
	}
	return $txt;
}

function GetInputSeqsWithMotifInHTML($dnaSeqs, $seqComments, $isRvrsComSeqsAdded, $motif, $motifIndex, $maxMutation, &$numSeqsOccur, &$numMisMatches) {
	$motifLen = strlen($motif);
	$motifGapLen = GetMotifGapLen($motif);
	$nCharPerLine = 50;
	$html = '<table cellspacing="10" width="100%">';	
	$nSeq = count($dnaSeqs);
	$nComments = count($seqComments);
	$numSeqsOccur = 0;
	$numMisMatches = 0;
	$nMatchThreshold = $motifLen - $maxMutation - $motifGapLen;
	for ($i = 0; $i < $nSeq; $i++) {
		$nBestMatch = 0;			
		$bestLoc = GetBestMatchLocation($dnaSeqs[$i], $motif, &$nBestMatch);
		if ($i < $nComments) {
			$seqComment = $seqComments[$i];
		} else {
			$seqComment = "";
		}
		$isOccur = false;
		$numMisMatchesPerSeq = 0;
		if ($isRvrsComSeqsAdded) {
			$rvrsComplSeq = GetRvrsComplement($dnaSeqs[$i]);
			$nBestMatchCompl = 0;			
			$bestLocCompl = GetBestMatchLocation($rvrsComplSeq, $motif, &$nBestMatchCompl);	
			$html .= '<tr bgcolor="#FFFFFF"><td>';
			if ($nMatchThreshold <= $nBestMatch) {
				$html .= '<b>Seq '.($i + 1).'</b> has <font color="red"><b>'.$nBestMatch.'</b></font> matches against <b>Motif '.($motifIndex + 1).' <font color="blue">'.$motif.'</font></b><br>';
				$html .= '<b>Comment:</b><i>'.$seqComment.'</i><br><br>';
				$html .= SplitSeqIntoLinesWithMotifInHTML($dnaSeqs[$i], $nCharPerLine, $bestLoc, $motif);
				$isOccur = true;				
			} else {
				$html .= '<b>Seq '.($i + 1).'</b> has '.$nBestMatch.' matches against <b>Motif '.($motifIndex + 1).' <font color="blue">'.$motif.'</font></b><br>';
				$html .= '<b>Comment: </b><i>'.$seqComment.'</i><br><br>';
				$html .= SplitSeqIntoLinesInHTML($dnaSeqs[$i], $nCharPerLine);				
			}
			if ($nMatchThreshold <= $nBestMatchCompl) {
				$html .= '<br><br><b>Reverse complement of Seq '.($i + 1).'</b> has <font color="red"><b>'.$nBestMatchCompl.' matches</b></font> <br><br>';
				$html .= SplitSeqIntoLinesWithMotifInHTML($rvrsComplSeq, $nCharPerLine, $bestLocCompl, $motif);
				$isOccur = true;
			} else {
				$html .= '<br><br><b>Reverse complement of Seq '.($i + 1).'</b> has '.$nBestMatchCompl.' matches <br><br>';
				$html .= SplitSeqIntoLinesInHTML($rvrsComplSeq, $nCharPerLine);				
			}
			if ($nBestMatch >= $nBestMatchCompl) {
				$numMisMatchesPerSeq = $motifLen - $nBestMatch - $motifGapLen;
			} else {
				$numMisMatchesPerSeq = $motifLen - $nBestMatchCompl - $motifGapLen;
			}
			$html .= "<br><br></td></tr>\n";
		} else {
			$html .= '<tr bgcolor="#FFFFFF"><td>';
			if ($nMatchThreshold <= $nBestMatch ) {
				$html .= '<b>Seq '.($i + 1).'</b> has <font color="red"><b>'.$nBestMatch.' matches </b></font> against <b>Motif '.($motifIndex + 1).' <font color="blue">'.$motif.'</font></b><br>';
				$html .= '<b>Comment: </b><i>'.$seqComment.'</i><br><br>';
				$html .= SplitSeqIntoLinesWithMotifInHTML($dnaSeqs[$i], $nCharPerLine, $bestLoc, $motif);
				$isOccur = true;
			} else {
				$html .= '<b>Seq '.($i + 1).'</b> has '.$nBestMatch.' matches against <b>Motif '.($motifIndex + 1).' <font color="blue">'.$motif.'</font></b><br>';
				$html .= '<b>Comment: </b><i>'.$seqComment.'</i><br><br>';
				$html .= SplitSeqIntoLinesInHTML($dnaSeqs[$i], $nCharPerLine);
			}
			$numMisMatchesPerSeq = $motifLen - $nBestMatch - $motifGapLen;
			$html .= "<br><br></td></tr>\n";
		}
		if ($isOccur) {
			$numSeqsOccur++;
			$numMisMatches += $numMisMatchesPerSeq;
		}
	}
	$html .= '</table>';
	return $html;
}

function GetMatchingScore($dnaSeqs, $isRvrsComSeqsAdded, $motif, $maxMutation) {
	$score = 0;
	$nSeq = count($dnaSeqs);
	$motifLen = strlen($motif);	
	for ($i = 0; $i < $nSeq; $i++) {
		$nBestMatch = 0;
		$seq = $dnaSeqs[$i];
		$bestMatchLocation = GetBestMatchLocation($seq, $motif, &$nBestMatch);
		if ($isRvrsComSeqsAdded) {
			$seqCompl = GetRvrsComplement($seq);
			$nBestMatchCompl = 0;
			$bestMatchLocationCompl = GetBestMatchLocation($seqCompl, $motif, &$nBestMatchCompl);
			if ($nBestMatch < $nBestMatchCompl) {
				$nBestMatch = $nBestMatchCompl;
				$bestMatchLocation = $bestMatchLocationCompl;
				$seq = $seqCompl;
			}
		}
		if ($motifLen - $maxMutation - GetMotifGapLen($motif) <= $nBestMatch) {		
			$score += $nBestMatch;
		}
	}	
	$score = round((100 * $score)/($motifLen * $nSeq));
	return $score;
}

function GetProbMatchingMatrix($dnaSeqs, $isRvrsComSeqsAdded, $motif, $maxMutation) {
	$motifLen = strlen($motif);
	$row = array();	
	for ($i = 0; $i < $motifLen; $i++) {
		$row[] = 0;
	}
	$matrix = array();
	for ($i = 0; $i < 4; $i++) {
		$matrix[] = $row;
	}	
	for ($i = 0; $i < 4; $i++) {
		for ($j = 0; $j < $motifLen; $j++) {
			$matrix[$i][$j] = 0;
		}
	}
	$nSeq = count($dnaSeqs);
	$nConsideredSeq = 0;
	for ($i = 0; $i < $nSeq; $i++) {
		$nBestMatch = 0;
		$seq = $dnaSeqs[$i];
		$bestMatchLocation = GetBestMatchLocation($seq, $motif, &$nBestMatch);
		if ($isRvrsComSeqsAdded) {
			$seqCompl = GetRvrsComplement($seq);
			$nBestMatchCompl = 0;
			$bestMatchLocationCompl = GetBestMatchLocation($seqCompl, $motif, &$nBestMatchCompl);
			if ($nBestMatch < $nBestMatchCompl) {
				$nBestMatch = $nBestMatchCompl;
				$bestMatchLocation = $bestMatchLocationCompl;
				$seq = $seqCompl;
			}
		}		
		if ($motifLen - $maxMutation - GetMotifGapLen($motif) > $nBestMatch) continue;
		
		$nConsideredSeq++;		
		for ($j = 0; $j < $motifLen; $j++) {
			if ($seq[$j + $bestMatchLocation] == 'A' || $seq[$j + $bestMatchLocation] == 'a') {
				$matrix[0][$j]++;
			} else if ($seq[$j + $bestMatchLocation] == 'C' || $seq[$j + $bestMatchLocation] == 'c') {
				$matrix[1][$j]++;
			} else if ($seq[$j + $bestMatchLocation] == 'G' || $seq[$j + $bestMatchLocation] == 'g') {
				$matrix[2][$j]++;
			} else if ($seq[$j + $bestMatchLocation] == 'T' || $seq[$j + $bestMatchLocation] == 't') {
				$matrix[3][$j]++;
			} 
		}		
	}
	for ($i = 0; $i < 4; $i++) {
		if ($nConsideredSeq > 0) {
			for ($j = 0; $j < $motifLen; $j++) {
				$matrix[$i][$j] /= $nConsideredSeq;
			}
		}
	}	
	return $matrix;
}
function GetProbMatchingMatrixInHTML($dnaSeqs, $isRvrsComSeqsAdded, $motif, $maxMutation) {	
	$motifLen = strlen($motif);
	$matrix = GetProbMatchingMatrix($dnaSeqs, $isRvrsComSeqsAdded, $motif, $maxMutation);
	$html = '<table cellspacing="1">';
	$html .= '<tr bgcolor="#FFFF88"><td></td>';
	for ($j = 0; $j < $motifLen; $j++) {
		$html .= '<td><b><font color="blue">'.$motif[$j].'</font></b></td>';
	}
	$html .= '</tr>';	
	for ($i = 0; $i < 4; $i++) {
		if ($i == 0) {
			$html .= '<tr bgcolor="#FF9988" align="right"><td><b>A</b></td>';
		} else if ($i == 1) {
			$html .= '<tr bgcolor="#FF9988" align="right"><td><b>C</b></td>';
		} else if ($i == 2) {
			$html .= '<tr bgcolor="#FF9988" align="right"><td><b>G</b></td>';
		} else {
			$html .= '<tr bgcolor="#FF9988" align="right"><td><b>T</b></td>';
		}
		for ($j = 0; $j < $motifLen; $j++) {
			$value = round($matrix[$i][$j] * 10);
			if ($value >= 5) {
				$html .= '<td bgcolor="#FF5588">';
			} else {
				$html .= '<td>';
			}
			if (0 < $value && $value < 10) {
				$html .= '.'.$value.'</td>';
			} else {
				$html .= ($value/10).'</td>';
			}
		}		
		$html .= '</tr>';
	}
	$html .= '</table>';
	return $html;
}

function GetMotifListInHTML($queryID, $dnaSeqs, $isRvrsComSeqsAdded, $motifSeqs, $motifIndex, $scoreList, $numSeqsOccur, $numMismatches) {	
	$nMotif = count($motifSeqs);
	$nSeq = count($dnaSeqs);
	if (count($motifSeqs) == 0) {
		return '<b><font color="red">No motifs found</font></b>. You should try with smaller value of the parameter "<b>percentage of DNA sequences containing motifs</b>", i.e. "<b>Quorum Percent</b>"';
	}
	if ($nMotif == 1) {
		$html = '<b><font size=+1 color="red">Found '.($nMotif).' motif</font></b><br>';
	} else {
		$html = '<b><font size=+1 color="red">Found '.($nMotif).' motifs</font></b><br>';
		$html .= '<i><ul>';
		$html .= '<li>Motifs are ranked based on biological significance</li>';
		$html .= '<li>Select a motif to view its occuring locations on the input sequences on the left panel</li>';
		$html .= '<li>Selected motif is in yellow background</li>';
		$html .= '</ul></i>';
	}	
	$html .= '<table width="100%" cellspacing="10">';
	for ($i = 0; $i < $nMotif; $i++) {
		$motif = $motifSeqs[$i];
		//$score = GetMatchingScore($dnaSeqs, $isRvrsComSeqsAdded, $motif, $maxMutation);
		$quorumPercent = (int)(($numSeqsOccur/$nSeq) * 100);
		if ($motifIndex == $i) {
			$html .= '<tr bgcolor="#FFFF88"><td><b>Motif '. ($i + 1).':<br></b> <font color="blue"><b>'.$motif.'</b></font><br>';
			$html .= 'Length: <font color="red">'.(strlen($motif) - GetMotifGapLen($motif)).'</font><br>';
			$html .= 'Quorum percent: <font color="red">'.$quorumPercent.'%</font><br>';
			$html .= 'Occurs in <font color="red">'.$numSeqsOccur.'</font> input sequences<br>';
			$html .= 'Average #mismatches: <font color="red">'.round($numMismatches/$numSeqsOccur, 2).'</font><br>';
			$html .= '<table><tr>';
			$htmlLink = "'index.php?page=motifseq&cmd=viewResult&param=downloadResult&format=html&queryID=".$queryID.'&cd='.SecurityEncodeFunc("$queryID").'&motif='.($i)."'";
			//$html .= '<td valign="center" align="left"><input type="button" value="Motif locations"/> </td>';
			$html .= '<td valign="center" align="left"><input type="button" value="Save motif locations" onclick="window.open('.$htmlLink.')"/></td>';
			$html .= '<td valign="top" align="left"><img src="images/system/arrow_right.gif" width="50" height="20" border="0" alt="Locations of this motif are on the right"> </td>';
			$htmlLink2 = "'index.php?page=motifseq&cmd=viewResult&param=downloadResult&format=text&queryID=".$queryID.'&cd='.SecurityEncodeFunc("$queryID").'&motif='.($i)."'";
			$html .= '</tr><tr><td colspan="2" valign="center" align="left"><input type="button" value="Save motif locations in text" onclick="window.location.href='.$htmlLink2.'"/></td>';
			$html .= '</tr></table>';
		} else {
			$html .= '<tr bgcolor="#FFFFFF"><td><b>Motif '. ($i + 1).':<br></b> <font color="blue"><b>'.$motif.'</b></font><br>';
			$html .= 'Length: <font color="red">'.(strlen($motif) - GetMotifGapLen($motif)).'</font><br>';
			$htmlLink = "'index.php?page=motifseq&cmd=viewResult&queryID=".$queryID.'&cd='.SecurityEncodeFunc("$queryID").'&motif='.($i)."'";
			$html .= '<br><input type="button" value="View motif locations" onclick="window.location.href='.$htmlLink.'"/>';			
		}
		//$html .= '<br><input type="button" value="Compare with known motifs"/>';	
		$html .= '</td></tr>';
	}
	$html .= '</table>';
	return $html;
}

function CheckIfDNAseqs($dnaSeqs) {
	$nSeq = count($dnaSeqs);
	$numDNALetters = 0;
	$numLetters = 0;
	for ($i = 0; $i < $nSeq; $i++) {
		$seq = $dnaSeqs[$i];
		$seqLen = strlen($seq);
		$numLetters += $seqLen;
		for ($j = 0; $j < $seqLen; $j++) {
			if ($seq[$j] == 'A' || $seq[$j] == 'C' || $seq[$j] == 'G' || $seq[$j] == 'T' ||
				$seq[$j] == 'a' || $seq[$j] == 'c' || $seq[$j] == 'g' || $seq[$j] == 't') {
				$numDNALetters++;
			}
		}
	}
	$ratio = $numDNALetters/$numLetters;
	if ($ratio >= 0.9)  return true;
	else return false;
}

//end functions 


//end funcions

if ($_POST['cmd'] == 'Submit') {
	$logPage .= '-submit';
	//$captcha_resp = recaptcha_check_answer ($CAPTCHA_PrivateKey, 
	//										$_SERVER["REMOTE_ADDR"], 
	//										$_POST["recaptcha_challenge_field"],
	//										$_POST["recaptcha_response_field"]);	
	//if (!$captcha_resp->is_valid) {   
	//   $captcha_passed = false;
	//}
	
	
	//$userEmail = mysql_utils_strictly_prep(substr(trim($_POST['email']), 0, 50));
	//$userEmail = strtolower($userEmail);
	$userEmail = "anonymous@motifsearch.com";
	$userFirstName = "Anonymous User";
	$userLastName = "";
	
	if (($captcha_passed) && isValidEmail($userEmail) ) {
		//add user through email
		if (isset($_SESSION['userID']) && $_SESSION['userID'] > 0) {
			$userID = $_SESSION['userID'];
		} else {
			$userID = $AnonymousUserID;
		}
		//add query
		$model = (int)substr($_POST['model'], 0, 1);
		if ($model < 1 || $model > 3) {
			$model = 1;
		}
		//in minute
		$timeLimit = (int)substr($_POST['time_limit'], 0, 9);
		if ($timeLimit < 0 || $timeLimit > 60 * 24 * 30) {
			$timeLimit = 10;
		}
		//quorum percent 
		$quorumPercent = (int)substr($_POST['quorum_percent'], 0, 3);
		if ($quorumPercent < 5 || $quorumPercent > 100) {
			$quorumPercent = 75;
		}
		//echo '<br>binding_site @'.$_POST['binding_site'].'@'; 
		if ((int)$_POST['binding_site'] == 2) {
		 	$bindingLen1 = (int)substr($_POST['binding_len_1'], 0, 2);
			$bindingLen2 = (int)substr($_POST['binding_len_2'], 0, 2);
			$bindingGap = (int)substr($_POST['binding_len_gap'], 0, 2);
			if ($bindingLen1 < 5 || $bindingLen1 > 20) {
				$bindingLen1Min = 8;
				$bindingLen1Max = 15;			
			} else {
				$bindingLen1Min = $bindingLen1;
				$bindingLen1Max = $bindingLen1;			
			}
			if ($bindingGap < 1 || $bindingGap > 15) {
				$bindingGapMin = 1;
				$bindingGapMax = 5;			
			} else {
				$bindingGapMin = $bindingGap;
				$bindingGapMax = $bindingGap;			
			}			
			if ($bindingLen2 < 3 || $bindingLen2 > 20) {
				$bindingLen2Min = 3;
				$bindingLen2Max = 10;			
			} else {
				$bindingLen2Min = $bindingLen2;
				$bindingLen2Max = $bindingLen2;			
			}			
		} else {			
		 	$bindingLen = (int)substr($_POST['binding_len'], 0, 2);
			if ($bindingLen < 9 || $bindingLen > 40) {
				$bindingLen1Min = 9;
				$bindingLen1Max = 25;
			} else {
				$bindingLen1Min = $bindingLen;
				$bindingLen1Max = $bindingLen;			
			}
			$bindingGapMin = 0;
			$bindingGapMax = 0;						
			$bindingLen2Min = 0;
			$bindingLen2Max = 0;			
		}
		$maxNumSeqs = 5000;
		$minNumSeqs = 5;
		$maxSeqLen = 1000;
		$minSeqLen = 15;
		
		$dnaSeqsFasta = mysql_utils_strictly_prep(substr($_POST['dna_seqs_fasta'], 0, $maxNumSeqs * ($maxSeqLen + 100) )); 
		$isRvrsComSeqsAdded = (int)substr($_POST['add_rvrs_com'], 0, 1);
		if ($isRvrsComSeqsAdded != 0) {
			$isRvrsComSeqsAdded = 1;
		}
		$dnaSeqsDescription = mysql_utils_strictly_prep(substr($_POST['description'], 0, 512)); 
		$isDNAseq = 1;	
		$isConfirmed = 1;
		$processingStatus = 1;
		
		$isValidData = false;
		//$dnaSeqs = GetSeqsListFromFastaSeq($dnaSeqsFasta);
		$dnaSeqs = GetSeqsListWithCommentFromFastaSeq($dnaSeqsFasta, &$seqComments);
		$nSeq = count($dnaSeqs);			
		if ($nSeq >= $minNumSeqs  && $nSeq <= $maxNumSeqs) {
			for ($i = 0; $i < $nSeq; $i++) {
				$seqLen = strlen($dnaSeqs[$i]);
				//if ($seqLen < 15 || $seqLen > 1000) {
				//	break;
				//}
				if ($seqLen < $minSeqLen) {
					$sequenceName = ($i + 1)."-th";
					if ($i == 0) $sequenceName = "first";
					if ($i == 1) $sequenceName = "second";
					if ($i == 2) $sequenceName = "third";
					$invalidDataErrorMessage = "The length of the <b>".$sequenceName."</b> sequence is <b>".$seqLen."</b> . Its length is required to be no less than <b>".$minSeqLen."</b>." ;
					$invalidDataErrorMessage .= "<br>The comment of the <b>".$sequenceName."</b> sequence is: <i>".$seqComments[$i]."</i>";
					$invalidDataErrorMessage .= "<br>The <b>".$sequenceName."</b> sequence is: <i>".$dnaSeqs[$i]."</i>";
					$invalidDataErrorMessage .= "<br><br>Other sequences and comments near the invalid sequence:";
					$idx = $i - 5;
					if ($idx < 0) $idx = 0;
					for (; $idx <= $i + 5 && $idx < $nSeq; $idx++) {
						$sequenceName = ($idx + 1)."-th";
						if ($idx == $i) {
							$invalidDataErrorMessage .= "<b><br>The comment of the ".$sequenceName." sequence is: <i>".$seqComments[$idx]."</i>";
							$invalidDataErrorMessage .= "<br>The ".$sequenceName." sequence is: <i>".$dnaSeqs[$idx]."</i></b>";
						} else {
							$invalidDataErrorMessage .= "<br>The comment of the ".$sequenceName." sequence is: <i>".$seqComments[$idx]."</i>";
							$invalidDataErrorMessage .= "<br>The ".$sequenceName." sequence is: <i>".$dnaSeqs[$idx]."</i>";
						}
					}
					break;
				}				
				if ($seqLen > $maxSeqLen) {
					$seqLen = $maxSeqLen;
					$dnaSeqs[$i] = substr($dnaSeqs[$i], 0, $seqLen);
				}
			}
			if ($i >= $nSeq) {
				$isValidData = true;
			}			
		} else {
			$invalidDataErrorMessage = "The number of sequences is <b>".$nSeq."</b> . It is required to be between <b>".$minNumSeqs."</b> and <b>".$maxNumSeqs.".</b>";
			for ($i = 0; $i < 10 && $i < $nSeq; $i++) {
				$sequenceName = ($i + 1)."-th";
				$invalidDataErrorMessage .= "<br>The comment of the ".$sequenceName." sequence is: <i>".$seqComments[$i]."</i>";
				$invalidDataErrorMessage .= "<br>The ".$sequenceName." sequence is: <i>".$dnaSeqs[$i]."</i>";
			}
		}
		
		if ($isValidData){
			$link = mysql_connect($sql_host, $sql_username, $sql_password);
			if (!mysql_select_db($sql_database, $link)) die ();

			//if (CheckIfDNAseqs($dnaSeqs)) $isDNAseq = 1;
			//else $isDNAseq = 0;
			$isDNAseq = 1;
			
			$isConfirmed = 1;
			$queryID = insertAutoKeyRecord($link, '`motifseq_query`',
					array('`websiteID`', '`userID`', '`model`', '`timeLimit`', '`quorumPercent`', 
						  '`bindingLen1Min`', '`bindingLen1Max`', 
						  '`bindingGapMin`', '`bindingGapMax`',
						  '`bindingLen2Min`', '`bindingLen2Max`', 
						  '`seqsFasta`', '`isDNAseq`', '`isRvrsComSeqsAdded`', 
						  '`seqsDescription`', '`isConfirmed`', 
						  '`submissionIPaddr`', '`submissionTime`', '`latestUpdateTime`', 
						  '`processingStatus`'),					 
					array("$websiteID", "$userID", "$model", "$timeLimit", "$quorumPercent",
						  "$bindingLen1Min", "$bindingLen1Max", 
						  "$bindingGapMin", "$bindingGapMax",
						  "$bindingLen2Min", "$bindingLen2Max",
						  "'".$dnaSeqsFasta."'", "$isDNAseq", "$isRvrsComSeqsAdded",
						  "'".$dnaSeqsDescription."'", "$isConfirmed", 
						  "'".$_SERVER["REMOTE_ADDR"]."'", "NOW()", "NOW()",
						  "$processingStatus"),
					'queryID');
			//close database link
			mysql_close($link);
			$emailDeliverySucc = true;
			$resultLink = 'index.php?page=motifseq&cmd=viewResult&queryID='.$queryID.'&cd='.SecurityEncodeFunc("$queryID");
			header("Location: $resultLink");
			exit(1);											
		}
	}
		
} else if ($_POST['cmd'] == 'change_params') {
	$logPage .= '-changeParams';

	$queryID = (int)$_POST['queryID'];
	if ($_POST['cd'] == SecurityEncodeFunc("$queryID") || $IsIgnoredSecurityCheck ) {
		$security_passed = true;
	} else {
		$security_passed = false;
	}
	//$security_passed = true;
	$newQueryID = $queryID;
		
	if (isset($_POST['cmd_submit']) && $security_passed ) {
		
		$link = mysql_connect($sql_host, $sql_username, $sql_password);
		if (!mysql_select_db($sql_database, $link)) {
			die ();
		}
		
		//add query
		$model = (int)substr($_POST['model'], 0, 1);
		if ($model < 1 || $model > 3) {
			$model = 1;
		}
		//in minute
		$timeLimit = (int)substr($_POST['time_limit'], 0, 9);
		if ($timeLimit < 0 || $timeLimit > 60 * 24 * 30) {
			$timeLimit = 10;
		}
		//quorum percent 
		$quorumPercent = (int)substr($_POST['quorum_percent'], 0, 3);
		if ($quorumPercent < 5 || $quorumPercent > 100) {
			$quorumPercent = 75;
		}
		//echo '<br>binding_site @'.$_POST['binding_site'].'@'; 
		if ((int)$_POST['binding_site'] == 2) {
		 	$bindingLen1 = (int)substr($_POST['binding_len_1'], 0, 2);
			$bindingLen2 = (int)substr($_POST['binding_len_2'], 0, 2);
			$bindingGap = (int)substr($_POST['binding_len_gap'], 0, 2);
			if ($bindingLen1 < 5 || $bindingLen1 > 20) {
				$bindingLen1Min = 8;
				$bindingLen1Max = 15;			
			} else {
				$bindingLen1Min = $bindingLen1;
				$bindingLen1Max = $bindingLen1;			
			}
			if ($bindingGap < 1 || $bindingGap > 15) {
				$bindingGapMin = 1;
				$bindingGapMax = 5;			
			} else {
				$bindingGapMin = $bindingGap;
				$bindingGapMax = $bindingGap;			
			}			
			if ($bindingLen2 < 3 || $bindingLen2 > 20) {
				$bindingLen2Min = 3;
				$bindingLen2Max = 10;			
			} else {
				$bindingLen2Min = $bindingLen2;
				$bindingLen2Max = $bindingLen2;			
			}			
		} else {			
		 	$bindingLen = (int)substr($_POST['binding_len'], 0, 2);
			if ($bindingLen < 9 || $bindingLen > 40) {
				$bindingLen1Min = 9;
				$bindingLen1Max = 25;
			} else {
				$bindingLen1Min = $bindingLen;
				$bindingLen1Max = $bindingLen;			
			}
			$bindingGapMin = 0;
			$bindingGapMax = 0;						
			$bindingLen2Min = 0;
			$bindingLen2Max = 0;			
		}
		
		$isRvrsComSeqsAdded = (int)substr($_POST['add_rvrs_com'], 0, 1);
		if ($isRvrsComSeqsAdded != 0) {
			$isRvrsComSeqsAdded = 1;
		}
		$dnaSeqsDescription = mysql_utils_strictly_prep(substr($_POST['description'], 0, 512)); 
		$isDNAseq = 1;	
		$isConfirmed = 1;
		$processingStatus = 1;
		
		$dnaSeqsFasta = getOneRecord($link, '`motifseq_query`', '`seqsFasta`', '`queryID`', "$queryID");
		$userID = getOneRecord($link, '`motifseq_query`', '`userID`', '`queryID`', "$queryID");
		
		//instant process here
		$newQueryID = insertAutoKeyRecord($link, '`motifseq_query`',
					array('`websiteID`', '`userID`', '`model`', '`timeLimit`', '`quorumPercent`', 
						  '`bindingLen1Min`', '`bindingLen1Max`', 
						  '`bindingGapMin`', '`bindingGapMax`',
						  '`bindingLen2Min`', '`bindingLen2Max`', 
						  '`seqsFasta`', '`isDNAseq`', '`isRvrsComSeqsAdded`', 
						  '`seqsDescription`', '`isConfirmed`', 
						  '`submissionIPaddr`', '`submissionTime`', '`latestUpdateTime`', 
						  '`processingStatus`'),					 
					array("$websiteID", "$userID", "$model", "$timeLimit", "$quorumPercent",
						  "$bindingLen1Min", "$bindingLen1Max", 
						  "$bindingGapMin", "$bindingGapMax",
						  "$bindingLen2Min", "$bindingLen2Max",
						  "'".$dnaSeqsFasta."'", "$isDNAseq", "$isRvrsComSeqsAdded",
						  "'".$dnaSeqsDescription."'", "$isConfirmed", 
						  "'".$_SERVER["REMOTE_ADDR"]."'", "NOW()", "NOW()",
						  "$processingStatus"),
					'queryID');				
		
		mysql_close($link);
	}
	
	$resultLink = 'index.php?page=motifseq&cmd=viewResult&queryID='.$newQueryID.'&cd='.SecurityEncodeFunc("$newQueryID");		
	header("Location: $resultLink");
	exit(1);
	
} else if ($_POST['cmd'] == 'rate_accuracy') {
	$logPage .= '-rateAccuracy';

	$queryID = (int)$_POST['queryID'];
	if ($_POST['cd'] == SecurityEncodeFunc("$queryID") || $IsIgnoredSecurityCheck ) {
		$security_passed = true;
	} else {
		$security_passed = false;
	}
	if (isset($_POST['cmd_submit']) && $security_passed ) {
		
		$link = mysql_connect($sql_host, $sql_username, $sql_password);
		if (!mysql_select_db($sql_database, $link)) {
			die ();
		}
		$rateAccurate = (int)$_POST['rate_accuracy'];
		$commment = mysql_utils_strictly_prep(substr(trim($_POST['commment']), 0, 1000));	
		setOneRecord($link, '`motifseq_query`', '`rateAccuracy`', "$rateAccurate", '`queryID`', "$queryID");
		setOneRecord($link, '`motifseq_query`', '`commment`', "'".$commment."'", '`queryID`', "$queryID");
		mysql_close($link);
	}
	
	$resultLink = 'index.php?page=motifseq&cmd=viewResult&queryID='.$queryID.'&cd='.SecurityEncodeFunc("$queryID");		
	header("Location: $resultLink");
	exit(1);
		
} else if ($_POST['cmd'] == 'add_contact') {
	$logPage .= '-addContact';
	
	$userEmail = mysql_utils_strictly_prep(substr(trim($_POST['email']), 0, 50));
	$userEmail = strtolower($userEmail);
	$queryID = (int)$_POST['queryID'];
	if ($_POST['cd'] == SecurityEncodeFunc("$queryID") || $IsIgnoredSecurityCheck) {
		$security_passed = true;
	} else {
		$security_passed = false;
	}	
	if ( isset($_POST['cmd_submit']) && ($security_passed && isValidEmail($userEmail)) ) {
	//if ( ($security_passed && isValidEmail($userEmail)) ) {
		$link = mysql_connect($sql_host, $sql_username, $sql_password);
		if (!mysql_select_db($sql_database, $link)) {
			die ();
		}
		//add user through email	
		$userID = getOneRecord($link, '`userrl`', '`userID`', '`email`', "'$userEmail'"); 
		if ($userID <= 0 && $userID != $AnonymousUserID) {			
			$userPassword = md5($_POST['password']);
			$userStatus = 0;
			$userFirstName = mysql_utils_strictly_prep(substr(trim($_POST['firstName']), 0, 30));
			$userLastName = mysql_utils_strictly_prep(substr(trim($_POST['lastName']), 0, 30));
			$userPhone = mysql_utils_strictly_prep(substr(trim($_POST['phone']), 0, 20));
			$userOrgnization = mysql_utils_strictly_prep(substr(trim($_POST['organization']), 0, 60));
			$userID = insertAutoKeyRecord($link, '`userrl`',
						array('`email`', '`password`', '`status`', '`firstName`', '`lastName`', '`phone`','`organization`', '`lastLogin`'),
						array("'$userEmail'", "'$userPassword'", "$userStatus", "'$userFirstName'", "'$userLastName'", "'$userPhone'", "'$userOrgnization'", "NOW()" ),
						'userID');
			setOneRecord($link, '`motifseq_query`', '`userID`', "$userID", '`queryID`', "$queryID");
			$_SESSION['userID'] = $userID;
			$_SESSION['userEmail'] = $userEmail;
		} else if ($userID != $AnonymousUserID) {
			setOneRecord($link, '`userrl`', '`lastLogin`', "NOW()", '`userID`', "$userID");
			if (isset($_POST['firstName']) && $_POST['firstName'] != "") {
				$userFirstName = mysql_utils_strictly_prep(substr(trim($_POST['firstName']), 0, 30));
				setOneRecord($link, '`userrl`', '`firstName`', "'".$userFirstName."'", '`userID`', "$userID");
			}
			if (isset($_POST['lastName']) && $_POST['lastName'] != "") {
				$userLastName = mysql_utils_strictly_prep(substr(trim($_POST['lastName']), 0, 30));
				setOneRecord($link, '`userrl`', '`lastName`', "'".$userLastName."'", '`userID`', "$userID");
			}
			if (isset($_POST['phone']) && $_POST['phone'] != "") {
				$userPhone = mysql_utils_strictly_prep(substr(trim($_POST['phone']), 0, 20));
				setOneRecord($link, '`userrl`', '`phone`', "'".$userPhone."'", '`userID`', "$userID");
			}
			if (isset($_POST['organization']) && $_POST['organization'] != "") {
				$userOrganization = mysql_utils_strictly_prep(substr(trim($_POST['organization']), 0, 60));
				setOneRecord($link, '`userrl`', '`organization`', "'".$userOrganization."'", '`userID`', "$userID");
			}			
			//$userFirstName = getOneRecord($link, '`user`', '`firstName`', '`userID`', "$userID"); 
			setOneRecord($link, '`motifseq_query`', '`userID`', "$userID", '`queryID`', "$queryID");
			$_SESSION['userID'] = $userID;
			$_SESSION['userEmail'] = $userEmail;
		}
		mysql_close($link);
	}
		
	$resultLink = 'index.php?page=motifseq&cmd=viewResult&queryID='.$queryID.'&cd='.SecurityEncodeFunc("$queryID");		
	header("Location: $resultLink");
	exit(1);			
	
} else if (false && $_GET['cmd'] == 'confirmQuery') {
	$logPage .= '-confirmQuery';
	
	$isConfirmSucc = false;
	$queryID = (int)$_GET['queryID'];
	if ($_GET['cd'] == SecurityEncodeFunc("$queryID")) {
		$link = mysql_connect($sql_host, $sql_username, $sql_password);
		if (!mysql_select_db($sql_database, $link)) {
			die ();
		}
		setOneRecord($link, '`motifseq_query`', '`isConfirmed`', "1", '`queryID`', "$queryID");
		mysql_close($link);
		$isConfirmSucc = true;	
	} 	
} else if ($_GET['cmd'] == 'viewResult') {
	$logPage .= '-view';
	
	$link = mysql_connect($sql_host, $sql_username, $sql_password);
	if (!mysql_select_db($sql_database, $link)) {
		die ();
	}
	$isConfirmSucc = false;
	$queryID = (int)$_GET['queryID'];
	if ($_GET['cd'] == SecurityEncodeFunc("$queryID") || $IsIgnoredSecurityCheck) {
		$security_passed = true;
		$logPage .= $queryID.'pass';
	} else {
		$security_passed = false;
		$logPage .= $queryID.'fail';
	}
			
	if ($security_passed) {
		$processingStatus = getOneRecord($link, '`motifseq_query`', '`processingStatus`', '`queryID`', "$queryID");
		$userID = getOneRecord($link, '`motifseq_query`', '`userID`', '`queryID`', "$queryID");
		$isDNAseq = getOneRecord($link, '`motifseq_query`', '`isDNAseq`', '`queryID`', "$queryID");
		if (!$isDNAseq) {
			mysql_close($link);
			$htmlProteinLink = 'index.php?page=motifproteinseq&cmd=viewResult&queryID='.$queryID.'&cd='.SecurityEncodeFunc("$queryID");
			header("Location: $htmlProteinLink");
			exit(1);
		}	
		if ($processingStatus >= 1) {			
			if ($processingStatus == 1) {
				setOneRecord($link, '`motifseq_query`', '`isConfirmed`', "1", '`queryID`', "$queryID");	
			}
			$isConfirmSucc = true;	
		}		
	}
	if (($isConfirmSucc && $processingStatus >= 1)) {
		$queryInforInHTML = GetQueryInforInHTML($link, $queryID, $processingStatus, $AnonymousUserID);
		if ($processingStatus == 3) {			
			$dnaSeqsInFasta = getOneRecord($link, '`motifseq_query`', '`normSeqsFasta`', '`queryID`', "$queryID");
			$originalDnaSeqsInFasta = getOneRecord($link, '`motifseq_query`', '`seqsFasta`', '`queryID`', "$queryID");
			$motifSeqsResultTxt = getOneRecord($link, '`motifseq_query`', '`result`', '`queryID`', "$queryID");
			$isRvrsComSeqsAdded = getOneRecord($link, '`motifseq_query`', '`isRvrsComSeqsAdded`', '`queryID`', "$queryID");
			$originalDnaSeqs = GetSeqsListWithCommentFromFastaSeq($originalDnaSeqsInFasta, &$seqComments);
			$dnaSeqs = GetSeqsListFromFastaSeq($dnaSeqsInFasta);
			$motifSeqs = GetMotifsListFromResultTxt($motifSeqsResultTxt, &$scoreList, &$maxMutationList);
			if (count($motifSeqs) > 100) {
				$motifSeqs = array_slice($motifSeqs, 0, 100);
			}
			$motifIndex = (int)$_GET['motif'];
			if ($motifIndex >= count($motifSeqs) || $motifIndex < 0) {
				$motifIndex = 0;
			}
			// $motifFoundInHTML = '<i>Following motifs are listed in the decreasing order of biological significance.</i><br>';
			// $motifFoundInHTML .= GetMotifListInHTML($queryID, $dnaSeqs, $isRvrsComSeqsAdded, $motifSeqs, $motifIndex, $scoreList);
			$numSeqsOccur = (int)(count($dnaSeqs) * 0.5);
			if (count($motifSeqs) > 0) {
				$motif = $motifSeqs[$motifIndex];
				$maxMutation = (int)$maxMutationList[$motifIndex];
				if ($_GET['param'] == 'downloadResult') {		
					mysql_close($link);	
					if ($_GET['format'] == 'text') {
						$motifLocationsFileContentType = "text";
						$motifLocationsFileFormat = "txt";					
						$motifLocationsFile = GetMotifLocationsInTxt($dnaSeqs, $seqComments, $isRvrsComSeqsAdded, $motif, $motifIndex, $maxMutation, &$numSeqsOccur, &$numMismatches);
					} else {
						$motifLocationsFileContentType = "html";
						$motifLocationsFileFormat = "html";
						$motifLocationsFile = GetInputSeqsWithMotifInHTML($dnaSeqs, $seqComments, $isRvrsComSeqsAdded, $motif, $motifIndex, $maxMutation, &$numSeqsOccur, &$numMismatches);	
					}
					//send resutl to user
					$motifLocationsFileName = "MotifLocations_QueryID".$queryID."_Motif".($motifIndex + 1).".".$motifLocationsFileFormat;
					header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
					header("Expires: ".date("Y-m-d H:i:s a", time()));
					header("Content-Type: text/".$motifLocationsFileContentType."; charset=ISO-8859-1");
					header("Content-Disposition: inline; filename=".$motifLocationsFileName.";");
					header("Content-Length: ".strlen($motifLocationsFile));
					echo $motifLocationsFile;				
					exit(0);
				}			
				$inputSeqsInHTML .= '<br><b>Probability matching matrix of selected motif</b>';
				$inputSeqsInHTML .= '<br><b>Motif '.($motifIndex + 1).': </b>'.'<b><font color="blue">'.$motif.'</font></b><br><br>';
				$inputSeqsInHTML .= '<center>';
				$inputSeqsInHTML .= GetProbMatchingMatrixInHTML($dnaSeqs, $isRvrsComSeqsAdded, $motif, $maxMutation);
				$inputSeqsInHTML .= '</center>';
				$inputSeqsInHTML .= GetInputSeqsWithMotifInHTML($dnaSeqs, $seqComments, $isRvrsComSeqsAdded, $motif, $motifIndex, $maxMutation, &$numSeqsOccur, &$numMismatches);	
			} else {
				$inputSeqsInHTML = GetInputSeqsInHTML($dnaSeqs, $seqComments, $isRvrsComSeqsAdded);
			}
			$motifFoundInHTML = GetMotifListInHTML($queryID, $dnaSeqs, $isRvrsComSeqsAdded, $motifSeqs, $motifIndex, $scoreList, $numSeqsOccur, $numMismatches);
		} else {
			$htmlLink = "'index.php?page=motifseq&cmd=viewResult&queryID=".$queryID.'&cd='.SecurityEncodeFunc("$queryID")."'";
			$motifFoundInHTML = 'Not available. PLease wait ...'; 
			$motifFoundInHTML .='<br><input type="button" value="Refresh" onclick="window.location.href='.$htmlLink.'"/>';
			if ($userID == $AnonymousUserID) {
				$motifFoundInHTML .= '<br><i>You can save the link, close your web browser and check it back later. Or let us know your email by clicking the "Update" button. We will send you a notification email as soon as the result is available. The notification email will include the link to the result. Your email will be kept confidential. Thank you.</i>';
			} else {
				$motifFoundInHTML .= '<br><i>You can save the link, close your web browser and check it back later. We will send you a notification email as soon as the result is available. The notification email will include the link to the result. Your email will be kept confidential. Thank you.</i>';
			}
			$dnaSeqsInFasta = getOneRecord($link, '`motifseq_query`', '`seqsFasta`', '`queryID`', "$queryID");
			$dnaSeqs = GetSeqsListWithCommentFromFastaSeq($dnaSeqsInFasta, &$seqComments);
			$inputSeqsInHTML = GetInputSeqsInHTML($dnaSeqs, $seqComments, $isRvrsComSeqsAdded);	
		}		
	}	
	mysql_close($link);	
}
?>

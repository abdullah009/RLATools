<div id="publication">
    <center><font size="+3" color="#666600">Download publications</font></center>
    
    <ol>
    
    <li><p>
    Abdullah-Al Mamun, Tian Mi, Robert Aseltine and Sanguthevar Rajasekaran.
    <b>"Efficient sequential and parallel algorithms for record linkage"</b>. 
    <i>J Am Med Inform Assoc</i>.
    2014; 21:252-262. <a href="http://jamia.bmj.com/content/21/2/252.full" target="_blank" class="headertext">[link]</a>
    <a href="http://jamia.bmj.com/content/21/2/252.full.pdf+html" target="_blank">[full text]</a>
    </p></li>
    
    <li><p>
    Tian Mi, Sanguthevar Rajasekaran and Robert Aseltine.
    <b>"Efficient algorithms for fast integration on large data sets from multiple sources"</b>. 
    <i>Med Inform Decis Mak</i>.
    2012;12:59. <a href="http://www.biomedcentral.com/1472-6947/12/59" target="_blank" class="headertext">[link]</a>
    <a href="http://www.biomedcentral.com/content/pdf/1472-6947-12-59.pdf" target="_blank" class="headertext">[full text]</a>
    </p></li>
    
    <li><p>
    Sanguthevar Rajasekaran.
    <b>" Efficient parallel hierarchical clustering algorithms"</b>. 
    <i>IEEE Trans Parallel Distrib Syst</i>.
    2005, 16(6):497-502. <a href="http://www.dimap.ufrn.br/~motta/dim070/Apresentacoes/ParallelClustering.pdf" target="_blank" class="headertext">[link]</a>
    <a href="http://www.dimap.ufrn.br/~motta/dim070/Apresentacoes/ParallelClustering.pdf" target="_blank" class="headertext">[full text]</a>
    </p></li>
    
    </ol>
</div>
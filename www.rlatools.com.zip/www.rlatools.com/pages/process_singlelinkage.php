<?php
	
	$isValidData = false;
	$invalidDataErrorMessage = "";
	$emailDeliverySucc = false;	
	$captcha_passed = true;
	
	$isConfirmSucc = false;
	$processingStatus = 1;
	$queryInforInHTML = "";
	$jobName	= "";
	$jobLink	= "";
	$linkageMethod	= 1; // for single linkage 2 for complete linkage
	
	function createConfigXML()
	{
		global $jobName, $jobLink;
		
		$jobName	= $_POST['email'] . '_' . time();
		$dir		= 'resource/' . $jobName . '/';	
		$jobLink	= "http://www.rlatools.com/download_output.php?cmd=download&link=/" . $dir . "output.csv";
		mkdir($dir, 0777);
		
		$configXML	= new DOMDocument('1.0', 'utf-8');
		$configXML->formatOutput	= true;
		
		$root	= $configXML->createElement('rla-config');
		$root	= $configXML->appendChild($root);
		
		// dataset
		$datasetTotal	= $_POST['dataset_total'];
		$attrTotal		= $_POST['attribute_total'];
		for ($i = 0; $i < $datasetTotal; ++$i)
		{
			$name	= 'dataset' . $i;
			$dataset	= $configXML->createElement('dataset');
			
			$attr	= $configXML->createAttribute('name');
			$attr->value	= $name;
			$dataset->appendChild($attr);
			$attr	= $configXML->createAttribute('id');
			$attr->value	= '' + $i;
			$dataset->appendChild($attr);
			
			$value	= $configXML->createElement('value', $dir . $_FILES["$name"]["name"]);
			
			$valStr	= '';
			for ($j = 0; $j < $attrTotal; ++$j)
				if ($j < $attrTotal - 1)
					$valStr	= $valStr . $_POST['attribute_index' . $i . '_' . $j] . " ";
				else
					$valStr	= $valStr . $_POST['attribute_index' . $i . '_' . $j];
			$index	= $configXML->createElement('index', $valStr);
			
			$dataset->appendChild($value);
			$dataset->appendChild($index);
			
			$root->appendChild($dataset);
		}
		
		// comparison
		$comparisonGrp	= $configXML->createElement('version-config-param');
		$attr	= $configXML->createAttribute('id');
		$attr->value	= 'ComparisonGroup';
		$comparisonGrp->appendChild($attr);
		
		$compTotal		= $_POST['comparison_total'];
		for ($i = 0; $i < $compTotal; ++$i)
		{		
			$comparison	= $configXML->createElement('comparison');
			$attr	= $configXML->createAttribute('id');
			$attr->value	= $i;
			$comparison->appendChild($attr);
		
			$method		= $configXML->createElement('dist_calc_method', $_POST['comparison' . $i]);
			if ($_POST['comparison' . $i] == "2")
				$index		= $configXML->createElement('comparing_attribute_indices', $_POST['comparison_index' . $i] . ',' . $_POST['comparison2_index' . $i]);
			else
				$index		= $configXML->createElement('comparing_attribute_indices', $_POST['comparison_index' . $i]);
			$truncation	= $configXML->createElement('truncation_count', $_POST['truncation_count' . $i]);	
			$comparison->appendChild($method);
			$comparison->appendChild($index);
			if ($_POST['comparison' . $i] == "3")
				$comparison->appendChild($truncation);
			
			$comparisonGrp->appendChild($comparison);	
		}
		
		if ($_POST['threshold'] != '')
			$comparisonGrp->appendChild($configXML->createElement('threshold', $_POST['threshold']));
		else
			$comparisonGrp->appendChild($configXML->createElement('threshold', 1));
		
		$block	= $configXML->createElement('block');
		$block->appendChild($configXML->createElement('index', $_POST['block_index']));
		if ($_POST['block_length'] != '')
			$block->appendChild($configXML->createElement('length', $_POST['block_length']));
		else
			$block->appendChild($configXML->createElement('length', 7));
		$comparisonGrp->appendChild($block);
		
		$root->appendChild($comparisonGrp);		
		
		$titleField	= "";
		for ($i = 0; $i < $attrTotal - 1; ++$i)
		{
			if ($_POST['attribute' . $i] == '')
				$titleField	= $titleField . "Field_" . $i . ",";
			else
				$titleField	= $titleField . $_POST['attribute' . $i] . ",";
		}
		if ($_POST['attribute' . ($attrTotal - 1)] == '')
			$titleField	= $titleField . "Field_" . ($attrTotal - 1);
		else
			$titleField	= $titleField . $_POST['attribute' . ($attrTotal - 1)];
		$title		= $configXML->createElement('title', $titleField);
		$root->appendChild($title);
		// output 
		$output		= $configXML->createElement('output_function');
		$outputFile	= $configXML->createElement('output_file', 'resource/'.$jobName.'/');
		$root->appendChild($output);	
		$output->appendChild($outputFile);	
		
		$configXML->save($dir . "ConfigRLA_SL.xml");
	}
	

?>
<?php
/*
	function PrintSubmissionHistory($link, $userID, $userEmail, $password_md5, 
								$numSubmission, $numSubPerPart, $partIdx, 
								$sortField, $sortDirection, $sortFieldHeader, $sortDirectionHeader) {
								
	$numPart = $numSubmission/$numSubPerPart;
	if (($numSubmission % $numSubPerPart) != 0) $numPart++;
	if ($partIdx > $numPart) $partIdx = $numPart;
	$minIdx = ($partIdx - 1) * $numSubPerPart;
	
	if ($sortDirectionHeader ==  'ASC') $sortDirectionHeaderCode = 'inc'; 
	else $sortDirectionHeaderCode = 'dec';
		
	$sqlQuery = 'SELECT `queryID`, `timeLimit`, `quorumPercent`, 
						`bindingLen1Min`, `bindingLen1Max`, 
						`bindingGapMin`, `bindingGapMax`, 
						`bindingLen2Min`, `bindingLen2Max`,
						`seqsFasta`, `isDNAseq`, `isRvrsComSeqsAdded`, 
						`seqsDescription`, `submissionTime`, `processingStatus`, `result`
				FROM `motifseq_query` WHERE `userID`='.$userID. ' ORDER BY `'.$sortField.'` '.$sortDirection. ' LIMIT '.$minIdx.','.$numSubPerPart;

	$commonHeader = '<a href="index.php?page=submissionhistory&cmd=viewhistorypage&email='.$userEmail.'&cd='.$password_md5;
	if ($sortFieldHeader == 'queryID') {
		$queryHeader = $commonHeader.'&sortField=query&sortDir='.$sortDirectionHeaderCode.'">Query No </a>';
	} else {
		$queryHeader = $commonHeader.'&sortField=query&sortDir=dec">Query No </a>';
	}
	$queryHeaderSort = '<b>sort<b/><br>'.$commonHeader.'&sortField=query&sortDir=inc"> <img src="images/system/arrow_up.gif" alt="sort increasingly" width="25" height="25" border="0" /> </a><br>';
	$queryHeaderSort .= $commonHeader.'&sortField=query&sortDir=dec"> <img src="images/system/arrow_down.gif" alt="sort decreasingly" width="25" height="25" border="0" /> </a>';
	
	if ($sortFieldHeader == 'submissionTime') {
		$timeHeader = $commonHeader.'&sortField=time&sortDir='.$sortDirectionHeaderCode.'">Submission time </a>';
	} else {
		$timeHeader = $commonHeader.'&sortField=time&sortDir=dec">Submission time </a>';
	}
	$timeHeaderSort = '<b>sort<b/><br>'.$commonHeader.'&sortField=time&sortDir=inc"> <img src="images/system/arrow_up.gif" alt="sort increasingly" width="25" height="25" border="0" /> </a><br>';
	$timeHeaderSort .= $commonHeader.'&sortField=time&sortDir=dec"> <img src="images/system/arrow_down.gif" alt="sort decreasingly" width="25" height="25" border="0" /> </a>';
	
	if ($sortFieldHeader == 'processingStatus') {
		$statusHeader = $commonHeader.'&sortField=status&sortDir='.$sortDirectionHeaderCode.'">Status </a>';
	} else {
		$statusHeader = $commonHeader.'&sortField=status&sortDir=dec">Status </a>';
	}
	$statusHeaderSort = '<b>sort<b/><br>'.$commonHeader.'&sortField=status&sortDir=inc"> <img src="images/system/arrow_up.gif" alt="sort increasingly" width="25" height="25" border="0" /> </a><br>';
	$statusHeaderSort .= $commonHeader.'&sortField=status&sortDir=dec"> <img src="images/system/arrow_down.gif" alt="sort decreasingly" width="25" height="25" border="0" /> </a>';
	
	echo '<table width="100%">';
	echo '<tr align="left" valign="top" bgcolor="#FF33FF">';
	echo '<td><b>'.$queryHeader.'</b></td>';
	echo '<td><b>'.$timeHeader.'</b></td>';	
	echo '<td><b>Data</b></td>';
	echo '<td><b>Parameters</b></td>';
	echo '<td><b>Description</b></td>';	
	echo '<td><b>'.$statusHeader.'</b></td>';
	echo '<td><b>Result<b></td>';
	echo '</tr>';

	echo '<tr align="center" valign="top" bgcolor="#FF33FF">';
	echo '<td><b>'.$queryHeaderSort.'</b></td>';
	echo '<td><b>'.$timeHeaderSort.'</b></td>';	
	echo '<td><b>&nbsp;</b></td>';
	echo '<td><b>&nbsp;</b></td>';
	echo '<td><b>&nbsp;</b></td>';	
	echo '<td><b>'.$statusHeaderSort.'</b></td>';
	echo '<td><b>&nbsp;<b></td>';
	echo '</tr>';
	
	$result = mysql_query($sqlQuery, $link);
	$count = 0;
	while( ($row = mysql_fetch_array($result)) ) {
		if ($row['isDNAseq'] == 1) {		
			$queryTxt = '<a target="_blank" href="index.php?page=motifseq&cmd=viewResult&queryID='.$row['queryID'].'&cd='.SecurityEncodeFunc($row['queryID']).'"><b>'.$row['queryID'].'</b></a>';
			$queryTxt .= '<br><br><a target="_blank" href="index.php?page=motifseq&cmd=viewResult&queryID='.$row['queryID'].'&cd='.SecurityEncodeFunc($row['queryID']).'">View detail</a>';
		} else {
			$queryTxt = '<a target="_blank" href="index.php?page=motifproteinseq&cmd=viewResult&queryID='.$row['queryID'].'&cd='.SecurityEncodeFunc($row['queryID']).'"><b>'.$row['queryID'].'</b></a>';
			$queryTxt .= '<br><br><a target="_blank" href="index.php?page=motifproteinseq&cmd=viewResult&queryID='.$row['queryID'].'&cd='.SecurityEncodeFunc($row['queryID']).'">View detail</a>';
		}
	
		$seqList = GetSeqsListFromFastaSeq($row['seqsFasta']);
		$numSeq = count($seqList);
		$totalLen = 0;
		for ($i = 0; $i < $numSeq; $i++) {
			$totalLen += strlen($seqList[$i]);
		}
		if ($row['isDNAseq'] == 1) $dataTxt = 'Seq type: <b>DNA</b>';
		else $dataTxt = 'Seq type: <b>Protein</b>';
		$dataTxt .= '<br>#seqs: <b>'.$numSeq.'</b>';
		$dataTxt .= '<br>Total length: <b>'.$totalLen.'</b>';
		
		if ($row['timeLimit'] <= 10) $paramsTxt = '<b>Quick Search</b>';
		else $paramsTxt = '<b>Full Search</b>';
		$paramsTxt .= '<br>Quorum percent: <b>'.$row['quorumPercent'].'</b>';
		if ($row['isDNAseq'] == 1) {
			if ($row['isRvrsComSeqsAdded'] == 1) $paramsTxt .= '<br>Add rvrs cmplmnt: <b>Yes</b>';
			else $paramsTxt .= '<br>Add rvrs cmplmnt: <b>No</b>';
		}
		if ($row['bindingLen2Min'] == 0 && $row['bindingLen2Max'] == 0) {
			$paramsTxt .= '<br><b>Single-box</b>';
			if ($row['bindingLen1Min'] == $row['bindingLen1Max'] ) $paramsTxt .= '<br>Length: <b>'.$row['bindingLen1Min'].'</b>';
			else $paramsTxt .= '<br>Length: <b>Any</b>';
		} else {
			$paramsTxt .= '<br><b>Double-box</b>';
			if ($row['bindingLen1Min'] == $row['bindingLen1Max'] ) $paramsTxt .= '<br>1st length: <b>'.$row['bindingLen1Min'].'</b>';
			else $paramsTxt .= '<br>1st length: <b>Any</b>';
			if ($row['bindingGapMin'] == $row['bindingGapMax'] ) $paramsTxt .= '<br>gap length: <b>'.$row['bindingGapMin'].'</b>';
			else $paramsTxt .= '<br>gap length: <b>Any</b>';
			if ($row['bindingLen2Min'] == $row['bindingLen2Max'] ) $paramsTxt .= '<br>2nd length: <b>'.$row['bindingLen2Min'].'</b>';
			else $paramsTxt .= '<br>2nd length: <b>Any</b>';		
		}
		if ($row['processingStatus'] == 1) $processingStatusTxt = '<b>in processing queue</b>';
		else if ($row['processingStatus'] == 2) $processingStatusTxt = '<b>being processed</b>';
		else if ($row['processingStatus'] == 3) $processingStatusTxt = '<b>processed</b>';
		else $processingStatusTxt = '<b>unprocessed</b>';
		
		if ($row['processingStatus'] == 3) {
			$motifList = GetMotifsListFromResultTxt($row['result'], &$scoreList, &$maxMutationList);
			$resultTxt = '#motifs: <b>'.count($motifList).'</b>';
		} else {
			$resultTxt = 'Not available';
		}
		
		if ($count % 2 == 0) {
			echo '<tr align="left" valign="top" bgcolor="#CCCCFF">';
		} else {
			echo '<tr align="left" valign="top"  bgcolor="#CCFFFF">';
		}
		echo '<td>'.$queryTxt.'</td>';
		echo '<td>'.$row['submissionTime'].'</td>';
		echo '<td>'.$dataTxt.'</td>';		
		echo '<td>'.$paramsTxt.'</td>';
		echo '<td>'.substr(trim($row['seqsDescription']), 0, 20).'</td>';
		echo '<td>'.$processingStatusTxt.'</td>';
		echo '<td>'.$resultTxt.'</td>';
		echo '</tr>';
		$count++;
	}
	mysql_free_result($result);
	echo '</table>';
}

function PrintSubmissionHistoryPage($userEmail, $password_md5, $numSubmission, $numSubPerPart, $partIdx, $sortField, $sortDirection) {
	if ($sortField == 'queryID')  $sortFieldCode = 'query'; 
	else if ($sortField == 'submissionTime') $sortFieldCode = 'time'; 
	else if ($sortField == 'processingStatus') $sortFieldCode = 'status'; 
	else $sortFieldCode  = 'query';
	
	if ($sortDirection ==  'ASC') $sortDirectionCode = 'inc'; 
	else $sortDirectionCode = 'dec';
	
	echo '<table><tr valign="top" align="left"><td><b>Page: </b></td><td>';
	$numPart = $numSubmission/$numSubPerPart;
	if (($numSubmission % $numSubPerPart) != 0) $numPart++;
	for ($i = 1; $i <= $numPart; $i++) {
		if ($i == $partIdx) {
			echo '<b><a href="index.php?page=submissionhistory&cmd=viewhistorypage&idx='.$i.'&email='.$userEmail.'&cd='.$password_md5;
			echo '&sortField='.$sortFieldCode.'&sortDir='.$sortDirectionCode.'">'.$i.'</a></b>, ';
		} else {
			echo '<a href="index.php?page=submissionhistory&cmd=viewhistorypage&idx='.$i.'&email='.$userEmail.'&cd='.$password_md5;
			echo '&sortField='.$sortFieldCode.'&sortDir='.$sortDirectionCode.'">'.$i.'</a>, ';
		}
		if ($i % 30 == 0) echo '<br>'; 
	}
	echo '</td></tr></table>';
}

*/


	function PrintSubmissionHistory($link, $userID, $userEmail, $password_md5, 
								$numSubmission, $numSubPerPart, $partIdx, 
								$sortField, $sortDirection, $sortFieldHeader, $sortDirectionHeader) 
								{
								
	$numPart = $numSubmission/$numSubPerPart;
	if (($numSubmission % $numSubPerPart) != 0) $numPart++;
	if ($partIdx > $numPart) $partIdx = $numPart;
	$minIdx = ($partIdx - 1) * $numSubPerPart;
	
	if ($sortDirectionHeader ==  'ASC') $sortDirectionHeaderCode = 'inc'; 
	else $sortDirectionHeaderCode = 'dec';
		
	$sqlQuery = 'SELECT `queryID`, `submissionTime`, `latestUpdateTime`, 
						`processingStatus`, `linkageMethod`, 
						`jobName`, `jobLink`
				FROM `rla_query` WHERE `userID`='.$userID. ' ORDER BY `'.$sortField.'` '.$sortDirection. ' LIMIT '.$minIdx.','.$numSubPerPart;
	
	echo '<table width="100%">';
	echo '<tr align="left" valign="top" bgcolor="#CCCCCC">';
	echo '<td><b>queryID</b></td>';
	echo '<td><b>submissionTime</b></td>';	
	echo '<td><b>latestUpdateTime</b></td>';
	echo '<td><b>processingStatus</b></td>';
	echo '<td><b>jobLink</b></td>';	
	echo '</tr>';
	
	$result = mysqli_query($link, $sqlQuery);
	$count = 0;
	while( ($row = mysqli_fetch_array($result)) ) {
		/*if ($row['isDNAseq'] == 1) {		
			$queryTxt = '<a target="_blank" href="index.php?page=motifseq&cmd=viewResult&queryID='.$row['queryID'].'&cd='.SecurityEncodeFunc($row['queryID']).'"><b>'.$row['queryID'].'</b></a>';
			$queryTxt .= '<br><br><a target="_blank" href="index.php?page=motifseq&cmd=viewResult&queryID='.$row['queryID'].'&cd='.SecurityEncodeFunc($row['queryID']).'">View detail</a>';
		} else {
			$queryTxt = '<a target="_blank" href="index.php?page=motifproteinseq&cmd=viewResult&queryID='.$row['queryID'].'&cd='.SecurityEncodeFunc($row['queryID']).'"><b>'.$row['queryID'].'</b></a>';
			$queryTxt .= '<br><br><a target="_blank" href="index.php?page=motifproteinseq&cmd=viewResult&queryID='.$row['queryID'].'&cd='.SecurityEncodeFunc($row['queryID']).'">View detail</a>';
		}
	
		$seqList = GetSeqsListFromFastaSeq($row['seqsFasta']);
		$numSeq = count($seqList);
		$totalLen = 0;
		for ($i = 0; $i < $numSeq; $i++) {
			$totalLen += strlen($seqList[$i]);
		}
		if ($row['isDNAseq'] == 1) $dataTxt = 'Seq type: <b>DNA</b>';
		else $dataTxt = 'Seq type: <b>Protein</b>';
		$dataTxt .= '<br>#seqs: <b>'.$numSeq.'</b>';
		$dataTxt .= '<br>Total length: <b>'.$totalLen.'</b>';
		
		if ($row['timeLimit'] <= 10) $paramsTxt = '<b>Quick Search</b>';
		else $paramsTxt = '<b>Full Search</b>';
		$paramsTxt .= '<br>Quorum percent: <b>'.$row['quorumPercent'].'</b>';
		if ($row['isDNAseq'] == 1) {
			if ($row['isRvrsComSeqsAdded'] == 1) $paramsTxt .= '<br>Add rvrs cmplmnt: <b>Yes</b>';
			else $paramsTxt .= '<br>Add rvrs cmplmnt: <b>No</b>';
		}
		if ($row['bindingLen2Min'] == 0 && $row['bindingLen2Max'] == 0) {
			$paramsTxt .= '<br><b>Single-box</b>';
			if ($row['bindingLen1Min'] == $row['bindingLen1Max'] ) $paramsTxt .= '<br>Length: <b>'.$row['bindingLen1Min'].'</b>';
			else $paramsTxt .= '<br>Length: <b>Any</b>';
		} else {
			$paramsTxt .= '<br><b>Double-box</b>';
			if ($row['bindingLen1Min'] == $row['bindingLen1Max'] ) $paramsTxt .= '<br>1st length: <b>'.$row['bindingLen1Min'].'</b>';
			else $paramsTxt .= '<br>1st length: <b>Any</b>';
			if ($row['bindingGapMin'] == $row['bindingGapMax'] ) $paramsTxt .= '<br>gap length: <b>'.$row['bindingGapMin'].'</b>';
			else $paramsTxt .= '<br>gap length: <b>Any</b>';
			if ($row['bindingLen2Min'] == $row['bindingLen2Max'] ) $paramsTxt .= '<br>2nd length: <b>'.$row['bindingLen2Min'].'</b>';
			else $paramsTxt .= '<br>2nd length: <b>Any</b>';		
		}
		if ($row['processingStatus'] == 1) $processingStatusTxt = '<b>in processing queue</b>';
		else if ($row['processingStatus'] == 2) $processingStatusTxt = '<b>being processed</b>';
		else if ($row['processingStatus'] == 3) $processingStatusTxt = '<b>processed</b>';
		else $processingStatusTxt = '<b>unprocessed</b>';
		
		if ($row['processingStatus'] == 3) {
			$motifList = GetMotifsListFromResultTxt($row['result'], &$scoreList, &$maxMutationList);
			$resultTxt = '#motifs: <b>'.count($motifList).'</b>';
		} else {
			$resultTxt = 'Not available';
		}
		
		if ($count % 2 == 0) {
			echo '<tr align="left" valign="top" bgcolor="#CCCCFF">';
		} else {
			echo '<tr align="left" valign="top"  bgcolor="#CCFFFF">';
		}
		*/
		$queryID			= $row['queryID'];
		$submissionTime		= $row['submissionTime'];
		$latestUpdateTime	= $row['latestUpdateTime'];
		if ($row['processingStatus'] == 1)
			$processingStatus	= "In Process";
		else if ($row['processingStatus'] == 3)
			$processingStatus	= "Completed";
		else
			$processingStatus	= "Error Occurred";
		$jobLink			= $row['jobLink'];
		
		echo '<tr align="left" valign="top" bgcolor="#ffffff">';
		echo '<td><b>'.$queryID.'</b></td>';
		echo '<td><b>'.$submissionTime.'</b></td>';	
		echo '<td><b>'.$latestUpdateTime.'</b></td>';
		echo '<td><b>'.$processingStatus.'</b></td>';
		
		if ($row['processingStatus'] == 3)
			echo '<td><b><a href='.$jobLink.' target="_blank">Download File</b></td>';	
		echo '</tr>';
		
		$count++;
	}
	mysqli_free_result($result);
	echo '</table>';
}

	if (isset($_POST['cmd']) && $_POST['cmd'] == 'send_new_password') // to reset password
	{			
		$captcha_passed = true;
	
		if ($captcha_passed) 
		{
			$userEmail = mysql_utils_strictly_prep(substr(trim($_POST['email']), 0, 50));
			$userEmail = strtolower($userEmail);
		
			$isSendEmailSucc = true;
			$headers = "From: noreply@$websiteDomain\r\n" . "X-Mailer: php";
			$body = "Hello, \nYou have requested to reset your password from $websiteDomain. Click the link below to change your password."; 
			$body .= "\n\nhttp://$websiteDomain/index.php?page=submissionhistory&cmd=setpass&email=".$userEmail."&cd=".SecurityEncodeFunc($userEmail);
			$body .= "\n\nSincerely, \n$websiteDomain";			
			if (mail($userEmail, "$websiteDomain: you have requested to reset your password", $body, $headers)) {
				$emailDeliverySucc = true;
			} else {
				$isSendEmailSucc = false;
			}
			
			$link = mysqli_connect($sql_host, $sql_username, $sql_password);
			if (!mysqli_select_db($link, $sql_database)) die ();		
			$userID = getOneRecord($link, '`userrl`', '`userID`', '`email`', "'$userEmail'"); 
			if ($userID < 2) {
				$userID = insertAutoKeyRecord($link, '`userrl`',
								array('`email`', '`password`', '`lastLogin`'),
								array("'$userEmail'", "'".md5($randPassword)."'", "NOW()" ),
								'userID');
			}
			mysqli_close($link);		
		}
		
		if (isset($_POST['cmd_noaction']) && $captcha_passed && $isSendEmailSucc) {
			echo '<table align="center"><td id="submission">';
			echo '<br><br>An email has been successfully sent to <b>'.$userEmail.'</b><br>';
			echo 'Please check your email. Thank you.';
			echo '</td></table>';
		} else {	
			include_once('forms/form_sendtemppass.php');
		}
		
	} 
	else if (isset($_POST['cmd']) && $_POST['cmd'] == 'set_password') 
	{
		$cd = substr(trim($_POST['cd']), 0, 50); 
		$userEmail = mysql_utils_strictly_prep(substr(trim($_POST['email']), 0, 50));
		$userEmail = strtolower($userEmail);
		$passwordNew = mysql_utils_strictly_prep(substr(trim($_POST['password_new']), 0, 50));
		$passwordNewAgain = mysql_utils_strictly_prep(substr(trim($_POST['password_new_again']), 0, 50));
		if ($passwordNew == $passwordNewAgain && $cd == SecurityEncodeFunc("$userEmail")) {
			$isValidPassword = true;
		} else {
			$isValidPassword = false;
		}
		if ($isValidPassword) {
			$link = mysqli_connect($sql_host, $sql_username, $sql_password);
			if (!mysqli_select_db($link, $sql_database)) die ();		
			$userID = getOneRecord($link, '`userrl`', '`userID`', '`email`', "'$userEmail'"); 
			if ($userID > 1) {
				setOneRecord($link, '`userrl`', '`password`', "'".md5($passwordNew)."'", '`userID`', "$userID");
				$_SESSION['userID'] = $userID;
				$_SESSION['userEmail'] = $userEmail;			
			}
			mysqli_close($link);
			echo '<br><b><center>Your password has been changed</b>.</center><br>';
			echo '<center><b><a href="index.php?page=submissionhistory">Click here to view your submission history</a></b></center><br>';
		} else {
			include_once('forms/form_setpass.php');
		}		
	} 
	else if (isset($_POST['cmd']) && $_POST['cmd'] == 'change_password') 
	{
		if ($_POST['cmd_changepass'] == 'Submit') 
		{
			$userEmail = mysql_utils_strictly_prep(substr(trim($_POST['email']), 0, 50));
			$userEmail = strtolower($userEmail);
			$password = mysql_utils_strictly_prep(substr(trim($_POST['password']), 0, 50));
			$passwordNew = mysql_utils_strictly_prep(substr(trim($_POST['password_new']), 0, 50));
			$passwordNewAgain = mysql_utils_strictly_prep(substr(trim($_POST['password_new_again']), 0, 50));
			$link = mysqli_connect($sql_host, $sql_username, $sql_password);
			if (!mysqli_select_db($link, $sql_database)) die ();		
			$userID = (int)getOneRecord($link, '`userrl`', '`userID`', '`email`', "'$userEmail'"); 
			$password_md5 = getOneRecord($link, '`userrl`', '`password`', '`email`', "'$userEmail'");
			//echo $userEmail . ' ' . $userID . ' ' .  $password . ' ' . $password_md5 .  ' ' . md5($password). '<br/>';
			if ($passwordNew == $passwordNewAgain && $password_md5 == md5($password)) 
			{
				$isValidPassword = true;
				setOneRecord($link, '`userrl`', '`password`', "'".md5($passwordNew)."'", '`userID`', "$userID");
				$_SESSION['userID'] = $userID;
				$_SESSION['userEmail'] = $userEmail;			
			} else {
				$isValidPassword = false;
			}
			mysqli_close($link);
			if ($isValidPassword) {		
				echo '<br><b><center>Your password has been changed</b>.</center><br>';
				echo '<center><b><a href="index.php?page=submissionhistory">Click here to view your submission history</a></b></center><br>';
			} else {			
				include_once('forms/form_changepass.php');
			}
		} 
		else if ($_POST['cmd_changepass'] == 'Cancel') 
		{
			include_once('forms/form_loginviewhistory.php');
		} 
		else 
		{
			include_once('forms/form_changepass.php');
		}
		
	} 
	else if (isset($_POST['cmd']) && $_POST['cmd'] == 'view_submission_history') 
	{
		$sortField = 'queryID'; 
		$sortDirection = 'DESC';
		$sortFieldHeader = 'queryID'; 
		$sortDirectionHeader = 'ASC';	
		$numSubPerPart = 10;
		$partIdx = 1;
		$userEmail = mysql_utils_strictly_prep(substr(trim($_POST['email']), 0, 50));
		$userEmail = strtolower($userEmail);
		$password = mysql_utils_strictly_prep(substr(trim($_POST['password']), 0, 50));
		$link = mysqli_connect($sql_host, $sql_username, $sql_password);
		if (!mysqli_select_db($link, $sql_database)) die ();		
		$userID = (int)getOneRecord($link, '`userrl`', '`userID`', '`email`', "'$userEmail'"); 
		$password_md5 = getOneRecord($link, '`userrl`', '`password`', '`email`', "'$userEmail'");
		if ($userID > 1 && $password_md5 == md5($password)) {
			$isValidPassword = true;
			$_SESSION['userID'] = $userID;
			$_SESSION['userEmail'] = $userEmail;		
		} else {
			$isValidPassword = false;
		}
	
		include_once('forms/form_loginviewhistory.php');
		if ($isValidPassword) {		
			$sqlQuery = 'SELECT COUNT(*) as `countRow` FROM `rla_query` WHERE `userID`='.$userID;
			$result = mysqli_query($link, $sqlQuery);
			$row = mysqli_fetch_array($result);
			$numSubmission = (int)$row['countRow'];
			mysqli_free_result($result);
			if ($numSubmission > 0) { 	
				echo '<br><font size="+2" color="#3366FF">Submission history of <b><i>'.$userEmail.'</i></b></b></font><br><br>';
				PrintSubmissionHistory($link, $userID, $userEmail, $password_md5, 
										$numSubmission, $numSubPerPart, $partIdx, 
										$sortField, $sortDirection, $sortFieldHeader, $sortDirectionHeader);
				echo '<br>';		
				//PrintSubmissionHistoryPage($userEmail, $password_md5, $numSubmission, $numSubPerPart, $partIdx, $sortField, $sortDirection);
				echo '<br><br>';
			} else {
				echo '<br><b>No submissions</b>';
			}
		}
		mysqli_close($link);
		
	}  
	else if (isset($_GET['cmd']) && $_GET['cmd'] == 'sendpass') // reset password form
	{
		include_once('forms/form_sendtemppass.php');
	} 
	else if (isset($_GET['cmd']) && $_GET['cmd'] == 'setpass') // to set new password from email link
	{
		$userEmail = strtolower(substr(trim($_GET['email']), 0, 50));
		$cd =  substr(trim($_GET['cd']), 0, 50);
		if ($cd == SecurityEncodeFunc("$userEmail")) {
			include_once('forms/form_setpass.php');
		}else {
			echo '<br>Your link is invalid.<br>';
		}
	} 
	else if (isset($_GET['cmd']) && $_GET['cmd'] == 'changepass') // change password form
	{
		include_once('forms/form_changepass.php');			
	} 
	else if (isset($_GET['cmd']) && $_GET['cmd'] == 'viewhistory') 
	{
		include_once('forms/form_loginviewhistory.php');		
	} 
	else 
	{
		include_once('forms/form_loginviewhistory.php');	
	}
?>

<?php
	//echo $_SERVER['DOCUMENT_ROOT'] . "<br>";
	$path	= $_SERVER['DOCUMENT_ROOT']."/resource/sample/" . $_GET['filename'];
	//echo $path . "<br/>";
	if (is_readable($path))
	{
		header("Content-type: text/csv");
		header("Content-disposition: attachment; filename=".$_GET['filename']);
		readfile($path);
		exit;
	}
	else
	{
		die("Invalid Request");
	}

?>
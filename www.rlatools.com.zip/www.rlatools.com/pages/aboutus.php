<div id="people">
    <center><font size="+3" color="#666600">About us</font></center><br />
    <hr>
</div>

    <table width="100%">
        <tr>
        <td valign = "top" align = "center" width = "400">    	
            <img src="images/people/raj-mug-small.JPG" alt="image"/>
            
        </td>
        <td valign = "top" align = "left" id="people"><b>Sanguthevar Rajasekaran</b><br>
            Professor at <a href="http://www.cse.uconn.edu" target="_blank" class="headertext"> Computer Science and Engineering Department</a>,<br>
            <a href="http://www.uconn.edu" target="_blank" class="headertext"> University of Connecticut</a><br>
            <a href="http://www.becat.uconn.edu/" target="_blank" class="headertext">BECAT</a> Director<br>
            Phone: (860)486-2428<br>
            Fax: (860)486-4817<br>
            Office: ITEB 257<br>		  
            Email: <a href = "mailto:rajasek@engr.uconn.edu" class="headertext">rajasek@engr.uconn.edu</a><br>
            Web: <a href = "http://www.engr.uconn.edu/~rajasek" target="_blank" class="headertext">Personal Page</a>
        </td>
        </tr>
    </table>
    
    <br />
    <br />
    
    <hr>
    <table width="100%">
        <tr>
            <td valign = "top" align = "center" width = "400">    
                <div class="wrap-blend">		
                <img src="images/people/abdullah02.JPG" alt="image"/>
                </div>
            </td>
            <td valign = "top" align = "left" id="people"><b>Abdullah-Al Mamun</b><br>
                PhD Student at <a href="http://www.cse.uconn.edu" target="_blank" class="headertext"> Computer Science and Engineering Department</a>,<br>
                <a href="http://www.uconn.edu" target="_blank" class="headertext"> University of Connecticut</a><br>
                Phone: (860)771-8173<br>
                Office: BECAT A38<br>		  
                Email: <a href = "mailto:abdullah.am.cs@engr.uconn.edu" class="headertext">abdullah.am.cs@engr.uconn.edu</a><br>
                Web: <a href = "http://www.engr.uconn.edu/~abm12008" target="_blank" class="headertext">Personal Page</a>
            </td>
        </tr>
    </table>
    
    <br />
    <br />
    
    <hr>
    <table width="100%">
        <tr>
            <td valign = "top" align = "center" width = "400">    
                <div class="wrap-blend">		
                <img src="images/people/aseltine01.JPG" alt="image"/>
                </div>
            </td>
            <td valign = "top" align = "left" id="people"><b>Robert H. Aseltine</b><br>
                Professor <br /> 
                <a href="http://sdm.uchc.edu/departments/oralhealth/behavioral/index.html" target="_blank" class="headertext"> Division of Behavioral Sciences and Community Health</a>,<br>
                <a href="http://www.uchc.edu/" target="_blank" class="headertext"> University of Connecticut Health Center</a><br>
                Phone: (860)679-3282<br>
                Office: 263 Farmington Ave, MC 3910, Farmington, CT 06030-3910<br>		  
                Email: <a href = "mailto:aseltine@uchc.edu" class="headertext">aseltine@uchc.edu</a><br>
                Web: <a href = "http://www.publichealth.uconn.edu/robert-aseltine.html" target="_blank" class="headertext">Personal Page</a>
            </td>
        </tr>
    </table>
    
    <br />
    <br />
    <hr>
    <br />
    
    
    <div id="people">
        <center>
            <font size="+3" color="#666600">Recommend our online tools</font>
            <br />
            <br />
            <!-- Place this tag where you want the +1 button to render -->
            <g:plusone size="tall" annotation="inline" href="http://rlatools.com"></g:plusone>
            <br />
            <script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
            <fb:like href="http://rlatools.com/" show_faces="true" width="450" action="recommend"></fb:like>      
      
        </center>
        
        <!-- Place this render call where appropriate -->
        <script type="text/javascript">
          (function() {
            var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
            po.src = 'https://apis.google.com/js/plusone.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
          })();
        </script>
    
    
    </div>



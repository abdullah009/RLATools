<table width="100%"><tr bgcolor="#EEEEEE"><td>
<font size="+3" color="#3366FF"> Finding de-novo protein motif sequences </font><br>
<p><font size="+1" color="#3366FF">This tool will help you detect <b>new unknown protein motifs</b> that may be present in your input sequences.</font></p>
</td></tr></table><br>

<?php 

if ($_POST['cmd'] == 'Submit') { 
	if (!$captcha_passed) {
		echo '<br><font color="#FF0000">You did not answer the verification question correctly. Please answer it again.</font><br>';
		include_once('forms/form_motifseqprotein.php');
	} else if (!$isValidData) {
		echo '<br><font color="#FF0000">Your protein sequences are not in the correct format. Please check it again.</font><br>';
		echo '<br><font color="#FF0000">'.$invalidDataErrorMessage.'</font><br>';
		include_once('forms/form_motifseqprotein.php');
	} else {
		echo "<center>Valid data.</center><br>";
	}	
} else if (false && $_GET['cmd'] == 'confirmQuery') {
	if ($isConfirmSucc) {
		echo "<center>Your query <b>$queryID</b> has been confirmed.<br>";
		echo '<a href="index.php?page=motifproteinseq&cmd=viewResult&queryID='.$queryID.'&cd='.SecurityEncodeFunc("$queryID").'">Click here to view your result.</a>';
		echo '</center>';			
	} else {
		echo "<center>Your query <b>$querID</b> does not exist.<br></center>";
	}
} else if ($_GET['cmd'] == 'viewResult' || $_GET['cmd'] == 'confirmQuery') {
	if ($isConfirmSucc && $processingStatus >= 1) {
		echo '<table width="100%"><tr bgcolor="#EEEEEE"><td>';
		echo $queryInforInHTML;
		echo '</td></tr></table><br>';
		
		if ($_GET['email'] == "update" ) {
			echo '<table width="100%"><tr bgcolor="#EEEEEE"><td>';
			$htmlPageName = 'motifproteinseq';
			include_once('forms/form_contact.php');			
			echo '</td></tr></table><br><br>';
		}
		if ($_GET['rateaccuracy'] == "update" ) {
			echo '<table width="100%"><tr bgcolor="#EEEEEE"><td>';
			$htmlPageName = 'motifproteinseq';
			include_once('forms/form_rateaccuracy.php');			
			echo '</td></tr></table><br>';
		}
		if ($_GET['params'] == "update" ) {
			echo '<table width="100%"><tr bgcolor="#EEEEEE"><td>';
			$htmlPageName = 'motifproteinseq';
			include_once('forms/form_changeparamprotein.php');
			echo '</td></tr></table><br>';
		}
		
		if ($ShowGoogleAd) {
			echo '<table width="100%"><tr bgcolor="#EEEEEE"><td>';
			echo '<script type="text/javascript"><!--
					google_ad_client = "ca-pub-7352602991462416";
					/* ad_banner */
					google_ad_slot = "8736138274";
					google_ad_width = 728;
					google_ad_height = 90;
					//-->
					</script>
					<script type="text/javascript"
					src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
				</script>';
			echo '</td></tr></table><br>';
		}
	
		echo '<table width="100%"><tr bgcolor="#EEEEEE"><td width="35%" bgcolor="#EEEEEE"><font color="#3399FF" size="+2"><b>Motifs found</b></font></td>';
		echo '<td width="65%" bgcolor="#EEEEEE"><font color="#3399FF" size="+2"><b>Input protein sequences</b></font></td></tr>';
		echo '<tr bgcolor="#EEEEEE" valign="top"><td>'.$motifFoundInHTML.'&nbsp;</td><td>'.$inputSeqsInHTML.'</td></tr>';
		echo '</table>';
	} else {
		echo "<center>Your query <b>$queryID</b> does not exist.<br></center>";
	}
} else {
	echo '<table width="100%"><tr bgcolor="#EEEEEE"><td>';
	include_once('forms/form_motifseqprotein.php');
	echo '</td></tr></table><br>';

	if ($ShowGoogleAd) {
		echo '<table width="100%"><tr bgcolor="#EEEEEE"><td>';
		echo '<script type="text/javascript"><!--
				google_ad_client = "ca-pub-7352602991462416";
				/* ad_banner */
				google_ad_slot = "8736138274";
				google_ad_width = 728;
				google_ad_height = 90;
				//-->
				</script>
				<script type="text/javascript"
				src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
			</script>';
		echo '</td></tr></table><br>';
	}
}

?>



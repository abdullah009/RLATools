<div id="feedback">
    <center><font size="+3" color="#666600">Submit your feedbacks</font></center><br />
    <br />
</div>

    <?php 
    if (isset($_POST['cmd']) && ($_POST['cmd'] == 'Submit')) 
    {
        
        $captcha_passed = true;
       
        if ($captcha_passed) 
        {
            if (isset($_SESSION['userID']) && $_SESSION['userID'] > 0) {
                $userID = $_SESSION['userID'];
            } else {
                $userID = $AnonymousUserID;
            }
            $feedbackType = (int)substr($_POST['feedback_type'], 0, 3);
            $content = mysql_utils_strictly_prep(substr($_POST['content'], 0, 1000 - 4)); 
                
            $link = mysqli_connect($sql_host, $sql_username, $sql_password);
            if (!mysqli_select_db($link, $sql_database)) {
                die ();
            }		
            $feedbackID = insertAutoKeyRecord($link, '`general_feedback`',
                        array('`feedbackType`', '`userID`', '`submissionIPaddr`', '`submissionTime`', '`content`'),					 
                        array("$feedbackType", "$userID", "'".$_SERVER["REMOTE_ADDR"]."'", "NOW()", "'".$content."'"),
                        'feedbackID');				
            mysqli_close($link);
            echo '<br><div id="feedback"><center><b>Your feedback has been submitted successfully. Thank you.</b></center></div>';	
        } 
        else 
        {
			echo '<table width="100%"> <tr> <td>';
            include_once('forms/form_feedback.php');
			echo '</td></tr></table><br>';
        }
    } 
    else 
    {
        echo '<div id="feedback"><center>We are happy to hear feedback from you! Your feedback will help us improve the quality of our services. Thank you.</center></div>';
		echo '<table width="100%"> <tr> <td>';
		include_once('forms/form_feedback.php');
		echo '</td></tr></table><br>';
    }
    ?>
    
    <div id="feedback">
        <center>
            <font size="+3" color="#666600">Recommend our online tools</font>
            <br />
            <br />
            <!-- Place this tag where you want the +1 button to render -->
            <g:plusone size="tall" annotation="inline" href="http://rlatools.com"></g:plusone>
            <br />
            <script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
            <fb:like href="http://rlatools.com/" show_faces="true" width="450" action="recommend"></fb:like>      
      
        </center>
        
        <!-- Place this render call where appropriate -->
        <script type="text/javascript">
          (function() {
            var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
            po.src = 'https://apis.google.com/js/plusone.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
          })();
        </script>
    
    
    </div>
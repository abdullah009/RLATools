<div class="bodytext">
    <center><font size="+3" color="#666600">
        Record Linkage Using Single Linkage Clustering
    </font></center>
    <p>
        <a href="http://en.wikipedia.org/wiki/Record_linkage" target="_blank" class="headertext">Record linkage (RL)</a> refers to the task of identifying records across different data sources to refer to the same indiviual or any other entity. <br />
        Please visit <a href="index.php?page=help" target="_blank" class="headertext">instruction page</a> to fully understand how to use this tool.
	</p>
    
    <font color="#FF0000">
		<?php
            if (!isset($_POST['cmd']) || !($_POST['cmd'] == 'Submit'))
                echo 'Please fill up the required fields.'
        ?> 
    </font>
</div>


<?php
	
	function checkData()
	{
		
	}


	if (isset($_POST['cmd']) && ($_POST['cmd'] == 'Submit'))
	{
		
		createConfigXML();
		
		
		for ($i = 0; $i < $_POST["dataset_total"]; ++$i)
		{
			//echo "name: " . $_FILES["dataset".$i]["name"] . "<br>" . $_FILES["dataset".$i]["tmp_name"] . "<br>";
			if ($_FILES["dataset".$i]["error"] > 0)
				echo "Return Code: " . $_FILES["dataset".$i]["error"] . "<br>";
			else
				move_uploaded_file($_FILES["dataset".$i]["tmp_name"], "resource/".$jobName."/".$_FILES["dataset".$i]["name"]);
		}
		//echo 'submitted<br/>' . $jobName . '<br/>' . $jobLink . '<br>';
		
		if (isset($_SESSION['userID']) && $_SESSION['userID'] > 0) 
			$userID = $_SESSION['userID'];
		else 
			$userID = $AnonymousUserID;
			
		$userEmail		= $_POST['email'];
		
		
		$conn	= mysqli_connect($sql_host, $sql_username, $sql_password);
		if (!mysqli_select_db($conn, $sql_database)) die();
		
		$queryID	= insertAutoKeyRecord($conn, '`rla_query`', 
			array('`websiteID`', '`userID`', '`isConfirmed`', '`submissionIPAddr`', '`submissionTime`', '`latestUpdateTime`', '`processingStatus`', '`linkageMethod`', '`jobName`', '`jobLink`', '`recordTotal`', '`clusterTotal`', '`timeTaken`'), 
			array("$websiteID", "$userID", "1", "'".$_SERVER["REMOTE_ADDR"]."'", "NOW()", "NOW()", "$processingStatus", "$linkageMethod", "'".$jobName."'", "'".$jobLink."'", "-1", "-1", "-1"), 'queryID');
			
		$userID = getOneRecord($conn, '`userrl`', '`userID`', '`email`', "'$userEmail'"); 	
		//echo 	$userEmail . '\t' . $userPassword . '\t' . $userID . '<br>';
		if ($userID <= 0 && $userID != $AnonymousUserID) 
		{			
			$userPassword	= md5($randPassword);
			$userStatus		= 0;
			$userFirstName 	= mysql_utils_strictly_prep(substr(trim($_POST['firstName']), 0, 30));
			$userLastName 	= mysql_utils_strictly_prep(substr(trim($_POST['lastName']), 0, 30));
			$userPhone 		= mysql_utils_strictly_prep(substr(trim($_POST['phone']), 0, 20));
			$userOrgnization 	= mysql_utils_strictly_prep(substr(trim($_POST['organization']), 0, 60));
			$userID	= insertAutoKeyRecord($conn, '`userrl`',
						array('`email`', '`password`', '`status`', '`firstName`', '`lastName`', '`phone`','`organization`', '`lastLogin`'),
						array("'$userEmail'", "'$userPassword'", "$userStatus", "'$userFirstName'", "'$userLastName'", "'$userPhone'", "'$userOrgnization'", "NOW()" ),
						'userID');
			setOneRecord($conn, '`rla_query`', '`userID`', "$userID", '`queryID`', "$queryID");
			$_SESSION['userID']		= $userID;
			$_SESSION['userEmail']	= $userEmail;
		} 
		else if ($userID != $AnonymousUserID) 
		{
			setOneRecord($conn, '`userrl`', '`lastLogin`', "NOW()", '`userID`', "$userID");
			if (isset($_POST['firstName']) && $_POST['firstName'] != "") {
				$userFirstName = mysql_utils_strictly_prep(substr(trim($_POST['firstName']), 0, 30));
				setOneRecord($conn, '`userrl`', '`firstName`', "'".$userFirstName."'", '`userID`', "$userID");
			}
			if (isset($_POST['lastName']) && $_POST['lastName'] != "") {
				$userLastName = mysql_utils_strictly_prep(substr(trim($_POST['lastName']), 0, 30));
				setOneRecord($conn, '`userrl`', '`lastName`', "'".$userLastName."'", '`userID`', "$userID");
			}
			if (isset($_POST['phone']) && $_POST['phone'] != "") {
				$userPhone = mysql_utils_strictly_prep(substr(trim($_POST['phone']), 0, 20));
				setOneRecord($conn, '`userrl`', '`phone`', "'".$userPhone."'", '`userID`', "$userID");
			}
			if (isset($_POST['organization']) && $_POST['organization'] != "") {
				$userOrganization = mysql_utils_strictly_prep(substr(trim($_POST['organization']), 0, 60));
				setOneRecord($conn, '`userrl`', '`organization`', "'".$userOrganization."'", '`userID`', "$userID");
			}			
			//$userFirstName = getOneRecord($conn, '`user`', '`firstName`', '`userID`', "$userID"); 
			setOneRecord($conn, '`rla_query`', '`userID`', "$userID", '`queryID`', "$queryID");
			$_SESSION['userID'] = $userID;
			$_SESSION['userEmail'] = $userEmail;
		}
		
		
		mysqli_close($conn);
		
		echo '<table width="100%" class="bodytext"> <tr > <td>';
		echo '<center>Submitted</center>';
		echo '</td></tr></table><br>';
		
	}
	else
	{
		echo '<table width="100%"> <tr > <td>';
		include_once('forms/form_singlelinkage.php');
		echo '</td></tr></table><br>';
	}
	
	
	
?>
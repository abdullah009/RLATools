<div id="funding">
    <center><font size="+3" color="#666600">We would like to thank our sponsors</font></center>
    <br />
    </div>
    
    <table cellspacing="50px">
        <tr>
            <td align="center" id="funding">
                <a href="http://www.nih.gov" target="_blank">
                <img src="images/logo/NIH.jpg" alt="NIH Logo"  height="200" border="0"/>
                </a><br /> 
                <center>National Institutes of Health</center>
            </td>     
            <td align="center" id="funding">
                <a href="http://www.uconn.edu" target="_blank">
                <img src="images/logo/uconnlogo1.gif" alt="UCONN Logo"   height="200" border="0"/>
                </a><br /> 
                <center>University of Connecticut</center>
            </td>
            <td align="center" id="funding">
                <a href="http://www.cse.uconn.edu" target="_blank">
                <img src="images/logo/UCONN-CSE_logo.gif" alt="CSE Logo"  height="200" border="0"/>
                </a><br /> 
                <center>Dept of CSE, University of Connecticut</center>
            </td>
            <td align="center" id="funding">
                <a href="http://becat.uconn.edu/" target="_blank">
                <img src="images/logo/uconnlogo1.gif" alt="UCONN Logo"   height="200" border="0"/>
                </a><br /> 
               <center>BECAT, University of Connecticut</center>
            </td>
        </tr>
    
    </table>
    
    
    <div id="funding">
        <center><font size="+3" color="#666600">Fundings</font>
        <br>
        <br />
        Our website has been supported in part by the following grants: 
        <ul>
        <li><a href="http://projectreporter.nih.gov/project_info_details.cfm?aid=8142235&icde=11433713&ddparam=&ddvalue=&ddsub=" target="_blank" class="headertext"> 
        	<b>NIH R01LM010101</b></a>
        </li>
        </ul>
        </center>
    </div>
    
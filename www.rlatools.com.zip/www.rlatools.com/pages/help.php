<center><font size="+3" color="#666600">Free Online Record Linkage Tools</font></center><br>
<br />
<font size="+2" color="#3366FF">What is </font>
<a href="http://en.wikipedia.org/wiki/Record_linkage" target="_blank">
<font size="+2" color="#3366FF"><b>record linkage</b>?</font></a><br>
<p><a href="http://en.wikipedia.org/wiki/Record_linkage" target="_blank"><b>Record linkage (RL)</b></a> 
refers to the task of finding records in a data set that refer to the same entity across different data sources (e.g., data files, books, websites, databases). Record linkage is necessary when joining data sets based on entities that may or may not share a common identifier (e.g., database key, URI, National identification number), as may be the case due to differences in record shape, storage location, and/or curator style or preference. A data set that has undergone RL-oriented reconciliation may be referred to as being cross-linked. Record Linkage is called Data Linkage in many jurisdictions, but is the same process. More information about 
<a href="http://en.wikipedia.org/wiki/Record_linkage" target="_blank"><b>record linkage</b></a> can be found at wiki page
<a href="http://en.wikipedia.org/wiki/Record_linkage" target="_blank"><b>record linkage</b></a>.  
</p>

<font size="+2" color="#3366FF">About our online record linkage tools</font><br>
<p>Our online record linkage tools will help you detect new unknown motif sequences that 
may be present in your input sequences. Our tools include two features: 
<b><a href="index.php?page=motifseq">finding de-novo DNA motif sequences</a></b> and 
<a href="index.php?page=motifproteinseq"><b>finding de-novo protein motif sequences</b></a>.
<font size="+1" color="red">Our online tools are absolutely free!</font> 
</p>

<font size="+2" color="#3366FF">How to use our online motif search tools?</font><br>
<p>It's very simple. You can easily copy and paste your data into the form either at 
<a href="index.php?page=motifseq"><b>DNA sequences</b></a> or at
<a href="index.php?page=motifproteinseq"><b>protein sequences</b></a>, depending on whether your data is 
DNA sequences or protein sequences, and choose appropriate parameters, then submit. 
<font size="+1" color="red">Your data must be in </font>
<a href="http://en.wikipedia.org/wiki/FASTA_format" target="_blank"><font size="+1" color="red"><b>FASTA format</b></font></a>. 
Examples of FASTA format can be found at <a href="dnaseqssample.php" target="_blank"><b>DNA sequences in FASTA format</b></a> or at
<a href="proteinseqssample.php" target="_blank"><b>protein sequences in FASTA format</b></a>. 
Your data will be processed and you can view the result as soon as it is available. 
You will find our tools display the result visually. 
If the result is not available yet, click the "<b>Refresh</b>" button to view the most updated status of your submission.
You can bookmark the result link, close your web browser, and open the result link to check it back later. 
Your email will be kept confidential.
</p>
<p>
The processing time of your submission varies from few minutes to few hours, depends on your data and the parameters you choose.
If it seems to take few hours and you don't want to wait for the result to appear on your web brower, 
<b>let us know your contact email and now you can close your web browser.</b> 
We will send you a notification email as soon as the result is available. 
The notification email will include the link to the result. Open the email and click on the link, you will see 
the result.
</p>


<font size="+2" color="#3366FF">How do our online motif search tools work?</font><br>
<p>Our online motif search tools are built on 
<a href="http://www.biomedcentral.com/1471-2105/12/410" target="_blank"> <b>state-of-the-art algorithms </b></a>
<a href="http://www.plosone.org/article/info%3Adoi%2F10.1371%2Fjournal.pone.0041425" target="_blank"> <b>(algorithm qPMS7)</b></a>
for the most well-known motif search model
- The Planted Motif Search (PMS). The PMS Model precisely captures the nature of motifs and usually gives the most accurate 
results.</p>
 
<br>
<br>
<br>

<center><font size="+3" color="#666600">Like our online tools?</font><br>
<br />
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>&nbsp;
<fb:like href="http://rlatools.com/" show_faces="true" width="450" action="recommend"></fb:like>

<br><br>


<!-- Place this tag where you want the +1 button to render -->
<g:plusone size="tall" annotation="inline" href="http://rlatools.com"></g:plusone>
</center>

<!-- Place this render call where appropriate -->
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>

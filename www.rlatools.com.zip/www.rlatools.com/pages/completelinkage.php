<br />
<br />
<br />
<center><font face="Montserrat" size="+1" color="#FF0000">We will include record linkage using <b>Complete Linkage Clustering</b> soon! Please now use <a href="index.php?page=singlelinkage">Single Linkage Clustering</a> tool.</font></center><br>
<br />
<br />

 
<br>
<br>
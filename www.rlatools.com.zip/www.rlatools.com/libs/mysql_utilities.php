<?php 

function mysql_utils_strictly_prep($value) 
{
	$len = strlen($value);
	$ret = $value;
	for ($i = 0; $i < $len; $i++) {
		if ($value[$i] == '\'') {
			$ret[$i] = ' ';
		}
	}
	return $ret;
}

function mysql_utils_prep ($value)
{ 
    $magic_quotes_active = get_magic_quotes_gpc(); 
    $new_enough_php = function_exists("mysql_real_escape_string"); 
    // i.e PHP >= v4.3.0 
    if($new_enough_php)
	{ 
	    //undo any magic quote effects so mysql_real_escape_string can do the work 
    	if($magic_quotes_active)
		{ 
        	$value = stripslashes($value); 
	    } 
    	$value = mysqli_real_escape_string($value); 
    } 
	else 
	{ // before PHP v4.3.0 
        // if magic quotes aren't already on this add slashes manually 
        if(!$magic_quotes_active)
		{ 
            $value = addslashes($value); 
        } //if magic quotes are avtive, then the slashes already exist 
    } 
    return $value; 
} 

function insertAutoKeyRecord($conn, $table, $columns, $columnVals, $recordKeyName) 
{
	if (count($columnVals) != count($columns)) 
		return -1; 
	else 
	{
		$query = "INSERT INTO $table($recordKeyName";
		for ($i = 0; $i < count($columns); $i++) 
		{
			$query .= "," . $columns[$i] ;
		}
		$query .= ") VALUES(NULL ";
		for ($i = 0; $i < count($columnVals); $i++) 
		{
			$query .= ',' . $columnVals[$i] ;
		}
		$query .= ")";
		//echo '<br>'.$query.'<br>';
		mysqli_query($conn, $query) or die(mysqli_error($conn));	
		return mysqli_insert_id($conn);
	}	
}

function insertRecord($conn, $table, $columns, $columnVals) 
{
	if (count($columns) < 1 || count($columnVals) != count($columns)) 
		return 0; 
	else 
	{
		$query = "INSERT INTO $table(";
		for ($i = 0; $i < count($columns) - 1; $i++) 
		{
			$query .= $columns[$i] .',' ;
		}
		$query .= $columns[count($columns) - 1].") VALUES(";
		for ($i = 0; $i < count($columnVals) - 1; $i++) 
		{
			$query .= $columnVals[$i]. ',' ;
		}
		$query .= $columnVals[count($columnVals) - 1].")";
		//echo $query.'<br>';
		mysqli_query($conn, $query) or die(mysqli_error($conn));	
		return mysqli_affected_rows($conn);
	}	
}

function deleteOneRecord($conn, $table, $recordKeyName, $recordKeyNum) 
{
	$query = "DELETE FROM $table WHERE $recordKeyName = $recordKeyNum";
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
	return mysqli_affected_rows($conn);	
}

function getOneRecord($conn, $table, $column, $recordKeyName, $recordKeyNum) 
{
	$query	= "SELECT $column as columnName FROM  $table WHERE $recordKeyName = $recordKeyNum";
	//echo '<br/>'.$query.'<br/>';
	$result	= mysqli_query($conn, $query) or die(mysqli_error($conn));
	$row = mysqli_fetch_array($result);	
	//echo '<br/>'.$row['columnName'].'<br/>';
	//exit(1);
	return $row['columnName'];	
}

function getNumRecords($conn, $tables, $conditions) 
{
	$query = "SELECT COUNT(*) as num_recs FROM  $tables WHERE $conditions ";
	//echo '<br>'.$query;
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
	$row = mysqli_fetch_array($result);
	return $row['num_recs'];	
}

function getNumOfRecords($conn, $table, $columns, $columnVals) {
	$query = "SELECT COUNT(*) as num_recs FROM  $table WHERE 1 = 1 ";
	for ($i = 0; $i < count($columns) && $i < count($columnVals) ; $i++) {
		$query .= " AND ".$columns[$i]."=".$columnVals[$i] ;
	}
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
	$row = mysqli_fetch_array($result);
	//echo $query.'<br/>'.$row["$column"];
	//exit(1);
	return $row['num_recs'];	
}
/*
function getNumOfDistinctRecords($conn, $table, $distinctColumn, $columns, $columnVals) {
	$query = "SELECT DISTINCT $distinctColumn FROM  $table WHERE 1 = 1 ";
	for ($i = 0; $i < count($columns) && $i < count($columnVals) ; $i++) {
		$query .= " AND ".$columns[$i]."=".$columnVals[$i] ;
	}
	$result = mysql_query($query, $conn) or die(mysql_error($conn));	
	return mysql_num_rows($result);	
}
*/

function getNumOfDistinctRecords($conn, $tables, $distinctColumn, $conditions) {
	$query = "SELECT DISTINCT $distinctColumn FROM  $tables WHERE $conditions ";
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));	
	return mysqli_num_rows($result);		
}

function getNumOfNotNullDistinctRecords($conn, $tables, $distinctColumn, $conditions) 
{
	$query = "SELECT DISTINCT $distinctColumn FROM  $tables WHERE ($distinctColumn IS NOT NULL) AND ($conditions)";	
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));	
	return mysqli_num_rows($result);		
}

function getSumRecords($conn, $tables, $column, $conditions) 
{
	$query = "SELECT SUM($column) as sum_val FROM  $tables WHERE $conditions ";
	//echo '<br>'.$query;
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));	
	$row = mysqli_fetch_array($result);	
	return $row['sum_val'];		
}


function getMaxRecords($conn, $tables, $column, $conditions) {
	$query = "SELECT MAX($column) as max_val FROM  $tables WHERE $conditions ";
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));	
	$row = mysqli_fetch_array($result);	
	return $row['max_val'];		
}

function getMinRecords($conn, $tables, $column, $conditions) {
	$query = "SELECT MIN($column) as min_val FROM  $tables WHERE $conditions ";
	$result = mysqli_query($conn, $query) or die(mysqli_error($conn));	
	$row = mysqli_fetch_array($result);	
	return $row['min_val'];		
}


function setOneRecord($conn, $table, $column, $columnVal, $recordKeyName, $recordKeyNum) {
	$query = "UPDATE $table SET $column = $columnVal WHERE $recordKeyName = $recordKeyNum";
	mysqli_query($conn, $query) or die(mysqli_error($conn));
	return mysqli_affected_rows($conn);
}

function setInsertOneRecord($conn, $table, $column, $columnVal, $recordKeyName, $recordKeyNum) {
	if (getOneRecord($conn, $table, $recordKeyName, $recordKeyName, $recordKeyNum)) {
		//echo 'no insert <br/>';
		return setOneRecord($conn, $table, $column, $columnVal, $recordKeyName, $recordKeyNum);
	} else {
		//echo 'insert <br/>';
		return insertRecord($conn, $table, array($recordKeyName,$column), array($recordKeyNum,$columnVal));	
	}
}


function printSelectOptionList($conn, $tables, $value_col, $caption_col, $order_by_col, $order_by_type, $selected_val, $condition) {
	$query = "SELECT DISTINCT $value_col, $caption_col FROM $tables WHERE $condition ORDER BY $order_by_col $order_by_type";
	//echo $query;
	$result = mysqli_query($conn, $query);
	while($res  = mysqli_fetch_array($result,MYSQL_ASSOC)) {
		if ($res["$value_col"] == $selected_val && $res["$value_col"] != '') {
			echo '<option value="'.$res["$value_col"].'"  selected>'.$res["$caption_col"]."</option>\n";
		} else if ($res["$value_col"] != ''){
			echo '<option value="'.$res["$value_col"].'">'.$res["$caption_col"]."</option>\n";
		}		
	}	
	mysqli_free_result($result);	
}

?>
<?php 

function isValidEmail($email) {
	$len = strlen($email);
	if ($len < 4) {
		return false;
	}
	if ($email[0] == '.' || $email[$len - 1] == '.') {
		return false;
	}	
	for ($i = 0; $i < $len; $i++) {
		$ch = $email[$i];
		if ( !('a' <= $ch && $ch <= 'z') && 
			 !('A' <= $ch && $ch <= 'Z') && 
			 !('0' <= $ch && $ch <= '9') &&
			 !($ch == '.') ) {
			break;
		}
	}
	if ($i == 0 || $email[$i - 1] == '.' || $email[$i] != '@') {
		//echo '<br> i = '. $i;
		return false;
	}
	$i++;
	if ($i < $len && $email[$i] == '.') {
		return false;
	}
	for (; $i < $len; $i++) {
		$ch = $email[$i];
		if ( !('a' <= $ch && $ch <= 'z') && 
			 !('A' <= $ch && $ch <= 'Z') && 
			 !('0' <= $ch && $ch <= '9') &&
			 !($ch == '.') ) {
			 //echo '<br> i = '. $i. ' ch='.$ch;
			return false;
		}	
	}
	return true;
}

function getValueOfArrayPaternIndex($array,$key_patern) {
	$ret = array();
	foreach ($array as $key => $value) {
		$pos = strpos($key,$key_patern);		
		if ($pos !== false) {
			$ret[] = $value;
		}
	}
	return $ret;
}

function isFoundKeyInArray($array,$val) {
	foreach ($array as $key => $value) {
		if ($value == $val) return true;
	}
	return false;
}

function checkDateFormat($date) {  
	//match the format of the date  
	if (preg_match ("/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/", $date, $parts)) {		 
		//check weather the date is valid of not	
		if(checkdate($parts[2],$parts[3],$parts[1])) {
			return true;
		} else { 
			return false;
		}  
	}  else {  
		return false;
	}
}

?>
<div id="footer">
    <table bgcolor="#CCCCCC" width="100%">
    <tr><td  align="center" valign="top">
    Copyright � 2014 rlatools.com. All Rights Reserved.
    </td></tr>
    </table>
</div>
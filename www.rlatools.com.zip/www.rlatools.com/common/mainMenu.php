<table width="100%" border="0" cellpadding="0" cellspacing="1">
<tr align="center" valign="middle" bgcolor="#CCCCCC">
          
    <td width="135px" valign="middle" <?php if ($_SESSION['current_tab'] == 'Home') echo 'bgcolor="#99CCFF"'; ?> >
	 <a href="index.php" >Home</a> </td>

    <td width="135px" valign="middle" <?php if ($_SESSION['current_tab'] == 'MotifSearchOnline') echo 'bgcolor="#99CCFF"'; ?> >
	 <a href="pageMotifSearchOnline.php" >Job Submissions </a></td>
          
    <td width="135px" valign="middle" <?php if ($_SESSION['current_tab'] == 'DownloadSoftware') echo 'bgcolor="#99CCFF"'; ?> >
	 <a href="pageDownloadSoftware.php" >Download </a></td>

    <td width="135px" valign="middle" <?php if ($_SESSION['current_tab'] == 'Publications') echo 'bgcolor="#99CCFF"'; ?> >
	 <a href="pagePublications.php" >Citations </a></td>

    <td width="135px" valign="middle" <?php if ($_SESSION['current_tab'] == 'People') echo 'bgcolor="#99CCFF"'; ?> >
	 <a href="pagePeople.php" >Authors </a></td>

    <td width="135px" valign="middle" <?php if ($_SESSION['current_tab'] == 'ContactUs') echo 'bgcolor="#99CCFF"'; ?> >
	 <a href="pageContactUs.php" >Contact Us</a> </td>
<!--
<?php if (isset($_SESSION['isUserLoggin']) && ($_SESSION['isUserLoggin'] == 'y' || $_SESSION['isUserLoggin'] == 'Y')) { ?>
    <td width="135px" valign="middle" <?php if ($_SESSION['current_tab'] == 'MyAccount') echo 'bgcolor="#99CCFF"'; ?>>
	<a href="pageMyAccount.php" >My Account </a> <a href="processLogout.php" >(Logout)</a></td>    
<?php } else { ?>	 
    <td width="135px" valign="middle" <?php if ($_SESSION['current_tab'] == 'UserLoginOrRegister') echo 'bgcolor="#99CCFF"'; ?>>
	<a href="pageUserLogin.php" >User Login </a> or <a href="pageRegister.php" > Register </a></td>    
<?php } ?>	
-->   
</tr>
</table>
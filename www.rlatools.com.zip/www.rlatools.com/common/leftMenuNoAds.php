<hr>
<h3><b>Record Linkage</b></h3>
<hr>
<ul>
  
  <li>
  	<a href="index.php?page=services"> Online recordf linkage tools </a> <br>
	<ul>
		<li><a href="index.php?page=singlelinkage"> Finding record linkage using <br><font size="+1"><b>single linkage clustering</b></font> </a> <hr></li>
        <li><a href="index.php?page=motifseq"> Finding record linkage using <br><font size="+1"><b>complete linkage clustering</b></font> </a> </li>
<!--		
		<li><a href="index.php?page=motifseqcmp"> Comparing DNA/protein motif sequences</a> <hr> </li>
		<li><a href="index.php?page=motifstrct"> Comparing protein structures</a> </li>
-->		
	</ul>
	<hr>	
  </li>
  <li><a href="index.php?page=submissionhistory"> Submission history </a> <hr></li>
  <li><a href="index.php?page=help"> Help </a> <hr></li> 
  <li><a href="index.php?page=feedback"> Feedback </a> <hr></li> 
  <li><a href="index.php?page=download"> Download </a> <hr></li> 
  <li><a href="index.php?page=sponsors"> Sponsors and fundings</a> <hr></li> 
  <li><a href="index.php?page=aboutus"> About us </a> </li>   
</ul>
<hr>


<br>
<br>

<hr>
<h3>External Links</h3>
<hr>
<ul>
  <li><a href="http://www.uconn.edu" target="_blank"> University of Connecticut </a> <hr></li>
  <li><a href="http://www.cse.uconn.edu" target="_blank"> Computer Science and Engineering Department </a> <hr> </li>
  <li><a href="http://www.becat.uconn.edu" target="_blank"> BECAT: Booth Engineering Center for Advanced Technology </a> <hr> </li>
  <li><a href="http://pms.engr.uconn.edu" target="_blank"> PMS: Online Motif Discovery Tools</a> <hr> </li>
  <li><a href="http://mnm.engr.uconn.edu" target="_blank"> MnM: Advance Mimimotif Miner </a> </li>
</ul>
<hr>



<div id="menu">
	<a href="index.php?page=singlelinkage" class="menutext">Single Linkage Tool</a> | 
    <a href="index.php?page=help" class="menutext">Instruction</a> |
    <a href="index.php?page=submissionhistory" class="menutext">Submission Info</a> |
    <a href="index.php?page=feedback" class="menutext">Feedback</a> |
    <a href="index.php?page=download" class="menutext">Publication</a> |
    <a href="index.php?page=sponsors" class="menutext">Funding</a> |
	<a href="index.php?page=aboutus" class="menutext">People</a>
</div>

<div class="solid_divider">
</div>



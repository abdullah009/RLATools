<?php
header('Location: ../');
exit;
?>
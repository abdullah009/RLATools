<div id="header">
    <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr align="center" valign="middle">
        	<td align="center" width="160">
            	<img src="images/logo/logo.jpg" height="140" width="140" class="img_header"/>
            </td>
            <td align="center" width="30%">
            	<table>
                    <tr>
                        <a href="http://www.rlatools.com" target="_blank" class="sitename">rlatools.com</a>
                    </tr>
                    <tr>
                        <font face="TymesLittleCaps" size="-1" color="#333300"> Implementation of Record Linkage Algorithms</font>
                    </tr>
                 </table>
            </td>
            <td align="left">
            	<p>
 	           		The purpose of this website is to provide record linkage tools. Currently we have made a record linkage tool available which uses <a href="http://jamia.bmj.com/content/21/2/252.full.pdf+html" target="_blank" class="headertext">single linkage clustering algorithm</a>.
                </p>
            </td>
        </tr>
    </table>
</div>
<div class="solid_divider">
</div>

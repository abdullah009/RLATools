<hr>
<h3><b>Panoptic Motif Search</b></h3>
<hr>
<ul>
  
  <li>
  	<a href="index.php?page=services"> Online motif search tools </a> <br>
	<ul>
		<li><a href="index.php?page=motifseq"> Finding de-novo <font size="+1"><b>DNA motif</b></font> sequences <img src="images/system/newbutton1.png" width="50" height="20" border="0"></a> <hr> </li>
		<li><a href="index.php?page=motifproteinseq"> Finding de-novo <font size="+1"><b>Protein motif</b></font> sequences <img src="images/system/newbutton1.png" width="50" height="20" border="0"></a> </li>
<!--		
		<li><a href="index.php?page=motifseqcmp"> Comparing DNA/protein motif sequences</a> <hr> </li>
		<li><a href="index.php?page=motifstrct"> Comparing protein structures</a> </li>
-->		
	</ul>
	<hr>	
  </li>
  <li><a href="index.php?page=submissionhistory"> Submission history </a> <hr></li>
  <li><a href="index.php?page=help"> Help </a> <hr></li> 
  <li><a href="index.php?page=feedback"> Feedback </a> <hr></li> 
  <li><a href="index.php?page=download"> Download </a> <hr></li> 
  <li><a href="index.php?page=sponsors"> Sponsors and fundings</a> <hr></li> 
  <li><a href="index.php?page=aboutus"> About us </a> </li>   
</ul>
<hr>


<?php if ($ShowGoogleAd) { $randGoogleAd = rand(1,5); //echo $randGoogleAd.'<br>'; ?>
<table><tr><td valign="center" align="left" width="75">
<font size="+2" color="#0066CC"><b>Useful Links</b></font>
</td>
<td td valign="top" align="left">
<img src="images/system/big-red-curved-down-arrow-right.png" width="100" height="80"/>
</td>
</tr></table>
<!-- <h3><b>Google Ad</b></h3> -->
<?php if ($randGoogleAd == 1) {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* LeftMenuAd1 */
google_ad_slot = "6503482164";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } else if ($randGoogleAd == 2) {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* LeftMenuAd7 */
google_ad_slot = "9354084124";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } else if ($randGoogleAd == 3) {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* LeftMenuAd9 */
google_ad_slot = "1012346999";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } else if ($randGoogleAd == 4) {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* LeftMenuAd9 */
google_ad_slot = "1012346999";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } else  {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* LeftMenuAd10 */
google_ad_slot = "1594602687";
google_ad_width = 200;
google_ad_height = 200;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } ?>
<?php }//end if google ad ?>



<br>

<hr>
<h3>External Links</h3>
<hr>
<ul>
  <li><a href="http://www.uconn.edu" target="_blank"> University of Connecticut </a> <hr></li>
  <li><a href="http://www.cse.uconn.edu" target="_blank"> Computer Science and Engineering Department </a> <hr> </li>
  <li><a href="http://www.becat.uconn.edu" target="_blank"> BECAT: Booth Engineering Center for Advanced Technology </a> <hr> </li>
  <li><a href="http://pms.engr.uconn.edu" target="_blank"> PMS: Online Motif Discovery Tools</a> <hr> </li>
  <li><a href="http://mnm.engr.uconn.edu" target="_blank"> MnM: Advance Mimimotif Miner </a> </li>
</ul>
<hr>


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-29333328-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<font size="+1" face="Montserrat">
<hr>
<h3 align="center"><b><a href="index.php?page=services"><font size="+1" color="CC6666">Record Linkage</font></a></b></h3>
<hr>
<ul>
  	

	<ul>
		<li><a href="index.php?page=singlelinkage"> Finding record linkage using <b>single linkage clustering</b> </a> <hr></li>
        <li><a href="index.php?page=completelinkage"> Finding record linkage using <b>complete linkage clustering</b> </a> </li>
<!--		
		<li><a href="index.php?page=motifseqcmp"> Comparing DNA/protein motif sequences</a> <hr> </li>
		<li><a href="index.php?page=motifstrct"> Comparing protein structures</a> </li>
-->		
	</ul>
	<hr>	
  
  <li><a href="index.php?page=submissionhistory"> <font color="#000000">Submission history</font> </a> <hr></li>
  <li><a href="index.php?page=help"> Help </a> <hr></li> 
  <li><a href="index.php?page=feedback"> Feedback </a> <hr></li> 
  <li><a href="index.php?page=download"> Download </a> <hr></li> 
  <li><a href="index.php?page=sponsors"> Sponsors and fundings</a> <hr></li> 
  <li><a href="index.php?page=aboutus"> About us </a> </li>   
  
</ul>
</font>

<?php if ($ShowGoogleAd) { $randGoogleAd = rand(1,5); //echo $randGoogleAd.'<br>'; ?>

<!-- <h3><b>Google Ad</b></h3> -->
<?php if ($randGoogleAd == 1) {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* NewAd1 */
google_ad_slot = "0575834107";
google_ad_width = 234;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } else if ($randGoogleAd == 2) {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* NewAd2 */
google_ad_slot = "7188707376";
google_ad_width = 234;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } else if ($randGoogleAd == 3) {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* NewAd3 */
google_ad_slot = "0036746804";
google_ad_width = 234;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } else if ($randGoogleAd == 4) {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* NewAd5 */
google_ad_slot = "8238423527";
google_ad_width = 234;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } else  {  ?>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7352602991462416";
/* NewAd5 */
google_ad_slot = "8238423527";
google_ad_width = 234;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<?php } ?>
<?php }//end if google ad ?>	

<br>
<hr>
<h3 align="center"><b><font size="+1" color="CC6666" face="Montserrat">External Links</font></b></h3>
<font size="+1" face="Montserrat" color="#000000">
<hr>
<ul>
  <li><a href="http://www.uconn.edu" target="_blank"> University of Connecticut </a> <hr></li>
  <li><a href="http://www.cse.uconn.edu" target="_blank"> Computer Science and Engineering Department </a> <hr> </li>
  <li><a href="http://www.becat.uconn.edu" target="_blank"> BECAT: Booth Engineering Center for Advanced Technology </a> <hr> </li>
   <li><a href="http://pms.engr.uconn.edu" target="_blank"> PMS: Online Motif Discovery Tools</a> <hr> </li>
  <li><a href="http://mnm.engr.uconn.edu" target="_blank"> MnM: Advance Mimimotif Miner </a> </li>
</ul>
<hr>
</font>

<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-29333328-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>

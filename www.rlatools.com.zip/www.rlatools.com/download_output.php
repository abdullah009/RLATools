<?php
	
	if ((isset($_GET['cmd']) && $_GET['cmd'] == 'download') || (isset($_POST['cmd']) && $_POST['cmd'] == 'download') ) 
	{	
		$path	= $_SERVER['DOCUMENT_ROOT'].$_GET['link'];
		//echo $path . "<br/>";
		if (is_readable($path))
		{
			header("Content-type: text/csv");
			header('Content-disposition: attachment; filename="output.csv"');
			readfile($path);
			exit;
		}
		else
		{
			die("Invalid Request");
		}		
	}
?>